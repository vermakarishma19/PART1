package com.viasat.facade.provisioning.sdp.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.provisioning.sdp.wrapper.BusinessTransactionWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ContactsWrapper;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.data.CorrectedContact;
import com.viasat.wildblue.facade.provisioning.data.UpdateContacts;
import com.viasat.wildblue.facade.provisioning.data.UpdateContactsResponse;

public class UpdateProcessor
{
	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateProcessor.class);

	private BusinessTransactionWrapper businessTransactionWrapper;
	private ContactsWrapper contactsWrapper;

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.businessTransactionWrapper = businessTransactionWrapper;
	}

	public void setContactsWrapper(ContactsWrapper contactsWrapper)
	{
		this.contactsWrapper = contactsWrapper;
	}

	public UpdateContactsResponse updateContacts(UpdateContacts parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{

		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String accountReference = businessTransactionWrapper
				.getAccountReferenceFromInternalServiceAgreementReference(serviceAgreementReference,
						wildBlueHeader);
		CorrectedContact cc = parameter.getCorrectedContact();

		contactsWrapper.updateAllContactAggregates(serviceAgreementReference, accountReference, cc,
				wildBlueHeader.getInvokedBy().getUsername(),
				wildBlueHeader.getInvokedBy().getApplication());
		UpdateContactsResponse response = new UpdateContactsResponse();
		return response;
	}

}
