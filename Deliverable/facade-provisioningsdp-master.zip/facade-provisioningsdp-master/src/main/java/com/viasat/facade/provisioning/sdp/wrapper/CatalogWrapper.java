package com.viasat.facade.provisioning.sdp.wrapper;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.common.fault.WebServiceFault;
import com.viasat.facade.catalog.client.CatalogServiceClient;
import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.catalog.data.GetComponents;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.wildblue.common.exception.ExceptionDetail;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;

public class CatalogWrapper
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CatalogWrapper.class);

	private CatalogServiceClient catalogServiceClient;

	public void setCatalogServiceClient(CatalogServiceClient catalogServiceClient)
	{
		this.catalogServiceClient = catalogServiceClient;
	}

	public GetComponentsResponse getComponent(String mcr, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetComponents req = new GetComponents();
		req.getMasterCatalogReferences().add(mcr);

		try
		{
			return catalogServiceClient.getEndpoint().getComponents(req, wildBlueHeader);
		}
		catch (WebServiceFault e)
		{
			throw convertWebServiceFaultToWebServiceException("getComponents", e);
		}
	}

	public GetComponentsResponse getComponents(List<String> mcrs, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetComponents req = new GetComponents();
		req.getMasterCatalogReferences().addAll(mcrs);

		try
		{
			return catalogServiceClient.getEndpoint().getComponents(req, wildBlueHeader);
		}
		catch (WebServiceFault e)
		{
			throw convertWebServiceFaultToWebServiceException("getComponents", e);
		}
	}

	private WebServiceException convertWebServiceFaultToWebServiceException(String request,
			WebServiceFault e)
	{
		ExceptionDetail ed = new ExceptionDetail();
		ed.setDetail("Message: " + e.getMessage());
		String msg = "Failed to call FCD-Catalog: " + request;
		LOGGER.error(msg, e);
		return new WildBlueWebServiceException(msg, ed, e);
	}
}
