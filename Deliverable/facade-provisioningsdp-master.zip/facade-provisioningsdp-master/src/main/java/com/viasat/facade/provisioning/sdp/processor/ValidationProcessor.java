package com.viasat.facade.provisioning.sdp.processor;

import java.util.Date;
import java.util.List;

import com.viasat.wildblue.common.commondata.ValidationError;
import com.viasat.wildblue.common.commondata.ValidationResult;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.common.validator.ValidationBean;
import com.viasat.wildblue.common.validator.ValidatorTool;
import com.viasat.wildblue.common.validator.WebServiceValidationException;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.AddServiceItem;
import com.viasat.wildblue.facade.provisioning.data.CancelAddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.CancelTransitionServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.CancelTransitionServiceEquipment;
import com.viasat.wildblue.facade.provisioning.data.CorrectedContact;
import com.viasat.wildblue.facade.provisioning.data.CustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.DisconnectAccount;
import com.viasat.wildblue.facade.provisioning.data.DisconnectServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.DisconnectServiceItem;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.ServiceItem;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceEquipment;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceEquipmentComplete;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceItem;
import com.viasat.wildblue.facade.provisioning.data.UpdateContacts;
import com.viasat.wildblue.facade.provisioning.data.UpdateEquipment;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelAddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelTransitionServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelTransitionServiceEquipmentResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectAccountResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateResumeAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateSuspendAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceEquipmentCompleteResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceEquipmentResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateUpdateContactsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateUpdateEquipmentResponse;

public class ValidationProcessor
{
	void checkValidationResult(ValidationResult validationResult) throws WebServiceException
	{
		if (validationResult != null && !validationResult.getValidationError().isEmpty())
			throw new WebServiceValidationException(validationResult.getValidationError());
	}

	public ValidateAddCustomerHierarchyResponse validateAddCustomerHierarchy(
			AddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateAddCustomerHierarchyResponse response = new ValidateAddCustomerHierarchyResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		CustomerHierarchy customerHierarchy = parameter.getCustomerHierarchy();

		ValidationBean validationBean = new ValidationBean("addCustomerHierarchy");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("customerHierarchy", customerHierarchy);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateAddServiceItemResponse validateAddServiceItem(AddServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateAddServiceItemResponse response = new ValidateAddServiceItemResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String transactionReference = parameter.getTransactionReference();
		ServiceItem serviceItem = parameter.getServiceItem();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("addServiceItem");
		validationBean.setField("serviceAgreementReference", serviceAgreementReference);
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceItem", serviceItem);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateCancelAddCustomerHierarchyResponse validateCancelAddCustomerHierarchy(
			CancelAddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelAddCustomerHierarchyResponse response = new ValidateCancelAddCustomerHierarchyResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String targetTransactionReference = parameter.getTargetTransactionReference();
		String reason = parameter.getReason();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("cancelAddCustomerHierarchy");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("targetTransactionReference", targetTransactionReference);
		validationBean.setField("reason", reason);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateCancelTransitionServiceAgreementResponse validateCancelTransitionServiceAgreement(
			CancelTransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelTransitionServiceAgreementResponse response = new ValidateCancelTransitionServiceAgreementResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String targetTransactionReference = parameter.getTargetTransactionReference();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("cancelTransitionServiceAgreement");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("targetTransactionReference", targetTransactionReference);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateCancelTransitionServiceEquipmentResponse validateCancelTransitionServiceEquipment(
			CancelTransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelTransitionServiceEquipmentResponse response = new ValidateCancelTransitionServiceEquipmentResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String targetTransactionReference = parameter.getTargetTransactionReference();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("cancelTransitionServiceEquipment");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("targetTransactionReference", targetTransactionReference);
		validationBean.setField("startDate", startDate);

		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateDisconnectAccountResponse validateDisconnectAccount(DisconnectAccount parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateDisconnectAccountResponse response = new ValidateDisconnectAccountResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String accountReference = parameter.getAccountReference();
		String reason = parameter.getReason();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("disconnectAccount");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("accountReference", accountReference);
		validationBean.setField("reason", reason);
		validationBean.setField("startDate", startDate);

		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateDisconnectServiceAgreementResponse validateDisconnectServiceAgreement(
			DisconnectServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateDisconnectServiceAgreementResponse response = new ValidateDisconnectServiceAgreementResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String reason = parameter.getReason();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("disconnectServiceAgreement");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceAgreementReference", serviceAgreementReference);
		validationBean.setField("reason", reason);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateDisconnectServiceItemResponse validateDisconnectServiceItem(
			DisconnectServiceItem parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateDisconnectServiceItemResponse response = new ValidateDisconnectServiceItemResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String serviceItemReference = parameter.getServiceItemReference();
		// currently there is no place to store reason in VBS
		// and it's not required according to facade's schema
		// ignoring this field altogether
		// String reason = parameter.getReason();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("disconnectServiceItem");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceItemReference", serviceItemReference);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateResumeAllServiceAgreementsResponse validateResumeAllServiceAgreements(
			ResumeAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateResumeAllServiceAgreementsResponse response = new ValidateResumeAllServiceAgreementsResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String accountReference = parameter.getAccountReference();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("resumeAllServiceAgreements");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("accountReference", accountReference);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateSuspendAllServiceAgreementsResponse validateSuspendAllServiceAgreements(
			SuspendAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateSuspendAllServiceAgreementsResponse response = new ValidateSuspendAllServiceAgreementsResponse();
		ValidationResult result = new ValidationResult();
		TransactionValidationProcessor transactionValidationProcessor = new TransactionValidationProcessor();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String accountReference = parameter.getAccountReference();
		String reasonCode = parameter.getReasonCode();

		ValidationBean validationBean = new ValidationBean("suspendAllServiceAgreements");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("accountReference", accountReference);
		validationBean.setField("reasonCode", reasonCode);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateTransitionServiceAgreementResponse validateTransitionServiceAgreement(
			TransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceAgreementResponse response = new ValidateTransitionServiceAgreementResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		CustomerHierarchy customerHierarchy = parameter.getCustomerHierarchy();

		ValidationBean validationBean = new ValidationBean("transitionServiceAgreement");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("customerHierarchy", customerHierarchy);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateTransitionServiceEquipmentResponse validateTransitionServiceEquipment(
			TransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceEquipmentResponse response = new ValidateTransitionServiceEquipmentResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String oldServiceItemReference = parameter.getOldServiceItemReference();
		ServiceItem newServiceItem = parameter.getNewServiceItem();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("transitionServiceEquipment");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceAgreementReference", serviceAgreementReference);
		validationBean.setField("oldServiceItemReference", oldServiceItemReference);
		validationBean.setField("newServiceItem", newServiceItem);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateTransitionServiceEquipmentCompleteResponse validateTransitionServiceEquipmentComplete(
			TransitionServiceEquipmentComplete parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceEquipmentCompleteResponse response = new ValidateTransitionServiceEquipmentCompleteResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String oldServiceItemReference = parameter.getOldServiceItemReference();

		ValidationBean validationBean = new ValidationBean("transitionServiceEquipmentComplete");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceAgreementReference", serviceAgreementReference);
		validationBean.setField("oldServiceItemReference", oldServiceItemReference);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateTransitionServiceItemResponse validateTransitionServiceItem(
			TransitionServiceItem parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceItemResponse response = new ValidateTransitionServiceItemResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String oldServiceItemReference = parameter.getOldServiceItemReference();
		ServiceItem newServiceItem = parameter.getNewServiceItem();
		Date startDate = parameter.getStartDate();

		ValidationBean validationBean = new ValidationBean("transitionServiceItem");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceAgreementReference", serviceAgreementReference);
		validationBean.setField("oldServiceItemReference", oldServiceItemReference);
		validationBean.setField("newServiceItem", newServiceItem);
		validationBean.setField("startDate", startDate);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateUpdateContactsResponse validateUpdateContacts(UpdateContacts parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateUpdateContactsResponse response = new ValidateUpdateContactsResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		CorrectedContact cc = parameter.getCorrectedContact();

		if (cc == null || (cc.getPerson() == null && cc.getServiceAddress() == null
				&& cc.getEmailAddress() == null && cc.getPhonePrimary() == null
				&& cc.getPhoneSecondary() == null))
		{
			ValidationError ve = new ValidationError();
			ve.setErrorCode(WebServiceValidationException.VALIDATION_ERROR);
			ve.setMessage(
					"At least one update field (person, service address, email address, phone primary, or phone secondary) should be set");
			result = new ValidationResult();
			result.getValidationError().add(ve);
		}
		else
		{
			String transactionReference = parameter.getTransactionReference();
			String serviceAgreementReference = parameter.getServiceAgreementReference();
			String salesChannelName = parameter.getSalesChannelName();

			ValidationBean validationBean = new ValidationBean("updateContacts");
			validationBean.setField("transactionReference", transactionReference);
			validationBean.setField("serviceAgreementReference", serviceAgreementReference);
			validationBean.setField("salesChannelName", salesChannelName);
			validationBean.setField("correctedContact", cc);
			validate(result, validationBean);
		}

		response.setValidationResult(result);

		return response;
	}

	public ValidateUpdateEquipmentResponse validateUpdateEquipment(UpdateEquipment parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateUpdateEquipmentResponse response = new ValidateUpdateEquipmentResponse();
		ValidationResult result = new ValidationResult();

		validateWBHeader(result, wildBlueHeader);

		String transactionReference = parameter.getTransactionReference();
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String oldmacAddress = parameter.getOldMACAddress();
		String newmacAddress = parameter.getNewMACAddress();
		String modemSerialNumber = parameter.getModemSerialNumber();
		String triaSerialNumber = parameter.getTriaSerialNumber();

		ValidationBean validationBean = new ValidationBean("updateEquipment");
		validationBean.setField("transactionReference", transactionReference);
		validationBean.setField("serviceAgreementReference", serviceAgreementReference);
		validationBean.setField("oldMacAddress", oldmacAddress);
		validationBean.setField("newMacAddress", newmacAddress);
		validationBean.setField("modemSerialNumber", modemSerialNumber);
		validationBean.setField("triaSerialNumber", triaSerialNumber);
		validate(result, validationBean);

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	private void validateWBHeader(ValidationResult validationResult, WildBlueHeader wildBlueHeader)
	{
		ValidationBean validationBean = new ValidationBean("WildBlueHeader");
		InvokedBy invokedBy = (wildBlueHeader != null ? wildBlueHeader.getInvokedBy() : null);
		validationBean.setField("invokedBy", invokedBy);
		validate(validationResult, validationBean);
	}

	private void validate(ValidationResult validationResult, ValidationBean validationBean)
	{
		ValidatorTool validator = ValidatorTool.getInstance();
		List<ValidationError> ve = validator.perform(validationBean);

		if (ve != null && !ve.isEmpty())
			validationResult.getValidationError().addAll(ve);
	}
}
