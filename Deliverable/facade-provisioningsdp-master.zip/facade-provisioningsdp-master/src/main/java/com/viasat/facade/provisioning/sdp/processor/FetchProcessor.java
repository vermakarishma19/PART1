package com.viasat.facade.provisioning.sdp.processor;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.datatype.DatatypeConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.isp.api.model.IspAccount;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.DeviceProtocol;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.facade.provisioning.sdp.util.ServiceProviderFinder;
import com.viasat.facade.provisioning.sdp.wrapper.BusinessTransactionWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.CatalogWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ContactsWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ISPWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.SDPWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ServiceLocationWrapper;
import com.viasat.internalservice.contact.api.model.EmailAddressLight;
import com.viasat.internalservice.contact.api.model.PhoneNumberLights;
import com.viasat.internalservice.servicelocation.api.model.InstallationAttribute;
import com.viasat.internalservice.servicelocation.api.model.LegacyAttribute;
import com.viasat.internalservice.servicelocation.api.model.QoiMetric;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocationAggregate;
import com.viasat.sdp.api.data.FixedNTD;
import com.viasat.sdp.api.data.InstallationKey;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.Layer3ServiceState;
import com.viasat.sdp.api.data.ServiceArea;
import com.viasat.wildblue.common.commondata.AntennaLookAngles;
import com.viasat.wildblue.common.commondata.Beam;
import com.viasat.wildblue.common.commondata.BeamSalesInfo;
import com.viasat.wildblue.common.commondata.BeamTechnicalInfo;
import com.viasat.wildblue.common.commondata.Contact;
import com.viasat.wildblue.common.commondata.ContactInfo;
import com.viasat.wildblue.common.commondata.EquipmentType;
import com.viasat.wildblue.common.commondata.Person;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.contingency.AccountNotFoundException;
import com.viasat.wildblue.common.exception.contingency.CustomerNotFoundException;
import com.viasat.wildblue.common.exception.fault.WildBlueFaultException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.common.location.Address;
import com.viasat.wildblue.common.location.GeoPosition;
import com.viasat.wildblue.common.location.Location;
import com.viasat.wildblue.facade.provisioning.data.Account;
import com.viasat.wildblue.facade.provisioning.data.AccountContactMap;
import com.viasat.wildblue.facade.provisioning.data.Customer;
import com.viasat.wildblue.facade.provisioning.data.GetAccount;
import com.viasat.wildblue.facade.provisioning.data.GetAccountHierarchy;
import com.viasat.wildblue.facade.provisioning.data.GetAccountHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.GetAllServiceAgreementHierarchies;
import com.viasat.wildblue.facade.provisioning.data.GetAllServiceAgreementHierarchiesResponse;
import com.viasat.wildblue.facade.provisioning.data.GetContactsForAccounts;
import com.viasat.wildblue.facade.provisioning.data.GetContactsForAccountsResponse;
import com.viasat.wildblue.facade.provisioning.data.GetCustomer;
import com.viasat.wildblue.facade.provisioning.data.GetCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.GetCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.GetCustomerResponse;
import com.viasat.wildblue.facade.provisioning.data.GetProvisioningDetails;
import com.viasat.wildblue.facade.provisioning.data.GetProvisioningDetailsResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreementHierarchy;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreementHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceItem;
import com.viasat.wildblue.facade.provisioning.data.GetServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatus;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatusResponse;
import com.viasat.wildblue.facade.provisioning.data.ProvisioningDetails;
import com.viasat.wildblue.facade.provisioning.data.ServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.ServiceItem;
import com.viasat.wildblue.facade.provisioning.data.TargetSystemItemMap;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.DeviceType;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.DeviceTypeAttribute;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementDevice;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy;

public class FetchProcessor
{
	private static final Logger LOGGER = LoggerFactory.getLogger(FetchProcessor.class);

	public static final String PROVISIONING_ACTIVE_STATUS = "ACTIVE";
	public static final String PROVISIONING_DISCONNECTED_STATUS = "DISCONNECTED";
	public static final String PROVISIONING_PENDING_STATUS = "PENDING_ACTIVE";
	public static final String PROVISIONING_SUSPENDED_STATUS = "SUSPENDED";
	public static final String COUNTRY_CODE_TYPE = "USA";
	private static final String SB = "SB";

	private BusinessTransactionWrapper businessTransactionWrapper;
	private ContactsWrapper contactsWrapper;
	private ServiceLocationWrapper serviceLocationWrapper;
	private SDPWrapper sdpWrapper;
	private CatalogWrapper catalogWrapper;
	private ISPWrapper ispWrapper;

	public void setIspWrapper(ISPWrapper ispWrapper)
	{
		this.ispWrapper = ispWrapper;
	}

	// Changed this method as Phase 3a
	public Contact getContact(List<com.viasat.internalservice.contact.api.model.Contact> contacts)
	{
		Contact contact = null;
		try
		{
			ContactInfo contactInfo = new ContactInfo();

			if (contacts != null && contacts.size() > 0)
			{
				String firstName = contacts.get(0).getFirstName();
				String lastname = contacts.get(0).getLastName();
				String middleName = contacts.get(0).getMiddleName();
				String suffix = contacts.get(0).getSuffix();
				Person person = new Person();
				person.setFirstName(firstName);
				person.setLastName(lastname);
				if (middleName != null)
				{
					person.setMiddleName(middleName);
				}
				if (suffix != null)
				{
					person.setSuffix(suffix);
				}
				if (contacts.get(0).getContactRoles() != null
						&& contacts.get(0).getContactRoles().size() > 0)
				{
					String contactType = contacts.get(0).getContactRoles().get(0)
							.getContactRoleType();
					contactInfo.setContactType(getContactType(contactType));
				}
				ArrayList<EmailAddressLight> Email = contacts.get(0).getEmailAddresses();
				if (Email != null)
				{
					contactInfo.setEmailAddress(Email.get(0).getEmailAddress());
				}
				PhoneNumberLights phone = contacts.get(0).getPhoneNumbers();
				if (phone != null)
				{
					contactInfo.setPrimaryPhone(phone.get(0).getPrimaryPhoneNumber());
				}

				if (phone.get(0).getSecondaryPhoneNumber() != null)
					contactInfo.setSecondaryPhone(phone.get(0).getSecondaryPhoneNumber());
				else
					contactInfo.setSecondaryPhone(null);

				Address Add = new Address();

				// Country code
				String countryCode = contacts.get(0).getPostalAddresses().get(0).getCountryCode();

				if (countryCode.equals(SdpConstants.COUNTRY_CODE))
				{
					Add.setCountryCode(COUNTRY_CODE_TYPE);
				}
				else
				{
					Add.setCountryCode(countryCode);
				}

				Add.setMunicipality(contacts.get(0).getPostalAddresses().get(0).getMunicipality());
				Add.setPostalCode(contacts.get(0).getPostalAddresses().get(0).getPostalCode());
				Add.setRegion(contacts.get(0).getPostalAddresses().get(0).getRegion());
				String addressLine1 = contacts.get(0).getPostalAddresses().get(0).getAddressLine1();
				String addressLine2 = contacts.get(0).getPostalAddresses().get(0).getAddressLine2();
				Add.getAddressLine().add(addressLine1);
				if (addressLine2 != null)
				{
					Add.getAddressLine().add(addressLine2);
				}
				Location location = new Location();
				location.setAddress(Add);
				contactInfo.setLocation(location);

				// Setting Person and Contact Info.
				contact = new Contact();
				contact.setPerson(person);
				contact.setContactInfo(contactInfo);
				return contact;
			}
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException("Error getting contactInfo: " + e.getMessage(), e);
		}
		return contact;
	}

	public static String getContactType(String contactType)
	{
		switch (contactType)
		{
		case ContactsWrapper.CUSTOMER_CONTACT_ROLE_TYPE:
			contactType = SdpConstants.CONTACT_TYPE_CUSTOMER;
			break;

		case ContactsWrapper.ACCOUNT_CONTACT_ROLE_TYPE:
			contactType = SdpConstants.CONTACT_TYPE_ACCOUNT;
			break;
		case ContactsWrapper.SERVICE_AGREEMENT_CONTACT_ROLE_TYPE:
			contactType = SdpConstants.CONTACT_TYPE_SERVICE;
			break;
		default:
			break;
		}
		return contactType;
	}

	public GetCustomerResponse getCustomer(GetCustomer parameter) throws WebServiceException
	{
		try
		{
			String customerReference = parameter.getCustomerReference();
			Customer customer = null;
			List<AccountHierarchy> accountHierarchies = null;
			com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustomerHierarchy = businessTransactionWrapper
					.getCustomerHierarchyByInternalReference(customerReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			if (null != btsCustomerHierarchy)
			{
				String serviceProviderName = ServiceProviderFinder
						.getServiceProviderNameFromBusinessTransactionCustomerHierarchy(
								btsCustomerHierarchy);

				String serviceAgreementRef = null;
				accountHierarchies = btsCustomerHierarchy.getAccounts();

				if (accountHierarchies != null && !accountHierarchies.isEmpty())
				{
					for (com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy accountHierarchy : accountHierarchies)
					{
						List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchies = accountHierarchy
								.getServiceAgreements();

						if (null != serviceAgreementHierarchies
								&& !serviceAgreementHierarchies.isEmpty())
						{
							for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
							{
								if (!SB.equals(serviceAgreementHierarchy.getDeviceProtocol()))
								{
									serviceAgreementRef = serviceAgreementHierarchy
											.getServiceAgreementReference();
								}
							}
						}
					}
				}

				if (serviceAgreementRef != null && !serviceAgreementRef.isEmpty())
				{
					customer = new Customer();
					customer.setCustomerReference(customerReference);
					customer.setCustomerType(btsCustomerHierarchy.getCustomerTypeName());

					customer.setServiceProviderType(serviceProviderName);
					String accountRef = accountHierarchies.get(0).getAccountReference();
					List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
							.getCustomerContacts(accountRef, null, null);
					String businessName = contacts.get(0).getBusinessName();
					if (businessName != null)
					{
						customer.setBusinessName(businessName);
					}

					customer.setCustomerContact(getContact(contacts));
				}
			}

			if (null == customer)
			{
				throw new CustomerNotFoundException(null, customerReference);
			}
			GetCustomerResponse response = new GetCustomerResponse();
			response.setCustomer(customer);
			return response;
		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException("Error getting customer: " + e.getMessage(), e);
		}
	}

	public com.viasat.wildblue.facade.provisioning.data.GetAccountResponse getAccount(
			GetAccount parameter, String contactType) throws WebServiceException
	{
		try
		{
			String accountRef = parameter.getAccountReference();
			com.viasat.wildblue.facade.provisioning.data.Account account = null;
			com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy = businessTransactionWrapper
					.getAccountHierarchyByInternalReference(accountRef,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			if (null != btsAccountHierarchy)
			{
				String serviceProviderName = ServiceProviderFinder
						.getServiceProviderNameFromBusinessTransactionAccountHierarchy(
								btsAccountHierarchy);
				String serviceAgreementRef = null;
				List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
						.getServiceAgreements();

				for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
				{
					// use the last service agreement that is SB2, we really
					// just
					// want the contact.
					if (DeviceProtocol.SB2.equals(
							DeviceProtocol.valueOf(serviceAgreementHierarchy.getDeviceProtocol())))
					{
						serviceAgreementRef = serviceAgreementHierarchy
								.getServiceAgreementReference();
					}
				}

				if (serviceAgreementRef != null && !"".equals(serviceAgreementRef))
				{

					account = new Account();
					account.setAccountReference(accountRef);
					List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
							.getAccountContacts(accountRef, null, null);
					account.setAccountContact(getContact(contacts));
					account.setAccountType(getAccountType(serviceProviderName));

				}
			}

			if (null == account)
			{
				throw new AccountNotFoundException(null, accountRef,
						"Account does not exist in volubill database");
			}

			com.viasat.wildblue.facade.provisioning.data.GetAccountResponse response = new com.viasat.wildblue.facade.provisioning.data.GetAccountResponse();
			response.setAccount(account);
			return response;
		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException("Error getting account: " + e.getMessage(), e);
		}
	}

	public GetContactsForAccountsResponse getContactsForAccounts(GetContactsForAccounts parameter)
			throws WebServiceException
	{
		// Maybe there is a way to do this by a query into VB but this is the
		// only way for now...
		GetContactsForAccountsResponse response = null;
		List<String> accountRefs = null;
		try
		{
			response = new GetContactsForAccountsResponse();
			accountRefs = parameter.getAccountReferences();

			for (String accountRef : accountRefs)
			{
				Account account = null;

				GetAccount getAccount = new GetAccount();
				getAccount.setAccountReference(accountRef);
				com.viasat.wildblue.facade.provisioning.data.GetAccountResponse getAccountResponse = getAccount(
						getAccount, SdpConstants.CONTACT_TYPE_SERVICE);
				account = getAccountResponse.getAccount();

				if (account != null)
				{
					AccountContactMap accountContactMap = new AccountContactMap();
					accountContactMap.setAccountReference(accountRef);
					accountContactMap.setAccountContact(account.getAccountContact());

					AccountHierarchy accountHierarchy = businessTransactionWrapper
							.getAccountHierarchyByInternalReference(accountRef,
									ConfigurationConstants.COMMON_WILDBLUE_HEADER);

					List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
							.getServiceAgreementContacts(accountHierarchy.getServiceAgreements()
									.get(0).getServiceAgreementReference(), null, null);
					accountContactMap.setAccountContact(getContact(contacts));

					response.getAccountContactMaps().add(accountContactMap);
				}
			}

		}
		catch (WebServiceException e)
		{
			LOGGER.warn("Could not find contact information for WB account " + accountRefs
					+ " in Volubill (Note: Volubill account number is WB serviceAgreementReference)");
		}
		return response;
	}

	public GetProvisioningDetailsResponse getProvisioningDetails(GetProvisioningDetails parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ProvisioningDetails provisioningDetails = null;
		String customerCode = null;
		String modemType = null;
		String triaType = null;
		String serviceLevel = null;

		String serviceAgreementReference = parameter.getServiceAgreementReference();
		ServiceAgreementHierarchy btsServiceAgreementHier = businessTransactionWrapper
				.getServiceAgreementHierarchyFromInternalServiceAgreementReference(
						serviceAgreementReference, wildBlueHeader);
		String accountReference = btsServiceAgreementHier.getAccountReference();
		com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustomertHier = null;

		btsCustomertHier = businessTransactionWrapper
				.getCustomerHierarchyByInternalServiceAgreementReference(serviceAgreementReference,
						wildBlueHeader);

		String serviceProviderName = ServiceProviderFinder
				.getServiceProviderNameFromBusinessTransactionCustomerHierarchy(btsCustomertHier);

		if (null != btsServiceAgreementHier)
		{

			provisioningDetails = new ProvisioningDetails();
			provisioningDetails.setAccountReference(accountReference);
			provisioningDetails.setServiceAgreementReference(serviceAgreementReference);
			provisioningDetails.setIspCode(serviceProviderName);
			provisioningDetails.setStartDate(btsCustomertHier.getCreateDate());
			// code for getServiceProvisioningStatus-Stub-change when
			// getProvisioningStatus is complete
			GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = null;
			GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
			getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementReference);

			getServiceProvisioningStatusResponse = getServiceProvisioningStatus(
					getServiceProvisioningStatus, wildBlueHeader);

			provisioningDetails
					.setStatus(getServiceProvisioningStatusResponse.getServiceProvisioningStatus());
			if (getServiceProvisioningStatusResponse != null)
			{

				// FixedNTD
				FixedNTD fixedNTD = sdpWrapper.getFixedNTD(serviceAgreementReference);
				provisioningDetails.setMACAddress(fixedNTD.getMacAddress());
				if (fixedNTD != null)
				{
					// ServiceArea
					String serviceAreaId = fixedNTD.getConfiguration().getCsaId();
					ServiceArea serviceArea = sdpWrapper.getServiceArea(serviceAreaId);
					if (serviceArea != null)
					{

						Beam beamInfo = setBeamInfo(provisioningDetails.getBeamInfo());
						if (serviceArea.getInstallationKeys().getInstallationKey() != null)
						{
							InstallationKey latestKey = null;
							Date now = new Date();
							for (InstallationKey installKey : serviceArea.getInstallationKeys()
									.getInstallationKey())
							{
								// equal to or before now
								if (installKey.getAsOf().compareTo(now) <= 0)
								{
									if (latestKey == null)
										latestKey = installKey;
									else if (installKey.getAsOf().after(latestKey.getAsOf()))
										latestKey = installKey;
								}
							}
							if (latestKey != null)
								beamInfo.getBeamTechnicalInfo()
										.setModemInstallCode(latestKey.getKey());
						}

						modemType = getModemType(
								btsServiceAgreementHier.getServiceAgreementDevice(),
								provisioningDetails.getStatus());
						triaType = getTriaType(btsServiceAgreementHier.getServiceAgreementDevice(),
								provisioningDetails.getStatus());

						if (beamInfo != null)
						{
							BeamTechnicalInfo beamTechnicalInfo = beamInfo.getBeamTechnicalInfo();

							if (beamTechnicalInfo != null)
							{
								// beamInfo.getBeamTechnicalInfo().setCustomerCode(customerCode);

								EquipmentType equipmentType = new EquipmentType();
								equipmentType.setModemType(modemType);
								equipmentType.setTriaType(triaType);

								beamTechnicalInfo.setEquipmentType(equipmentType);
								beamInfo.setBeamTechnicalInfo(beamTechnicalInfo);
							}

							BeamSalesInfo beamSalesInfo = beamInfo.getBeamSalesInfo();
							if (beamSalesInfo != null)
							{
								beamInfo.setBeamSalesInfo(beamSalesInfo);
							}
						}
						serviceLevel = getServiceLevel(btsServiceAgreementHier);
						provisioningDetails.setServiceLevel(serviceLevel);
						List<ServiceLocationAggregate> serviceLocationAggregates = serviceLocationWrapper
								.getProvisioningDetailsServiceLocation(
										parameter.getServiceAgreementReference());
						if (serviceLocationAggregates != null)
						{
							InstallationAttribute installationAttribute = null;
							installationAttribute = (serviceLocationAggregates.get(0)
									.getInstallationAttributes() != null
									&& serviceLocationAggregates.get(0).getInstallationAttributes()
											.size() > 0)
													? serviceLocationAggregates.get(0)
															.getInstallationAttributes().get(0)
													: null;

							LegacyAttribute legacyAttribute = null;
							legacyAttribute = (serviceLocationAggregates.get(0)
									.getLegacyAttributes() != null
									&& serviceLocationAggregates.get(0).getLegacyAttributes()
											.size() > 0)
													? serviceLocationAggregates.get(0)
															.getLegacyAttributes().get(0)
													: null;

							QoiMetric qoiMetric = null;
							qoiMetric = (serviceLocationAggregates.get(0).getQoiMetrics() != null
									&& serviceLocationAggregates.get(0).getQoiMetrics().size() > 0)
											? serviceLocationAggregates.get(0).getQoiMetrics()
													.get(0)
											: null;

							if (getBeamInfoData(beamInfo, installationAttribute,
									legacyAttribute) != null)
								provisioningDetails.setBeamInfo(getBeamInfoData(beamInfo,
										installationAttribute, legacyAttribute));
							if (installationAttribute.getDesiredSatelliteName() != null)
								provisioningDetails.setDesiredSatelliteName(
										installationAttribute.getDesiredSatelliteName());
							if (installationAttribute.getInstallerId() != null)
								provisioningDetails
										.setInstallerId(installationAttribute.getInstallerId());
							if (installationAttribute.getCustomerCode() != null)
								provisioningDetails.setInstallationLogin(
										installationAttribute.getCustomerCode());
							if (legacyAttribute.getIspPassword() != null)
								provisioningDetails
										.setInstallationPassword(legacyAttribute.getIspPassword());
							if (legacyAttribute.getModemSerialNumber() != null)
								provisioningDetails.setModemSerialNumber(
										legacyAttribute.getModemSerialNumber());
							if (legacyAttribute.getTriaSerialNumber() != null)
								provisioningDetails
										.setTransceiverID(legacyAttribute.getTriaSerialNumber());
							if (qoiMetric != null)
							{
								BigDecimal qoiAttempts = qoiMetric.getQoiAttempts();
								if (qoiAttempts != null)
									provisioningDetails.setQoiAttempts(qoiAttempts.toString());

								String qoiFinishTime = qoiMetric.getQoiFinishTime().toString();
								if (qoiFinishTime != null)
									provisioningDetails.setQoiFinishTime(qoiFinishTime);

								String qoiStartTime = qoiMetric.getQoiStartTime().toString();
								if (qoiStartTime != null)
									provisioningDetails.setQoiStartTime(qoiStartTime);

								if (qoiMetric != null)
									provisioningDetails.setQoiStatus(qoiMetric.getQoiStatus());
							}
						}

					}

				}
			}

		}
		GetProvisioningDetailsResponse response = new GetProvisioningDetailsResponse();
		response.setProvisioningDetails(provisioningDetails);
		return response;
	}

	private String getServiceLevel(ServiceAgreementHierarchy btsServiceAgreementHier)
	{
		String serviceLevel = null;
		List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem> serviceItems = btsServiceAgreementHier
				.getServiceItems();
		for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem serviceItem : serviceItems)
		{
			if (serviceItem.getExternalSystemName().equals(SdpConstants.INTERNET_ACCESS_SERVICE))
			{
				serviceLevel = serviceItem.getExternalSystemName();
			}
		}
		return serviceLevel;
	}

	private Beam setBeamInfo(Beam beam)
	{
		if (beam == null)
		{
			beam = new Beam();
		}
		BeamTechnicalInfo beamTechnicalInfo = beam.getBeamTechnicalInfo();

		if (beamTechnicalInfo == null)
		{
			beamTechnicalInfo = new BeamTechnicalInfo();
			beam.setBeamTechnicalInfo(beamTechnicalInfo);
		}

		AntennaLookAngles antennaLookAngles = beamTechnicalInfo.getAntennaLookAngles();

		if (antennaLookAngles == null)
		{
			antennaLookAngles = new AntennaLookAngles();
			beamTechnicalInfo.setAntennaLookAngles(antennaLookAngles);
		}

		BeamSalesInfo beamSalesInfo = beam.getBeamSalesInfo();

		if (beamSalesInfo == null)
		{
			beamSalesInfo = new BeamSalesInfo();
			beam.setBeamSalesInfo(beamSalesInfo);
		}

		return beam;
	}

	public Beam getBeamInfoData(Beam beamInfo, InstallationAttribute installationAttribute,
			LegacyAttribute legacyAttribute)
	{
		BeamTechnicalInfo beamTechnicalInfo = new BeamTechnicalInfo();
		BeamSalesInfo beamSalesInfo = new BeamSalesInfo();
		AntennaLookAngles antennaLookAngles = new AntennaLookAngles();

		try
		{

			if (installationAttribute != null)
			{

				if (installationAttribute.getAntennaPointingAid() != null)
					beamTechnicalInfo
							.setAntennaPointingAid(installationAttribute.getAntennaPointingAid());

				if (installationAttribute.getAzimuth() != null)
					antennaLookAngles
							.setAzimuth(Double.valueOf(installationAttribute.getAzimuth()));

				if (installationAttribute.getBeamNumber() != null)
					beamTechnicalInfo
							.setBeamNumber(installationAttribute.getBeamNumber().toBigInteger());

				if (installationAttribute.getBoomArmAngle() != null)
					antennaLookAngles.setBoomArmAngle(
							Double.valueOf(installationAttribute.getBoomArmAngle()));

				if (installationAttribute.getElevation() != null)
					antennaLookAngles
							.setElevation(Double.valueOf(installationAttribute.getElevation()));

				if (installationAttribute.getSatelliteName() != null)
					beamTechnicalInfo.setSatelliteName(installationAttribute.getSatelliteName());

				if (installationAttribute.getSkew() != null)
					antennaLookAngles.setSkew(Double.valueOf(installationAttribute.getSkew()));

				if (installationAttribute.getPolarization() != null)
					beamTechnicalInfo.setPolarization(installationAttribute.getPolarization());

				if (installationAttribute.getCustomerCode() != null)
					beamTechnicalInfo.setCustomerCode(installationAttribute.getCustomerCode());
			}
			// LegacyAttributes
			if (legacyAttribute != null)
			{
				if (legacyAttribute.getGatewayNumber() != null)
					beamTechnicalInfo.setGatewayId(legacyAttribute.getGatewayNumber());

				if (legacyAttribute.getGatewayName() != null)
					beamTechnicalInfo.setGatewayName(legacyAttribute.getGatewayName());
			}
			beamTechnicalInfo.setAntennaLookAngles(antennaLookAngles);
			/* Uncomment once the testcases are fixed for getServiceAgreement */
			beamTechnicalInfo.setEquipmentType(beamInfo.getBeamTechnicalInfo().getEquipmentType());
			beamTechnicalInfo
					.setModemInstallCode(beamInfo.getBeamTechnicalInfo().getModemInstallCode());
			beamInfo.setBeamSalesInfo(beamInfo.getBeamSalesInfo());
			/* Uncomment once the testcases are fixed for getServiceAgreement */
			beamInfo.setBeamTechnicalInfo(beamTechnicalInfo);
		}
		catch (Exception e)
		{
			throw new WildBlueFaultException("Error getting Beam Info: " + e.getMessage(), e);
		}
		return beamInfo;
	}

	private String getModemType(List<ServiceAgreementDevice> serviceAgreementDevices,
			String acctStatus)
	{
		String modemType = null;

		// Get modem type list
		List<ServiceAgreementDevice> modemTypeList = new ArrayList<ServiceAgreementDevice>();

		for (ServiceAgreementDevice saDevice : serviceAgreementDevices)
		{
			DeviceType deviceType = saDevice.getDeviceType();
			if (deviceType != null)
			{
				for (DeviceTypeAttribute deviceAttr : deviceType.getDeviceTypeAttribute())
				{
					if ("DEVICE_CATEGORY".equals(deviceAttr.getAttributeName())
							&& "MODEM".equals(deviceAttr.getAttributeValue()))
					{
						modemTypeList.add(saDevice);
						break;
					}
				}
			}
		}

		// if there's only one, return it; else return the most recent
		if (modemTypeList.size() == 1)
		{
			modemType = modemTypeList.get(0).getDeviceType().getDeviceType();
		}
		else if (modemTypeList.size() > 1)
		{
			ServiceAgreementDevice latestModemDevice = null;

			String status = null;
			if (acctStatus.equals(PROVISIONING_PENDING_STATUS))
			{
				status = "PENDING";
			}
			else if (acctStatus.equals(PROVISIONING_ACTIVE_STATUS)
					|| acctStatus.equals(PROVISIONING_SUSPENDED_STATUS))
			{
				status = PROVISIONING_ACTIVE_STATUS;
			}

			for (ServiceAgreementDevice modemTypeDevice : modemTypeList)
			{
				String deviceStatus = modemTypeDevice.getDeviceStatus();

				if (acctStatus.equals(PROVISIONING_DISCONNECTED_STATUS))
				{
					if ("CANCELLED".equals(deviceStatus) || "INACTIVE".equals(deviceStatus))
					{
						status = deviceStatus;
					}
				}

				if (deviceStatus.equals(status))
				{
					if (latestModemDevice == null)
					{
						latestModemDevice = modemTypeDevice;
					}
					// determine which is more recent
					else
					{
						// first compare dates
						int compareDates = modemTypeDevice.getCreateDate()
								.compareTo(latestModemDevice.getCreateDate());
						if (compareDates == DatatypeConstants.GREATER)
						{
							latestModemDevice = modemTypeDevice;
						}
						// if dates are equal compare serviceAgreementDeviceRefs
						else if (compareDates == DatatypeConstants.EQUAL)
						{
							BigInteger modemTypeDeviceRef = new BigInteger(
									modemTypeDevice.getServiceAgreementDeviceReference());
							BigInteger latestDeviceRef = new BigInteger(
									latestModemDevice.getServiceAgreementDeviceReference());

							if (modemTypeDeviceRef
									.compareTo(latestDeviceRef) == DatatypeConstants.GREATER)
							{
								latestModemDevice = modemTypeDevice;
							}
						}
					}
				}
			}

			if (latestModemDevice == null)
			{
				modemType = "MODEM_TYPE_NOT_FOUND";
			}
			else
			{
				modemType = latestModemDevice.getDeviceType().getDeviceType();
			}

		}

		return modemType;
	}

	private String getTriaType(List<ServiceAgreementDevice> serviceAgreementDevices,
			String acctStatus)
	{
		String triaType = null;

		// Get list tria types
		List<ServiceAgreementDevice> triaTypeList = new ArrayList<ServiceAgreementDevice>();

		for (ServiceAgreementDevice saDevice : serviceAgreementDevices)
		{
			DeviceType deviceType = saDevice.getDeviceType();
			if (deviceType != null)
			{
				for (DeviceTypeAttribute deviceAttr : deviceType.getDeviceTypeAttribute())
				{
					if ("DEVICE_CATEGORY".equals(deviceAttr.getAttributeName())
							&& "TRIA".equals(deviceAttr.getAttributeValue()))
					{
						triaTypeList.add(saDevice);
						break;
					}
				}
			}
		}

		// if there's only one, return it; else return the most recent
		if (triaTypeList.size() == 1)
		{
			triaType = triaTypeList.get(0).getDeviceType().getDeviceType();
		}
		else if (triaTypeList.size() > 1)
		{
			ServiceAgreementDevice latestTriaDevice = null;

			String status = null;
			if (acctStatus.equals(PROVISIONING_PENDING_STATUS))
			{
				status = "PENDING";
			}
			else if (acctStatus.equals(PROVISIONING_ACTIVE_STATUS)
					|| acctStatus.equals(PROVISIONING_SUSPENDED_STATUS))
			{
				status = "ACTIVE";
			}

			for (ServiceAgreementDevice triaTypeDevice : triaTypeList)
			{
				String deviceStatus = triaTypeDevice.getDeviceStatus();

				if (acctStatus.equals(PROVISIONING_DISCONNECTED_STATUS))
				{
					if ("CANCELLED".equals(deviceStatus) || "INACTIVE".equals(deviceStatus))
					{
						status = deviceStatus;
					}
				}

				if (deviceStatus.equals(status))
				{
					if (latestTriaDevice == null)
					{
						latestTriaDevice = triaTypeDevice;
					}
					// determine which is more recent
					else
					{
						// first compare dates
						int compareDates = triaTypeDevice.getCreateDate()
								.compareTo(latestTriaDevice.getCreateDate());
						if (compareDates == DatatypeConstants.GREATER)
						{
							latestTriaDevice = triaTypeDevice;
						}
						// if dates are equal compare serviceAgreementDeviceRefs
						else if (compareDates == DatatypeConstants.EQUAL)
						{
							BigInteger triaTypeDeviceRef = new BigInteger(
									triaTypeDevice.getServiceAgreementDeviceReference());
							BigInteger latestDeviceRef = new BigInteger(
									latestTriaDevice.getServiceAgreementDeviceReference());

							if (triaTypeDeviceRef
									.compareTo(latestDeviceRef) == DatatypeConstants.GREATER)
							{
								latestTriaDevice = triaTypeDevice;
							}
						}
					}
				}
			}

			if (latestTriaDevice == null)
			{
				triaType = "TRIA_TYPE_NOT_FOUND";
			}
			else
			{
				triaType = latestTriaDevice.getDeviceType().getDeviceType();
			}

		}

		return triaType;
	}
	// Written this method to make code more reusable .

	public Layer3Service getLayer3ServiceForInternet(
			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy,
			GetComponentsResponse getComponentsResponse) throws WebServiceException
	{

		Layer3Service layer3Service = null;

		CatalogComponent internetComponent = getComponentsResponse.getComponents().stream()
				.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE.equals(c.getComponentType()))
				.findFirst().orElse(null);

		String internetMCR = internetComponent.getCharges().get(0).getMasterCatalogReference();

		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = serviceAgreementHierarchy
				.getServiceItems().stream() // for each serviceItem
				.filter(serviceItem -> internetMCR.equals(serviceItem.getMasterCatalogKey()))
				.findFirst().orElse(null);

		layer3Service = sdpWrapper.getLayer3Service(internetSvcItem.getServiceItemReference());

		return layer3Service;
	}

	public String getServiceProvisioningStatus(GetComponentsResponse getComponentsResponse,
			Layer3Service layer3Service, GetServiceProvisioningStatus parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		String serviceStatus = null;
		if (getComponentsResponse != null && layer3Service != null)
		{

			String state = null;
			CatalogComponent internetComponent = getComponentsResponse.getComponents().stream()
					.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE.equals(c.getComponentType()))
					.findFirst().orElse(null);

			state = layer3Service.getState().toString();

			// get the suspend package target system value from catalog
			// component
			String suspendPackage = internetComponent.getCharges().get(0)
					.getTargetSystemReferences().stream()
					.filter(tsr -> SdpConstants.SDP_SUSPEND_PACKAGE
							.equals(tsr.getTargetSystemXref()))
					.map(tsr -> tsr.getTargetSystemXrefValue()).findFirst().orElse(null);

			if (state != null)
			{

				if (state.equals(SdpConstants.PENDING) || state.equals(SdpConstants.DEACTIVATING)
						|| state.equals(SdpConstants.DEACTIVATED))
				{
					serviceStatus = state;
					return serviceStatus;

				}
				else if (suspendPackage
						.equals(layer3Service.getConfiguration().getServiceCatalogId()))
				{
					return SdpConstants.SUSPENDED;
				}
				else
				{
					return SdpConstants.ACTIVE;
				}
			}
		}
		else
		{
			getServiceProvisioningStatus(parameter, wildBlueHeader);
		}

		return serviceStatus;

	}

	public GetServiceProvisioningStatusResponse getServiceProvisioningStatus(
			GetServiceProvisioningStatus parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		try
		{
			List<AccountHierarchy> accountHierarchies = null;
			Layer3Service layer3Service = null;
			GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = new GetServiceProvisioningStatusResponse();
			String serviceAgreementRef = parameter.getServiceAgreementReference();
			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchies = null;

			com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustomerHierarchy = businessTransactionWrapper
					.getCustomerHierarchyByInternalServiceAgreementReference(serviceAgreementRef,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			accountHierarchies = btsCustomerHierarchy.getAccounts();
			String state = null;

			for (AccountHierarchy accountHierarchy : accountHierarchies)
			{
				serviceAgreementHierarchies = accountHierarchy.getServiceAgreements();
				for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreement : serviceAgreementHierarchies)
				{

					List<String> catalogRefs = serviceAgreement.getServiceItems().stream()
							.map(si -> {
								return si.getMasterCatalogKey();
							}).collect(Collectors.toList());

					GetComponentsResponse getComponentsResponse = catalogWrapper
							.getComponents(catalogRefs, wildBlueHeader);

					CatalogComponent internetComponent = getComponentsResponse.getComponents()
							.stream().filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE
									.equals(c.getComponentType()))
							.findFirst().orElse(null);

					String internetMCR = internetComponent.getCharges().get(0)
							.getMasterCatalogReference();

					com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = serviceAgreement
							.getServiceItems().stream() // for each serviceItem
							.filter(serviceItem -> internetMCR
									.equals(serviceItem.getMasterCatalogKey()))
							.findFirst().orElse(null);

					layer3Service = sdpWrapper
							.getLayer3Service(internetSvcItem.getServiceItemReference());
					state = layer3Service.getState().toString();

					// get the suspend package target system value from catalog
					// component
					String suspendPackage = internetComponent.getCharges().get(0)
							.getTargetSystemReferences().stream()
							.filter(tsr -> SdpConstants.SDP_SUSPEND_PACKAGE
									.equals(tsr.getTargetSystemXref()))
							.map(tsr -> tsr.getTargetSystemXrefValue()).findFirst().orElse(null);

					if (state != null)
					{

						if (state.equals(SdpConstants.PENDING)
								|| state.equals(SdpConstants.DEACTIVATING)
								|| state.equals(SdpConstants.DEACTIVATED))
						{
							getServiceProvisioningStatusResponse
									.setServiceProvisioningStatus(state.toString());

						}
						else if (suspendPackage
								.equals(layer3Service.getConfiguration().getServiceCatalogId()))
						{
							getServiceProvisioningStatusResponse
									.setServiceProvisioningStatus(SdpConstants.SUSPENDED);
						}
						else
						{
							getServiceProvisioningStatusResponse
									.setServiceProvisioningStatus(SdpConstants.ACTIVE);
						}

					}

					TargetSystemItemMap targetSystemItemMap = new TargetSystemItemMap();
					targetSystemItemMap.setMasterCatalogReference(internetMCR);
					getServiceProvisioningStatusResponse
							.setServiceAgreementReference(serviceAgreementRef);
					getServiceProvisioningStatusResponse.setInternetAccessServiceItemReference(
							internetSvcItem.getServiceItemReference());
					getServiceProvisioningStatusResponse.getTargetSystemItemMap()
							.add(targetSystemItemMap);

				}
			}

			return getServiceProvisioningStatusResponse;
		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException(
					"Error getting Provisioning Status : " + e.getMessage(), e);
		}
	}

	public GetServiceItemResponse getSeviceItem(GetServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		List<AccountHierarchy> accountHierarchies = null;
		String masterCaltalogKey = null;
		String status = null;
		List<CatalogComponent> catalogComponents = null;
		String componentType = null;
		GetServiceItemResponse getServiceItemResponse = new GetServiceItemResponse();
		ServiceItem srvcItem = new ServiceItem();
		// List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy>
		// serviceAgreementHierarchy = null;
		try
		{

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy = businessTransactionWrapper
					.getServiceAgreementHierarchyFromInternalServiceItemReference(
							parameter.getServiceItemReference(),
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem> serviceItems = serviceAgreementHierarchy
					.getServiceItems();
			String serviceAgreementRef = serviceAgreementHierarchy.getServiceAgreementReference();
			for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem serviceItem : serviceItems)
			{
				String serviceId = parameter.getServiceItemReference();
				if (serviceItem.getServiceItemReference().equals(serviceId))
				{
					masterCaltalogKey = serviceItem.getMasterCatalogKey();
					GetComponentsResponse getComponentsResponse = null;

					getComponentsResponse = catalogWrapper.getComponent(masterCaltalogKey,
							wildBlueHeader);

					if (getComponentsResponse != null)
						catalogComponents = getComponentsResponse.getComponents();

					for (CatalogComponent catalogComponent : catalogComponents)
					{
						componentType = catalogComponent.getComponentType();
						srvcItem.setServiceAgreementReference(serviceAgreementRef);
						srvcItem.setServiceItemReference(serviceId);
						srvcItem.setName(catalogComponent.getDisplayName());
						srvcItem.setType(catalogComponent.getComponentType());
						srvcItem.setCatalogNumber(masterCaltalogKey);

						if ((componentType != null && componentType.trim().length() > 0
								&& componentType.equals(SdpConstants.INTERNET_ACCESS_SERVICE)
						/*
						 * && (serviceItem.getItemDisplayName()
						 * .equals(SdpConstants.INTERNET_ACCESS_SERVICE))
						 */) || (componentType != null && componentType.trim().length() > 0
								&& componentType.equals(SdpConstants.VOIP)
						/*
						 * && (serviceItem.getItemDisplayName()
						 * .equals(SdpConstants.VOIP))
						 */))
						{
							Layer3Service layer3Service = sdpWrapper.getLayer3Service(serviceId);

							if (layer3Service != null)
							{

								GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = null;
								GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
								getServiceProvisioningStatus.setServiceAgreementReference(
										serviceItem.getServiceAgreementReference());
								String provisioningStatus = getServiceProvisioningStatus(
										getComponentsResponse, layer3Service,
										getServiceProvisioningStatus, wildBlueHeader);
								srvcItem.setStatus(provisioningStatus);
								srvcItem.setStartDate(layer3Service.getConfiguration().getDate());
							}

						}
						if (componentType != null && componentType.trim().length() > 0
								&& componentType.equals(SdpConstants.ISP_SERVICE) && (serviceItem
										.getItemDisplayName().equals(SdpConstants.ISP_SERVICE)))
						{
							BigDecimal getIspAccount = new BigDecimal(
									serviceItem.getServiceAgreementReference());
							IspAccount ispAccount = ispWrapper.getIspAccount(getIspAccount);
							String statusCode = ispAccount.getStatusCode();
							srvcItem.setStatus(statusCode);
							if (ispAccount != null)
							{
								List<ServiceLocationAggregate> serviceLocationAggregates = serviceLocationWrapper
										.getProvisioningDetailsServiceLocation(
												serviceItem.getServiceAgreementReference());
								if (serviceLocationAggregates != null)
								{
									for (int i = 0; i < serviceLocationAggregates.size(); i++)
									{
										srvcItem.setSelfCareLoginName(serviceLocationAggregates
												.get(i).getLegacyAttributes().get(i)
												.getIspUsername());
										srvcItem.setSelfCarePassword(serviceLocationAggregates
												.get(i).getLegacyAttributes().get(i)
												.getIspPassword());
									}
								}
							}
						}
					}
				}
			}
			if (srvcItem != null)
				getServiceItemResponse.setServiceItem(srvcItem);
		}
		catch (

		WebServiceException e)
		{
			e.printStackTrace();
			throw new WildBlueFaultException("Error getting Service Item : " + e.getMessage(), e);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new WildBlueFaultException("Error getting Service Item : " + e.getMessage(), e);
		}

		return getServiceItemResponse;
	}

	public void setCatalogWrapper(CatalogWrapper catalogWrapper)
	{
		this.catalogWrapper = catalogWrapper;
	}

	public void setContactsWrapper(ContactsWrapper contactsWrapper)
	{
		this.contactsWrapper = contactsWrapper;
	}

	public void setServiceLocationWrapper(ServiceLocationWrapper serviceLocationWrapper)
	{
		this.serviceLocationWrapper = serviceLocationWrapper;
	}

	public void setSdpWrapper(SDPWrapper sdpWrapper)
	{
		this.sdpWrapper = sdpWrapper;
	}

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.businessTransactionWrapper = businessTransactionWrapper;
	}

	public GetServiceAgreementHierarchyResponse getServiceAgreementHierarchy(
			GetServiceAgreementHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetServiceAgreementHierarchyResponse getServiceAgreementHierarchyResponse = new GetServiceAgreementHierarchyResponse();
		try
		{
			String salesChannelName = null;
			String salesChannelType = null;
			String modemType = null;
			String triaType = null;
			GeoPosition geoPosition = null;
			Beam beamInfo = new Beam();
			BeamTechnicalInfo beamTechnicalInfo = new BeamTechnicalInfo();
			BeamSalesInfo beamSalesInfo = new BeamSalesInfo();
			InstallationAttribute installationAttribute = null;
			LegacyAttribute legacyAttribute = null;
			IspAccount ispAccount = null;
			ServiceItem serviceItemIsp = new ServiceItem();
			ServiceAgreement serviceAgreement = new ServiceAgreement();
			List<ServiceItem> serviceItems = new ArrayList<>();
			EquipmentType equipmentType = new EquipmentType();

			com.viasat.wildblue.facade.provisioning.data.ServiceAgreementHierarchy serviceAgreementHierarchy = new com.viasat.wildblue.facade.provisioning.data.ServiceAgreementHierarchy();

			GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();

			String serviceAgreementReference = parameter.getServiceAgreementReference();

			getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementReference);

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy btsServiceAgreementHier = businessTransactionWrapper
					.getServiceAgreementHierarchyFromInternalServiceAgreementReference(
							serviceAgreementReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
			salesChannelName = btsServiceAgreementHier.getSalesChannelName();

			if (btsServiceAgreementHier != null)
			{
				serviceAgreement.setAccountReference(btsServiceAgreementHier.getAccountReference());
				serviceAgreement.setServiceAgreementReference(
						btsServiceAgreementHier.getServiceAgreementReference());

				salesChannelType = businessTransactionWrapper
						.getSalesChannelTypeForSalesChannelName(salesChannelName,
								ConfigurationConstants.COMMON_WILDBLUE_HEADER);

				serviceAgreement.setSalesChannelType(salesChannelName);

				List<String> catalogRefs = btsServiceAgreementHier.getServiceItems().stream()
						.map(si -> {
							return si.getMasterCatalogKey();
						}).collect(Collectors.toList());

				GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
						wildBlueHeader);

				if (salesChannelType != null)
				{
					Layer3Service layer3Serv = getLayer3ServiceForInternet(btsServiceAgreementHier,
							catalogComponents);
					if (layer3Serv != null)
					{
						serviceAgreement.setStartDate(layer3Serv.getConfiguration().getDate());
					}
					String status = getServiceProvisioningStatus(catalogComponents, layer3Serv,
							getServiceProvisioningStatus, wildBlueHeader);
					if (status != null)
					{

						serviceAgreement.setStatus(status);

						modemType = getModemType(
								btsServiceAgreementHier.getServiceAgreementDevice(),
								serviceAgreement.getStatus());
						triaType = getTriaType(btsServiceAgreementHier.getServiceAgreementDevice(),
								serviceAgreement.getStatus());
					}
					equipmentType.setModemType(modemType);
					equipmentType.setTriaType(triaType);
					beamTechnicalInfo.setEquipmentType(equipmentType);

					for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem service : btsServiceAgreementHier
							.getServiceItems())
					{
						ServiceItem serviceItemBts = new ServiceItem();
						CatalogComponent catalog = catalogComponents.getComponents().stream()
								.filter(catalogComponent -> service.getMasterCatalogKey()
										.equals(catalogComponent.getCharges().get(0)
												.getMasterCatalogReference()))
								.findFirst().orElse(null);

						if (catalog.getComponentType().equals("EMAIL")
								|| catalog.getComponentType()
										.equals(SdpConstants.INTERNET_ACCESS_SERVICE)
								|| catalog.getComponentType().equals(SdpConstants.VOIP))
						{
							serviceItemBts.setServiceAgreementReference(
									service.getServiceAgreementReference());
							serviceItemBts
									.setServiceItemReference(service.getServiceItemReference());
							if (catalog.getComponentType().equals("EMAIL"))
							{
								serviceItemBts.setName("ISP Service");
								serviceItemBts.setType("ISP");
							}
							else
							{
								serviceItemBts.setName(catalog.getDisplayName());
								serviceItemBts.setType(catalog.getComponentType());
							}
							serviceItemBts.setCatalogNumber(service.getMasterCatalogKey());
							serviceItemBts.setStatus(status);
							serviceItemBts.setStartDate(service.getCreateDate());
							serviceItems.add(serviceItemBts);
						}
					}

					FixedNTD fixedNTD = sdpWrapper.getFixedNTD(serviceAgreementReference);

					serviceAgreement.setMACAddress(fixedNTD.getMacAddress());

					String serviceAreaId = fixedNTD.getConfiguration().getCsaId();

					ServiceArea serviceArea = sdpWrapper.getServiceArea(serviceAreaId);
					if (serviceArea != null)
					{
						Date now = new Date();
						List<InstallationKey> installationKeys = serviceArea.getInstallationKeys()
								.getInstallationKey();
						InstallationKey key = installationKeys.stream().filter(
								installationKey -> now.compareTo(installationKey.getAsOf()) <= 0)
								.findFirst()
								.orElse(installationKeys.stream().findFirst().orElse(null));

						beamTechnicalInfo.setModemInstallCode(key.getKey());

					}

					beamInfo.setBeamTechnicalInfo(beamTechnicalInfo);
					beamInfo.setBeamSalesInfo(beamSalesInfo);

					CatalogComponent voipComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
							.orElse(null);

					if (voipComponent != null)
					{

						String voipMcr = voipComponent.getCharges().get(0)
								.getMasterCatalogReference();

						ServiceItem voipSvcItem = serviceItems.stream() // for
																		// each
								// serviceItem
								.filter(serviceItem -> voipMcr
										.equals(serviceItem.getCatalogNumber()))
								.findFirst().orElse(null);
						Layer3Service layer3Service = sdpWrapper
								.getLayer3Service(voipSvcItem.getServiceItemReference());
						Layer3ServiceState state = layer3Service.getState();

						voipSvcItem.setStartDate(layer3Service.getConfiguration().getDate());
					}

					CatalogComponent ispComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
							.findFirst().orElse(null);

					List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
							.getServiceAgreementContacts(serviceAgreementReference, null, null);

					serviceAgreement.setServiceContact(getContact(contacts));

					List<ServiceLocationAggregate> serviceLocationAggregates = serviceLocationWrapper
							.getProvisioningDetailsServiceLocation(serviceAgreementReference);

					if (serviceLocationAggregates != null)
					{
						if (serviceLocationAggregates.get(0) != null)
						{
							String latitude = serviceLocationAggregates.get(0).getActualLatitude();
							String longitude = serviceLocationAggregates.get(0)
									.getActualLongitude();
							geoPosition = new GeoPosition();
							geoPosition.setLatitude(Double.parseDouble(latitude));
							geoPosition.setLongitude(Double.parseDouble(longitude));

							installationAttribute = (serviceLocationAggregates.get(0)
									.getInstallationAttributes() != null
									&& serviceLocationAggregates.get(0).getInstallationAttributes()
											.size() > 0)
													? serviceLocationAggregates.get(0)
															.getInstallationAttributes().get(0)
													: null;
							legacyAttribute = (serviceLocationAggregates.get(0)
									.getLegacyAttributes() != null
									&& serviceLocationAggregates.get(0).getLegacyAttributes()
											.size() > 0)
													? serviceLocationAggregates.get(0)
															.getLegacyAttributes().get(0)
													: null;

							if (ispComponent != null)
							{
								String ispMcr = ispComponent.getCharges().get(0)
										.getMasterCatalogReference();
								ServiceItem ispSvcItem = serviceItems.stream() // for
																				// each
										// serviceItem
										.filter(serviceItem -> ispMcr
												.equals(serviceItem.getCatalogNumber()))
										.findFirst().orElse(null);
								if (ispSvcItem != null)
								{
									ispAccount = ispWrapper.getIspAccount(
											new BigDecimal(serviceAgreementReference));
								}

								// ispSvcItem.setStatus(ispAccount.getStatusCode());

								ispSvcItem.setSelfCareLoginName(legacyAttribute.getIspUsername());
								ispSvcItem.setSelfCarePassword(legacyAttribute.getIspPassword());

							}

							serviceAgreement.setBeamInfo(getBeamInfoData(beamInfo,
									installationAttribute, legacyAttribute));

							serviceAgreement.getServiceContact().getContactInfo().getLocation()
									.setGeoPosition(geoPosition);

							serviceAgreementHierarchy.setServiceAgreement(serviceAgreement);
							serviceAgreementHierarchy.getServiceItem().addAll(serviceItems);

							getServiceAgreementHierarchyResponse
									.setServiceAgreementHierarchy(serviceAgreementHierarchy);

						}
					}

				}
			}

		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException(
					"Error getting service agreement hierarchy: " + e.getMessage(), e);
		}
		return getServiceAgreementHierarchyResponse;
	}

	// FCSDP-18
	public GetServiceAgreementResponse getServiceAgreement(GetServiceAgreement parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		try
		{
			ServiceAgreement serviceAgreement = new ServiceAgreement();
			String modemType = null;
			String triaType = null;
			InstallationAttribute installationAttribute = null;
			LegacyAttribute legacyAttribute = null;
			GeoPosition geoPosition = null;
			Layer3ServiceState state = null;
			FixedNTD fixedNTD = null;
			String mcAddress = null;
			String csaId = null;
			com.viasat.wildblue.common.commondata.Beam beamInfo = new Beam();
			com.viasat.wildblue.common.commondata.BeamTechnicalInfo beamTechnicalInfo = new BeamTechnicalInfo();
			EquipmentType equipmentType = new EquipmentType();
			AntennaLookAngles antennaLookAngles = new AntennaLookAngles();
			BeamSalesInfo beamSalesInfo = new BeamSalesInfo();
			GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
			GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = null;

			String serviceAgreementReference = parameter.getServiceAgreementReference();
			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy btsServiceAgreementHier = businessTransactionWrapper
					.getServiceAgreementHierarchyFromInternalServiceAgreementReference(
							serviceAgreementReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
			String accountReference = btsServiceAgreementHier.getAccountReference();
			serviceAgreement.setServiceAgreementReference(serviceAgreementReference);
			serviceAgreement.setAccountReference(accountReference);
			getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementReference);
			if (btsServiceAgreementHier != null)
			{
				List<String> catalogRefs = btsServiceAgreementHier.getServiceItems().stream()
						.map(si -> {
							return si.getMasterCatalogKey();
						}).collect(Collectors.toList());

				GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
						wildBlueHeader);

				Layer3Service layer3Serv = getLayer3ServiceForInternet(btsServiceAgreementHier,
						catalogComponents);

				String status = getServiceProvisioningStatus(catalogComponents,layer3Serv,
						getServiceProvisioningStatus,
						ConfigurationConstants.COMMON_WILDBLUE_HEADER);
				fixedNTD = sdpWrapper.getFixedNTD(serviceAgreementReference);
				csaId = fixedNTD.getConfiguration().getCsaId();
				mcAddress = fixedNTD.getMacAddress();
				serviceAgreement.setServiceAgreementReference(serviceAgreementReference);
				serviceAgreement.setSalesChannelType(btsServiceAgreementHier.getSalesChannelName());
				serviceAgreement.setMACAddress(mcAddress);
				serviceAgreement.setStatus(status);
				serviceAgreement.setStartDate(layer3Serv.getConfiguration().getDate());
				modemType = getModemType(btsServiceAgreementHier.getServiceAgreementDevice(),
						serviceAgreement.getStatus());
				triaType = getTriaType(btsServiceAgreementHier.getServiceAgreementDevice(),
						serviceAgreement.getStatus());
				equipmentType.setModemType(modemType);
				equipmentType.setTriaType(triaType);

				serviceAgreement.setMACAddress(fixedNTD.getMacAddress());

				String serviceAreaId = fixedNTD.getConfiguration().getCsaId();

				ServiceArea serviceArea = sdpWrapper.getServiceArea(serviceAreaId);
				if (serviceArea != null)
				{
					Date now = new Date();
					List<InstallationKey> installationKeys = serviceArea.getInstallationKeys()
							.getInstallationKey();
					InstallationKey key = installationKeys.stream().filter(
							installationKey -> now.compareTo(installationKey.getAsOf()) <= 0)
							.findFirst().orElse(installationKeys.stream().findFirst().orElse(null));

					beamTechnicalInfo.setModemInstallCode(key.getKey());

				}

				beamTechnicalInfo.setEquipmentType(equipmentType);
				beamInfo.setBeamTechnicalInfo(beamTechnicalInfo);
				beamInfo.setBeamSalesInfo(beamSalesInfo);

				List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
						.getServiceAgreementContacts(serviceAgreementReference, null, null);
				serviceAgreement.setServiceContact(getContact(contacts));
				List<ServiceLocationAggregate> serviceLocationAggregates = serviceLocationWrapper
						.getProvisioningDetailsServiceLocation(serviceAgreementReference);
				if (serviceLocationAggregates != null)
				{
					if (serviceLocationAggregates.get(0) != null)
					{
						String latitude = serviceLocationAggregates.get(0).getActualLatitude();
						String longitude = serviceLocationAggregates.get(0).getActualLongitude();
						geoPosition = new GeoPosition();
						geoPosition.setLatitude(Double.parseDouble(latitude));
						geoPosition.setLongitude(Double.parseDouble(longitude));

						installationAttribute = (serviceLocationAggregates.get(0)
								.getInstallationAttributes() != null
								&& serviceLocationAggregates.get(0).getInstallationAttributes()
										.size() > 0)
												? serviceLocationAggregates.get(0)
														.getInstallationAttributes().get(0)
												: null;
						legacyAttribute = (serviceLocationAggregates.get(0)
								.getLegacyAttributes() != null
								&& serviceLocationAggregates.get(0).getLegacyAttributes()
										.size() > 0)
												? serviceLocationAggregates.get(0)
														.getLegacyAttributes().get(0)
												: null;
						serviceAgreement.setBeamInfo(
								getBeamInfoData(beamInfo, installationAttribute, legacyAttribute));
						serviceAgreement.setInstallationLogin(legacyAttribute.getIspUsername());
						serviceAgreement.setInstallationPassword(legacyAttribute.getIspPassword());
						serviceAgreement.getServiceContact().getContactInfo().getLocation()
								.setGeoPosition(geoPosition);
					}
				}
			}
			GetServiceAgreementResponse response = new GetServiceAgreementResponse();
			response.setServiceAgreement(serviceAgreement);

			return response;
		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException("Error getting service agreement: " + e.getMessage(),
					e);
		}
	}

	public GetAccountHierarchyResponse getAccountHierarchy(GetAccountHierarchy parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetAccountHierarchyResponse getAccountHierarchyResponse = new GetAccountHierarchyResponse();
		com.viasat.wildblue.facade.provisioning.data.AccountHierarchy accountHierarchy = new com.viasat.wildblue.facade.provisioning.data.AccountHierarchy();
		try
		{
			String salesChannelName = null;
			String salesChannelType = null;
			String macAddress = null;
			String serviceAgreementReference = null;
			String customerReference = null;
			String modemType = null;
			String triaType = null;
			EquipmentType equipmentType = new EquipmentType();
			Account account = new Account();
			BeamTechnicalInfo beamTechnicalInfo = new BeamTechnicalInfo();
			BeamSalesInfo beamSalesInfo = new BeamSalesInfo();
			Beam beamInfo = new Beam();
			IspAccount ispAccount = null;
			GeoPosition geoPosition = null;
			InstallationAttribute installationAttribute = null;
			LegacyAttribute legacyAttribute = null;

			List<ServiceItem> serviceItems = new ArrayList<>();
			ServiceItem serviceItemIsp = new ServiceItem();
			ServiceItem serviceItemVoip = new ServiceItem();
			com.viasat.wildblue.facade.provisioning.data.ServiceAgreement serviceAgreement = new com.viasat.wildblue.facade.provisioning.data.ServiceAgreement();
			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem> serviceItemList = new ArrayList<>();

			GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
			String accountRef = parameter.getAccountReference();

			com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy = businessTransactionWrapper
					.getAccountHierarchyByInternalReference(accountRef,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
			customerReference = btsAccountHierarchy.getCustomerReference();
			account.setCustomerReference(customerReference);
			account.setAccountReference(accountRef);
			serviceAgreement.setAccountReference(accountRef);
			List<ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
					.getServiceAgreements();
			for (ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
			{
				com.viasat.wildblue.facade.provisioning.data.ServiceAgreementHierarchy serviceAgreementHie = new com.viasat.wildblue.facade.provisioning.data.ServiceAgreementHierarchy();
				serviceAgreementReference = serviceAgreementHierarchy
						.getServiceAgreementReference();
				serviceAgreement.setServiceAgreementReference(serviceAgreementReference);
				salesChannelName = serviceAgreementHierarchy.getSalesChannelName();

				if (btsAccountHierarchy != null)
				{

					salesChannelType = businessTransactionWrapper
							.getSalesChannelTypeForSalesChannelName(salesChannelName,
									ConfigurationConstants.COMMON_WILDBLUE_HEADER);

					serviceAgreement.setSalesChannelType(salesChannelName);

					List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
							.map(si -> {
								return si.getMasterCatalogKey();
							}).collect(Collectors.toList());

					GetComponentsResponse catalogComponents = catalogWrapper
							.getComponents(catalogRefs, wildBlueHeader);

					getServiceProvisioningStatus
							.setServiceAgreementReference(serviceAgreementReference);

					Layer3Service layer3 = getLayer3ServiceForInternet(serviceAgreementHierarchy,
							catalogComponents);

					String status = getServiceProvisioningStatus(catalogComponents, layer3,
							getServiceProvisioningStatus, wildBlueHeader);

					if (status != null)
					{

						serviceAgreement.setStatus(status);

						modemType = getModemType(
								serviceAgreementHierarchy.getServiceAgreementDevice(),
								serviceAgreement.getStatus());
						triaType = getTriaType(
								serviceAgreementHierarchy.getServiceAgreementDevice(),
								serviceAgreement.getStatus());
					}
					equipmentType.setModemType(modemType);
					equipmentType.setTriaType(triaType);
					beamTechnicalInfo.setEquipmentType(equipmentType);
					beamInfo.setBeamTechnicalInfo(beamTechnicalInfo);
					serviceAgreement.setBeamInfo(beamInfo);
					beamInfo.setBeamSalesInfo(beamSalesInfo);

					serviceItemList = serviceAgreementHierarchy.getServiceItems();

					for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem service : serviceItemList)
					{
						ServiceItem serviceItemBts = new ServiceItem();
						CatalogComponent catalog = catalogComponents.getComponents().stream()
								.filter(catalogComponent -> service.getMasterCatalogKey()
										.equals(catalogComponent.getCharges().get(0)
												.getMasterCatalogReference()))
								.findFirst().orElse(null);

						if (catalog.getComponentType().equals("EMAIL")
								|| catalog.getComponentType()
										.equals(SdpConstants.INTERNET_ACCESS_SERVICE)
								|| catalog.getComponentType().equals(SdpConstants.VOIP))
						{
							serviceItemBts.setServiceAgreementReference(
									service.getServiceAgreementReference());
							serviceItemBts
									.setServiceItemReference(service.getServiceItemReference());
							if (catalog.getComponentType().equals("EMAIL"))
							{
								serviceItemBts.setName("ISP Service");
								serviceItemBts.setType("ISP");
							}
							else
							{
								serviceItemBts.setName(catalog.getDisplayName());
								serviceItemBts.setType(catalog.getComponentType());
							}
							serviceItemBts.setCatalogNumber(service.getMasterCatalogKey());
							serviceItemBts.setStatus(status);
							serviceItemBts.setStartDate(service.getCreateDate());
							serviceItems.add(serviceItemBts);
						}
					}

					List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
							.getAccountContacts(accountRef, null, null);

					if (contacts != null && contacts.size() > 0)
					{
						account.setAccountContact(getContact(contacts));

					}

					FixedNTD fixedNTD = sdpWrapper.getFixedNTD(serviceAgreementReference);

					String serviceAreaId = fixedNTD.getConfiguration().getCsaId();

					ServiceArea serviceArea = sdpWrapper.getServiceArea(serviceAreaId);
					if (serviceArea != null)
					{
						Date now = new Date();
						List<InstallationKey> installationKeys = serviceArea.getInstallationKeys()
								.getInstallationKey();
						InstallationKey key = installationKeys.stream().filter(
								installationKey -> now.compareTo(installationKey.getAsOf()) <= 0)
								.findFirst()
								.orElse(installationKeys.stream().findFirst().orElse(null));

						beamTechnicalInfo.setModemInstallCode(key.getKey());

					}

					serviceAgreement.setMACAddress(fixedNTD.getMacAddress());

					CatalogComponent voipComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
							.orElse(null);

					if (voipComponent != null)
					{

						String voipMcr = voipComponent.getCharges().get(0)
								.getMasterCatalogReference();

						ServiceItem voipSvcItem = serviceItems.stream() // for
								// each
								// serviceItem
								.filter(serviceItem -> voipMcr
										.equals(serviceItem.getCatalogNumber()))
								.findFirst().orElse(null);
						Layer3Service layer3Service = sdpWrapper
								.getLayer3Service(voipSvcItem.getServiceItemReference());
						Layer3ServiceState state = layer3Service.getState();

						voipSvcItem.setStartDate(layer3Service.getConfiguration().getDate());
					}

					CatalogComponent ispComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
							.findFirst().orElse(null);

					List<com.viasat.internalservice.contact.api.model.Contact> contact = contactsWrapper
							.getServiceAgreementContacts(serviceAgreementReference, null, null);

					serviceAgreement.setServiceContact(getContact(contact));

					List<ServiceLocationAggregate> serviceLocationAggregates = serviceLocationWrapper
							.getProvisioningDetailsServiceLocation(serviceAgreementReference);

					if (serviceLocationAggregates != null)
					{
						if (serviceLocationAggregates.get(0) != null)
						{
							OffsetDateTime startDate = serviceLocationAggregates.get(0)
									.getStartDate();
							Date date = Date.from(startDate.toInstant());
							serviceAgreement.setStartDate(date);
							String latitude = serviceLocationAggregates.get(0).getActualLatitude();
							String longitude = serviceLocationAggregates.get(0)
									.getActualLongitude();
							geoPosition = new GeoPosition();
							geoPosition.setLatitude(Double.parseDouble(latitude));
							geoPosition.setLongitude(Double.parseDouble(longitude));

							installationAttribute = (serviceLocationAggregates.get(0)
									.getInstallationAttributes() != null
									&& serviceLocationAggregates.get(0).getInstallationAttributes()
											.size() > 0)
													? serviceLocationAggregates.get(0)
															.getInstallationAttributes().get(0)
													: null;
							legacyAttribute = (serviceLocationAggregates.get(0)
									.getLegacyAttributes() != null
									&& serviceLocationAggregates.get(0).getLegacyAttributes()
											.size() > 0)
													? serviceLocationAggregates.get(0)
															.getLegacyAttributes().get(0)
													: null;

							serviceAgreement.setBeamInfo(getBeamInfoData(beamInfo,
									installationAttribute, legacyAttribute));

							if (ispComponent != null)
							{
								String ispMcr = ispComponent.getCharges().get(0)
										.getMasterCatalogReference();
								ServiceItem ispSvcItem = serviceItems.stream() // for
										// each
										// serviceItem
										.filter(serviceItem -> ispMcr
												.equals(serviceItem.getCatalogNumber()))
										.findFirst().orElse(null);
								if (ispSvcItem != null)
								{
									ispAccount = ispWrapper.getIspAccount(
											new BigDecimal(serviceAgreementReference));
								}

								ispSvcItem.setStatus(ispAccount.getStatusCode());

								ispSvcItem.setSelfCareLoginName(legacyAttribute.getIspUsername());
								ispSvcItem.setSelfCarePassword(legacyAttribute.getIspPassword());

							}

							serviceAgreement.getServiceContact().getContactInfo().getLocation()
									.setGeoPosition(geoPosition);

							serviceAgreementHie.setServiceAgreement(serviceAgreement);
							serviceAgreementHie.getServiceItem().addAll(serviceItems);
							accountHierarchy.getServiceAgreementHierarchy()
									.add(serviceAgreementHie);
							account.setAccountType(salesChannelType);
							accountHierarchy.setAccount(account);

							if (null == accountHierarchy)
							{
								throw new AccountNotFoundException(null, accountRef,
										"Account does not exist or was in error in volubill database");
							}

							getAccountHierarchyResponse.setAccountHierarchy(accountHierarchy);

						}
					}

				}

			}

		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			throw new WildBlueFaultException("Error getting account hierarchy: " + e.getMessage(),
					e);
		}
		return getAccountHierarchyResponse;
	}

	public GetCustomerHierarchyResponse getCustomerHierarchy(GetCustomerHierarchy parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		String custRef = parameter.getCustomerReference();
		CustomerHierarchy btsCustomerHierarchy;
		com.viasat.wildblue.facade.provisioning.data.CustomerHierarchy customerHierarchy = null;
		Customer customer = new Customer();

		try
		{
			btsCustomerHierarchy = businessTransactionWrapper
					.getCustomerHierarchyByInternalReference(custRef, wildBlueHeader);

			if (btsCustomerHierarchy != null)
			{
				List<AccountHierarchy> accountHierarchies = btsCustomerHierarchy.getAccounts();
				for (AccountHierarchy accountHierarchy : accountHierarchies)
				{
					String accountRef = accountHierarchy.getAccountReference();
					GetAccountHierarchy request = new GetAccountHierarchy();
					request.setAccountReference(accountRef);

					GetAccountHierarchyResponse response = getAccountHierarchy(request,
							wildBlueHeader);
					customerHierarchy = new com.viasat.wildblue.facade.provisioning.data.CustomerHierarchy();
					customerHierarchy.getAccountHierarchy().add(response.getAccountHierarchy());

					List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactsWrapper
							.getCustomerContacts(accountRef, null, null);

					if (contacts != null && !contacts.isEmpty())
					{
						customer.setCustomerContact(getContact(contacts));
						String businessName = contacts.get(0).getBusinessName();
						customer.setBusinessName(businessName);
					}

					customer.setCustomerReference(custRef);
					customer.setCustomerType(btsCustomerHierarchy.getCustomerTypeName());
					customerHierarchy.setCustomer(customer);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		GetCustomerHierarchyResponse response = new GetCustomerHierarchyResponse();
		response.setCustomerHierarchy(customerHierarchy);
		return response;
	}

	public GetAllServiceAgreementHierarchiesResponse getAllServiceAgreementHierarchies(
			GetAllServiceAgreementHierarchies parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetAllServiceAgreementHierarchiesResponse response = new GetAllServiceAgreementHierarchiesResponse();
		try
		{

			String serviceAgreementReference = parameter.getServiceAgreementReference();

			CustomerHierarchy customerHierarchy = businessTransactionWrapper
					.getCustomerHierarchyByInternalServiceAgreementReference(
							serviceAgreementReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			List<ServiceAgreementHierarchy> serviceAgreementHierarchies = customerHierarchy
					.getAccounts().get(0).getServiceAgreements();

			for (ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
			{
				GetServiceAgreementHierarchy param = new GetServiceAgreementHierarchy();
				param.setServiceAgreementReference(
						serviceAgreementHierarchy.getServiceAgreementReference());
				GetServiceAgreementHierarchyResponse getServiceAgreementHierarchyResponse = getServiceAgreementHierarchy(
						param, ConfigurationConstants.COMMON_WILDBLUE_HEADER);

				response.getServiceAgreementHierarchy()
						.add(getServiceAgreementHierarchyResponse.getServiceAgreementHierarchy());
			}

		}
		catch (WebServiceException e)
		{
			// Just throw the exception as is.
			throw e;
		}
		catch (Exception e)
		{
			// Unhandled exception case.
			throw new WildBlueFaultException(
					"Error getting all service agreement hierarchies: " + e.getMessage(), e);
		}
		return response;
	}

	public String getAccountType(String serviceProvider)
	{
		String wbAccountType = "WHOLESALE";

		if ("WildBlue".equals(serviceProvider))
		{
			wbAccountType = "RETAIL";
		}

		return wbAccountType;
	}
}
