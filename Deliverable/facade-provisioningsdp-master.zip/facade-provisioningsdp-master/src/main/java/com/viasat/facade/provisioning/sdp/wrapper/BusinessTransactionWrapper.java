package com.viasat.facade.provisioning.sdp.wrapper;

import com.viasat.common.client.EndpointInitException;
import com.viasat.common.client.StandardClient;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.exception.contingency.AccountNotFoundException;
import com.viasat.wildblue.common.exception.contingency.CustomerNotFoundException;
import com.viasat.wildblue.common.exception.contingency.ServiceAgreementNotFoundException;
import com.viasat.wildblue.common.exception.contingency.ServiceItemNotFoundException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.List;

// TODO copied this from BusinessTransactionUtility class in Facade-Provisioning-Shared-CORE. Refactor and clean up as needed.
public class BusinessTransactionWrapper
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataWrapper.class);

	// transaction types
	public static final String TRANSACTION_ACTIVATE_ISP = "activateISP";
	public static final String TRANSACTION_ACTIVATE_MODEM_ACCESS = "activateModemAccess";
	public static final String TRANSACTION_ADD_CUSTOMER_HIERARCHY = "addCustomerHierarchy";
	public static final String TRANSACTION_ADD_SERVICE_ITEM = "addServiceItem";
	public static final String TRANSACTION_ADD_USAGE_QUOTA = "addUsageQuota";
	public static final String TRANSACTION_CANCEL_ADD_CUSTOMER_HIERARCHY = "cancelAddCustomerHierarchy";
	public static final String TRANSACTION_CANCEL_TRANSITION_SERVICE_AGREEMENT = "cancelTransitionServiceAgreement";
	public static final String TRANSACTION_CANCEL_TRANSITION_SERVICE_EQUIPMENT = "cancelTransitionServiceEquipment";
	public static final String TRANSACTION_DISCONNECT_ACCOUNT = "disconnectAccount";
	public static final String TRANSACTION_DISCONNECT_SERVICE_AGREEMENT = "disconnectServiceAgreement";
	public static final String TRANSACTION_DISCONNECT_SERVICE_ITEM = "disconnectServiceItem";
	public static final String TRANSACTION_QOI_RESULTS = "updateQOIResults";
	public static final String TRANSACTION_REGISTER_MODEM = "registerModem";
	public static final String TRANSACTION_REMOVE_DAP_ENFORCEMENT = "removeDAPEnforcement";
	public static final String TRANSACTION_REMOVE_USAGE_QUOTA = "removeUsageQuota";
	public static final String TRANSACTION_RESUME_ALL_SERVICE_AGREEMENTS = "resumeAllServiceAgreements";
	public static final String TRANSACTION_SUSPEND_ALL_SERVICE_AGREEMENTS = "suspendAllServiceAgreements";
	public static final String TRANSACTION_TRANSITION_SERVICE_AGREEMENT = "transitionServiceAgreement";
	public static final String TRANSACTION_TRANSITION_SERVICE_EQUIPMENT = "transitionServiceEquipment";
	public static final String TRANSACTION_TRANSITION_SERVICE_EQUIPMENT_COMPLETE = "transitionServiceEquipmentComplete";
	public static final String TRANSACTION_TRANSITION_SERVICE_ITEM = "transitionServiceItem";
	public static final String TRANSACTION_UPDATE_ACCOUNT_CONTACT_ADDRESS = "updateAccountAddress";
	public static final String TRANSACTION_UPDATE_ACCOUNT_CONTACT_EMAIL = "updateAccountContactEmail";
	public static final String TRANSACTION_UPDATE_ACCOUNT_CONTACT_NAME = "updateAccountContactName";
	public static final String TRANSACTION_UPDATE_ACCOUNT_CONTACT_PHONE = "updateAccountContactPhone";
	public static final String TRANSACTION_UPDATE_CONTACTS = "updateContacts";
	public static final String TRANSACTION_UPDATE_CUSTOMER_CONTACT_ADDRESS = "updateCustomerAddress";
	public static final String TRANSACTION_UPDATE_CUSTOMER_CONTACT_EMAIL = "updateCustomerContactEmail";
	public static final String TRANSACTION_UPDATE_CUSTOMER_CONTACT_NAME = "updateCustomerContactName";
	public static final String TRANSACTION_UPDATE_CUSTOMER_CONTACT_PHONE = "updateCustomerContactPhone";
	public static final String TRANSACTION_UPDATE_EQUIPMENT = "updateEquipment";
	public static final String TRANSACTION_UPDATE_HOTLINE = "updateHotline";
	public static final String TRANSACTION_UPDATE_SERVICE_CONTACT_EMAIL = "updateServiceContactEmail";
	public static final String TRANSACTION_UPDATE_SERVICE_CONTACT_NAME = "updateServiceContactName";
	public static final String TRANSACTION_UPDATE_SERVICE_CONTACT_PHONE = "updateServiceContactPhone";
	public static final String TRANSACTION_UPDATE_VOLUME_CAP_DATE = "updateBillCycle";

	// transaction statuses
	public static final String TRANSACTION_STATUS_WORKING = "WORKING";
	public static final String TRANSACTION_STATUS_COMPLETE = "COMPLETE";
	public static final String TRANSACTION_STATUS_FAILED = "FAILED";

	// bts exception codes
	public static final String CODE_DATA_OBJECT_NOT_FOUND = "DATA_OBJECT_NOT_FOUND";

	private enum WSEType
	{
		ACCOUNT, CUSTOMER, SERVICE_AGREEMENT, SERVICE_ITEM
	}

	private StandardClient<BusinessTransaction> businessTransactionClient;

	public void setBusinessTransactionClient(
			StandardClient<BusinessTransaction> businessTransactionClient)
	{
		this.businessTransactionClient = businessTransactionClient;
	}

	/**
	 * Gets the account reference from the internal customer reference. Returns
	 * the first account reference in the hierarchy, so assumes a one-to-one
	 * mapping.
	 *
	 * @param accountReference
	 *            the customer reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the account reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public AccountHierarchy getAccountHierarchyByInternalReference(String accountReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetAccountHierarchyByInternalReference data = new GetAccountHierarchyByInternalReference();

		data.setAccountReference(accountReference);

		GetAccountHierarchyByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getAccountHierarchyByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.ACCOUNT, accountReference);
		}

		return response.getAccountHierarchy();
	}

	/**
	 * Gets the account reference from the external account reference. Returns
	 * the first account reference in the hierarchy, so assumes a one-to-one
	 * mapping.
	 *
	 * @param extAccountRef
	 *            the external customer reference
	 * @param extSystemName
	 *            the external sytem name
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the account reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public AccountHierarchy getAccountHierarchyByExternalReference(String extAccountRef,
			String extSystemName, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetAccountHierarchyByExternalReference data = new GetAccountHierarchyByExternalReference();

		data.setExternalAccountReference(extAccountRef);
		data.setExternalSystemName(extSystemName);

		GetAccountHierarchyByExternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getAccountHierarchyByExternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.ACCOUNT, extAccountRef);
		}

		return response.getAccountHierarchy();
	}

	/**
	 * Gets the customer hierarchy from the internal customer reference.
	 *
	 * @param customerReference
	 *            the customer reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the customer hierarchy
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public CustomerHierarchy getCustomerHierarchyByInternalReference(String customerReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetCustomerHierarchyByInternalReferenceResponse response = null;
		GetCustomerHierarchyByInternalReference data = new GetCustomerHierarchyByInternalReference();
		if (customerReference != null)
		{
			data.setCustomerReference(customerReference);
			try
			{
				response = getBTSSvc().getCustomerHierarchyByInternalReference(data,
						wildBlueHeader);
			}
			catch (WebServiceException wse)
			{
				throw makeWebServiceException(wse, WSEType.CUSTOMER, customerReference);
			}
		}

		return response != null ? response.getCustomerHierarchy() : null;
	}

	/**
	 * Add a Business Transaction.
	 *
	 * @param transactionType
	 *            the transaction type
	 * @param transactionReference
	 *            the transaction reference
	 * @param customerReference
	 *            the customer reference
	 * @param accountReference
	 *            the account reference
	 * @param serviceAgreementReference
	 *            the service agreement reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return The Business Transaction reference.
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String addBusinessTransaction(String transactionType, String facadeOwner,
			String transactionReference, String customerReference, String accountReference,
			String serviceAgreementReference, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		AddFacadeTransaction data = new AddFacadeTransaction();

		data.setFacadeOwnerName(facadeOwner);

		data.setFacadeTransactionTypeName(transactionType);

		FacadeXmlLogItem xmlLog = new FacadeXmlLogItem();

		xmlLog.setRequestDate(new Date());
		xmlLog.setRequestXml(
				"<TODO-FacadeProvisioning-BusinessTransactionUtility-SetActualRequestXml></TODO-FacadeProvisioning-BusinessTransactionUtility-SetActualRequestXml>");
		xmlLog.setResponseDate(new Date());
		xmlLog.setResponseXml(
				"<TODO-FacadeProvisioning-BusinessTransactionUtility-SetActualResponseXml></TODO-FacadeProvisioning-BusinessTransactionUtility-SetActualResponseXml>");
		xmlLog.setTransactionMode("done");
		xmlLog.setXmlMessageStatus("done");

		data.setFacadeXmlLogItem(xmlLog);

		data.setSoaTransactionReference(transactionReference);
		data.setCustomerReference(customerReference);
		data.setAccountReference(accountReference);
		data.setServiceAgreementReference(serviceAgreementReference);

		AddFacadeTransactionResponse response;
		try
		{
			response = getBTSSvc().addFacadeTransaction(data, wildBlueHeader);
		}
		catch (WebServiceException e)
		{
			throw new WebServiceException(
					"Exception caught while trying to add a transaction via the Business Transaction Service",
					e.getFaultInfo(), e);
		}

		return response.getFacadeTransactionReference();
	}

	/**
	 * Update a Business Transaction with the given <code>
	 * businessTransactionReference</code> and <code>
	 * businessTransactionStatusName</code>.
	 *
	 * @param accountReference
	 *            the account reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the string
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String confirmAccountReferenceNumber(String accountReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetAccountByInternalReference data = new GetAccountByInternalReference();
		data.setAccountReference(accountReference);

		try
		{
			getBTSSvc().getAccountByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException e)
		{
			throw new WebServiceException(
					"Exception caught while trying to update a transaction via the Business Transaction Service",
					e.getFaultInfo(), e);
		}

		return null;
	}

	/**
	 * Gets the account reference from the internal customer reference. Returns
	 * the first account reference in the hierarchy, so assumes a one-to-one
	 * mapping.
	 *
	 * @param customerReference
	 *            the customer reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the account reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public AccountHierarchy getAccountHierarchyFromInternalCustomerReference(
			String customerReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetCustomerHierarchyByInternalReference data = new GetCustomerHierarchyByInternalReference();

		data.setCustomerReference(customerReference);

		GetCustomerHierarchyByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getCustomerHierarchyByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.CUSTOMER, customerReference);
		}

		return response.getCustomerHierarchy().getAccounts().get(0);
	}

	/**
	 * Gets the account reference from facade transaction by internal reference.
	 *
	 * @param transactionReference
	 *            the transaction reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the account reference from facade transaction by internal
	 *         reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getAccountReferenceFromFacadeTransactionByInternalReference(
			String transactionReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetFacadeTransactionByInternalReference data = new GetFacadeTransactionByInternalReference();

		data.setFacadeTransactionReference(transactionReference);

		GetFacadeTransactionByInternalReferenceResponse response;

		try
		{
			response = getBTSSvc().getFacadeTransactionByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.ACCOUNT, transactionReference);
		}

		return response.getFacadeTransaction().getAccountReference();
	}

	/**
	 * Gets the account reference from the service agreement reference. Returns
	 * the first account reference in the hierarchy, so assumes a one-to-one
	 * mapping.
	 *
	 * @param serviceAgreementReference
	 *            the service agreement reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the account reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getAccountReferenceFromInternalServiceAgreementReference(
			String serviceAgreementReference, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetServiceAgreementByInternalReference data = new GetServiceAgreementByInternalReference();

		data.setServiceAgreementReference(serviceAgreementReference);

		GetServiceAgreementByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getServiceAgreementByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.ACCOUNT, serviceAgreementReference);
		}

		return response.getServiceAgreement().getAccountReference();
	}

	/**
	 * Gets the account reference from soa transaction by internal reference.
	 *
	 * @param transactionReference
	 *            the transaction reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the account reference from soa transaction by internal reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getAccountReferenceFromSoaTransactionByInternalReference(
			String transactionReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetSoaTransactionByInternalReference internalRefData = new GetSoaTransactionByInternalReference();

		internalRefData.setSoaTransactionReference(transactionReference);

		GetSoaTransactionByInternalReferenceResponse soaTransactionResponse;

		soaTransactionResponse = getBTSSvc().getSoaTransactionByInternalReference(internalRefData,
				wildBlueHeader);

		String externalAccountRef = soaTransactionResponse.getSoaTransaction()
				.getExternalAccountReference();

		String externalSystemName = soaTransactionResponse.getSoaTransaction()
				.getExternalSystemName();

		GetAccountByExternalReference externalRefData = new GetAccountByExternalReference();

		externalRefData.setExternalAccountReference(externalAccountRef);
		externalRefData.setExternalSystemName(externalSystemName);

		GetAccountByExternalReferenceResponse accountResponse;
		try
		{
			accountResponse = getBTSSvc().getAccountByExternalReference(externalRefData,
					wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.ACCOUNT, transactionReference);
		}

		return accountResponse.getAccount().getAccountReference();
	}

	/**
	 * Gets the external customer reference from soa transaction by internal
	 * reference from getSoaTransactionByInternalReference.
	 *
	 * @param transactionReference
	 *            the transaction reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the customer reference from soa transaction by internal reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public SoaTransactionXml getSoaTransactionByInternalReference(String transactionReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetSoaTransactionByInternalReference internalRefData = new GetSoaTransactionByInternalReference();
		internalRefData.setSoaTransactionReference(transactionReference);

		// get soa transactions
		GetSoaTransactionByInternalReferenceResponse resp = getBTSSvc()
				.getSoaTransactionByInternalReference(internalRefData, wildBlueHeader);

		// bts throws exception if not found so this should be null-safe
		return resp.getSoaTransaction();
	}

	/**
	 * Gets the customer reference from the account reference
	 *
	 * @param accountReference
	 *            the account reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the customer reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getCustomerReferenceFromInternalAccountReference(String accountReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetAccountByInternalReference data = new GetAccountByInternalReference();

		data.setAccountReference(accountReference);

		GetAccountByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getAccountByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.ACCOUNT, accountReference);
		}

		return response.getAccount().getCustomerReference();
	}

	/**
	 * Gets the sales channel name from facade transaction by internal
	 * reference.
	 *
	 * @param serviceAgreementReference
	 *            the service agreement reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the sales channel name from facade transaction by internal
	 *         reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getSalesChannelNameFromFacadeTransactionByInternalReference(
			String serviceAgreementReference, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetServiceAgreementByInternalReference data = new GetServiceAgreementByInternalReference();

		data.setServiceAgreementReference(serviceAgreementReference);

		GetServiceAgreementByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getServiceAgreementByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_AGREEMENT,
					serviceAgreementReference);
		}

		ServiceAgreement serviceAgreement = response.getServiceAgreement();

		return (serviceAgreement != null) ? serviceAgreement.getSalesChannelName() : null;
	}

	public String getSalesChannelTypeForSalesChannelName(
			String salesChannelName, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetSalesChannelTypeForSalesChannelName data = new GetSalesChannelTypeForSalesChannelName();

		data.setSalesChannelName(salesChannelName);

		GetSalesChannelTypeForSalesChannelNameResponse response;
		try
		{
			response = getBTSSvc().getSalesChannelTypeForSalesChannelName(data,wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw new WebServiceException(
					"Exception caught while trying to get SalesChannelType for SalesChannelName",
					wse.getFaultInfo(), wse);
		}

		String salesChannelType=response.getSalesChannelType();

		return (salesChannelType != null) ? salesChannelType : null;

	}

	public String getServiceAgreementFromInternalAccountReference(String accountReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// Just get the last service agreement regardless of device protocol
		return getServiceAgreementFromInternalAccountReference(accountReference, null,
				wildBlueHeader);
	}

	public String getServiceAgreementFromInternalAccountReference(String accountReference,
			String deviceProtocol, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		String serviceAgreementReference = null;
		com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy = getAccountHierarchyByInternalReference(
				accountReference, wildBlueHeader);

		List<ServiceAgreementHierarchy> btsServiceAgreementHierarchies = btsAccountHierarchy
				.getServiceAgreements();

		for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : btsServiceAgreementHierarchies)
		{
			if ((deviceProtocol == null)
					|| deviceProtocol.equals(serviceAgreementHierarchy.getDeviceProtocol()))
			{
				serviceAgreementReference = serviceAgreementHierarchy
						.getServiceAgreementReference();
			}
		}

		if (serviceAgreementReference == null)
		{
			throw new WebServiceException(
					"Account " + accountReference + " does not have a service agreement.",
					new AccountNotFoundException(null, accountReference));
		}

		return serviceAgreementReference;
	}

	public String getServiceAgreementFromInternalCustomerReference(String customerReference,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		String serviceAgreementReference = null;
		com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustomerHierarchy = getCustomerHierarchyByInternalReference(
				customerReference, wildBlueHeader);

		List<com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy> btsAccountHierarchies = btsCustomerHierarchy
				.getAccounts();

		for (com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy accountHierarchy : btsAccountHierarchies)
		{
			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> btsServiceAgreementHierarchies = accountHierarchy
					.getServiceAgreements();

			for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : btsServiceAgreementHierarchies)
			{
				serviceAgreementReference = serviceAgreementHierarchy
						.getServiceAgreementReference();
			}
		}

		if (serviceAgreementReference == null)
		{
			throw new WebServiceException(
					"Customer " + customerReference + " does not have a service agreement.",
					new ServiceAgreementNotFoundException(null, customerReference));
		}

		return serviceAgreementReference;
	}

	public ServiceAgreement getServiceAgreementByExternalReference(String extSvcAgreementRef,
			String extSystemName, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetServiceAgreementByExternalReference request = new GetServiceAgreementByExternalReference();
		request.setExternalServiceAgreementReference(extSvcAgreementRef);
		request.setExternalSystemName(extSystemName);

		try
		{
			GetServiceAgreementByExternalReferenceResponse response = getBTSSvc()
					.getServiceAgreementByExternalReference(request, wildBlueHeader);

			return response.getServiceAgreement();
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_AGREEMENT, extSvcAgreementRef);
		}
	}

	/**
	 * Gets the service agreement hierarchy from internal service agreement
	 * reference.
	 *
	 * @param serviceAgreementReference
	 *            the service agreement reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the service agreement hierarchy from internal service agreement
	 *         reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public ServiceAgreementHierarchy getServiceAgreementHierarchyFromInternalServiceAgreementReference(
			String serviceAgreementReference, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetServiceAgreementHierarchyByInternalReference data = new GetServiceAgreementHierarchyByInternalReference();

		data.setServiceAgreementReference(serviceAgreementReference);

		GetServiceAgreementHierarchyByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getServiceAgreementHierarchyByInternalReference(data,
					wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_AGREEMENT,
					serviceAgreementReference);
		}

		return response.getServiceAgreementHierarchy();
	}

	/**
	 * Gets the service agreement reference from the internal service item
	 * reference.
	 *
	 * @param serviceItemReference
	 *            the service item reference reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the service agreement reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getServiceAgreementReferenceFromInternalServiceItemReference(
			String serviceItemReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetServiceItemByInternalReference data = new GetServiceItemByInternalReference();

		data.setServiceItemReference(serviceItemReference);

		GetServiceItemByInternalReferenceResponse response;
		try
		{
			response = getBTSSvc().getServiceItemByInternalReference(data, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_ITEM, serviceItemReference);
		}

		return response.getServiceItem().getServiceAgreementReference();
	}

	/**
	 * Gets the service agreement reference from soa transaction by internal
	 * reference.
	 *
	 * @param transactionReference
	 *            the transaction reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the service agreement reference from soa transaction by internal
	 *         reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String getServiceAgreementReferenceFromSoaTransactionByInternalReference(
			String transactionReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetSoaTransactionByInternalReference internalRefData = new GetSoaTransactionByInternalReference();

		internalRefData.setSoaTransactionReference(transactionReference);

		GetSoaTransactionByInternalReferenceResponse soaTransactionResponse;
		try
		{
			soaTransactionResponse = getBTSSvc()
					.getSoaTransactionByInternalReference(internalRefData, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw new WebServiceException(
					"Exception caught while trying to get SOA Transaction via the Business Transaction Service",
					wse.getFaultInfo(), wse);
		}

		String externalServiceAgreementRef = soaTransactionResponse.getSoaTransaction()
				.getExternalServiceAgreementReference();

		String externalSystemName = soaTransactionResponse.getSoaTransaction()
				.getExternalSystemName();

		GetServiceAgreementByExternalReference externalRefData = new GetServiceAgreementByExternalReference();

		externalRefData.setExternalServiceAgreementReference(externalServiceAgreementRef);
		externalRefData.setExternalSystemName(externalSystemName);

		GetServiceAgreementByExternalReferenceResponse serviceAgreementResponse;
		try
		{
			serviceAgreementResponse = getBTSSvc()
					.getServiceAgreementByExternalReference(externalRefData, wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_AGREEMENT,
					externalServiceAgreementRef);
		}

		return serviceAgreementResponse.getServiceAgreement().getServiceAgreementReference();
	}

	/**
	 * Gets the soa transaction by internal account reference.
	 *
	 * @param accountReference
	 *            the account reference
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @return the facade transaction by internal account reference
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public String[] getSOATransactionRefByInternalAccountReference(String accountReference,
			String facadeOwner, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		GetFacadeTransactionsByInternalAccountReference data = new GetFacadeTransactionsByInternalAccountReference();

		data.setInternalAccountReference(accountReference);
		data.setResultLimit("99"); // need to cast a wide net

		GetFacadeTransactionsByInternalAccountReferenceResponse response;
		try
		{
			response = getBTSSvc().getFacadeTransactionsByInternalAccountReference(data,
					wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw new WebServiceException(
					"Exception caught while trying to get Facade Transactions via the Business Transaction Service",
					wse.getFaultInfo(), wse);
		}

		String[] references = new String[3];

		/*
		 * +++ Since there may be several responses, look for the 'PROVISIONING'
		 * and 'addCustomerHierarchy' OR 'PROVISIONING' and
		 * 'transitionServiceAgreement' OR 'PROVISIONING and
		 * 'transitionServiceEquipment' entry +++
		 */
		for (FacadeTransactionXml facadeTransaction : response.getFacadeTransactions())
		{
			if (facadeTransaction.getFacadeOwnerName().equals(facadeOwner)
					&& facadeTransaction.getFacadeTransactionTypeName()
							.equals(TRANSACTION_TRANSITION_SERVICE_EQUIPMENT))
			{
				references[0] = facadeTransaction.getFacadeTransactionReference();
				references[1] = facadeTransaction.getSoaTransactionReference();
				references[2] = facadeTransaction.getFacadeTransactionTypeName();

				LOGGER.debug("facadeTransactionTypeName for provisioningComplete: "
						+ facadeTransaction.getFacadeTransactionTypeName());
				break; // we got one, so we're done
			}
			else if (facadeTransaction.getFacadeOwnerName().equals(facadeOwner) && facadeTransaction
					.getFacadeTransactionTypeName().equals(TRANSACTION_ADD_CUSTOMER_HIERARCHY))
			{
				references[0] = facadeTransaction.getFacadeTransactionReference();
				references[1] = facadeTransaction.getSoaTransactionReference();
				references[2] = facadeTransaction.getFacadeTransactionTypeName();

				LOGGER.debug("facadeTransactionTypeName for provisioningComplete: "
						+ facadeTransaction.getFacadeTransactionTypeName());
				break; // we got one, so we're done
			}
			else if (facadeTransaction.getFacadeOwnerName().equals(facadeOwner)
					&& facadeTransaction.getFacadeTransactionTypeName()
							.equals(TRANSACTION_TRANSITION_SERVICE_AGREEMENT))
			{
				references[0] = facadeTransaction.getFacadeTransactionReference();
				references[1] = facadeTransaction.getSoaTransactionReference();
				references[2] = facadeTransaction.getFacadeTransactionTypeName();

				LOGGER.debug("facadeTransactionTypeName for provisioningComplete: "
						+ facadeTransaction.getFacadeTransactionTypeName());
				break; // we got one, so we're done

			}
		}

		return references;
	}

	/**
	 * Update a Business Transaction with the given <code>
	 * businessTransactionReference</code> and <code>
	 * businessTransactionStatusName</code>.
	 *
	 * @param businessTransactionReference
	 *            the business transaction reference
	 * @param businessTransactionStatusName
	 *            the business transaction status name
	 * @param wildBlueHeader
	 *            the wild blue header
	 * @throws WebServiceException
	 *             the web service exception
	 */
	public void updateBusinessTransaction(String businessTransactionReference,
			String businessTransactionStatusName, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{

		UpdateFacadeTransaction data = new UpdateFacadeTransaction();

		data.setFacadeTransactionReference(businessTransactionReference);

		data.setFacadeTransactionStatusName(businessTransactionStatusName);

		try
		{
			getBTSSvc().updateFacadeTransaction(data, wildBlueHeader);
		}
		catch (WebServiceException e)
		{
			throw new WebServiceException(
					"Exception caught while trying to update a transaction via the Business Transaction Service",
					e.getFaultInfo(), e);
		}
	}

	public ServiceAgreementHierarchy getServiceAgreementHierarchyFromInternalServiceItemReference(
			String serviceItemReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{

		GetCustomerHierarchyByInternalServiceItemReference data = new GetCustomerHierarchyByInternalServiceItemReference();

		data.setServiceItemReference(serviceItemReference);

		GetCustomerHierarchyByInternalServiceItemReferenceResponse response;
		try
		{
			response = getBTSSvc().getCustomerHierarchyByInternalServiceItemReference(data,
					wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_ITEM, serviceItemReference);
		}

		ServiceAgreementHierarchy svcAgreementHierarchy = null;
		for (AccountHierarchy account : response.getCustomerHierarchy().getAccounts())
		{
			for (ServiceAgreementHierarchy tmp : account.getServiceAgreements())
			{
				for (ServiceItem item : tmp.getServiceItems())
				{
					if (serviceItemReference.equals(item.getServiceItemReference()))
					{
						svcAgreementHierarchy = tmp;
						break;
					}
				}
				if (svcAgreementHierarchy != null)
				{
					break;
				}
			}
			if (svcAgreementHierarchy != null)
			{
				break;
			}
		}
		if (svcAgreementHierarchy == null)
		{
			throw new WebServiceException("Service Agreement Not Found",
					new ServiceItemNotFoundException("BusinessTransactionService",
							serviceItemReference));

		}
		return svcAgreementHierarchy;
	}

	public CustomerHierarchy getCustomerHierarchyByInternalServiceAgreementReference(
			String serviceAgreementReference, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		GetCustomerHierarchyByInternalServiceAgreementReference data = new GetCustomerHierarchyByInternalServiceAgreementReference();
		data.setServiceAgreementReference(serviceAgreementReference);
		GetCustomerHierarchyByInternalServiceAgreementReferenceResponse response;
		try
		{
			response = getBTSSvc().getCustomerHierarchyByInternalServiceAgreementReference(data,
					wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_AGREEMENT,
					serviceAgreementReference);
		}

		return response.getCustomerHierarchy();
	}

	private WildBlueWebServiceException makeWebServiceException(WebServiceException wse,
			WSEType wseType, String value)
	{
		String code;
		if (wse.getFaultInfo() != null)
		{
			code = wse.getFaultInfo().getCode();

			if (code.equals(CODE_DATA_OBJECT_NOT_FOUND))
			{
				switch (wseType)
				{
				case ACCOUNT:
					return new WildBlueWebServiceException(wse.getFaultInfo().getDetail(),
							new AccountNotFoundException(null, value));
				case CUSTOMER:
					return new WildBlueWebServiceException(wse.getFaultInfo().getDetail(),
							new CustomerNotFoundException(null, value));
				case SERVICE_AGREEMENT:
					return new WildBlueWebServiceException(wse.getFaultInfo().getDetail(),
							new ServiceAgreementNotFoundException(null, value));
				case SERVICE_ITEM:
					return new WildBlueWebServiceException(wse.getFaultInfo().getDetail(),
							new ServiceItemNotFoundException(null, value));
				}
			}
			return new WildBlueWebServiceException(wse.getMessage(), wse.getFaultInfo(), wse);
		}
		return new WildBlueWebServiceException(wse.getMessage(), wse);
	}

	private BusinessTransaction getBTSSvc() throws WebServiceException
	{
		try
		{
			return businessTransactionClient.getEndpoint();
		}
		catch (EndpointInitException e)
		{
			throw new WebServiceException(
					"Failed to get BusinessTransactionService endpoint from client!", e);
		}
	}

	public CustomerHierarchy getCustomerHierarchyByInternalServiceItemReference(
			String serviceItemReference, WildBlueHeader wildBlueHeader) throws WebServiceException
	{

		GetCustomerHierarchyByInternalServiceItemReference data = new GetCustomerHierarchyByInternalServiceItemReference();

		data.setServiceItemReference(serviceItemReference);

		GetCustomerHierarchyByInternalServiceItemReferenceResponse response;
		try
		{
			response = getBTSSvc().getCustomerHierarchyByInternalServiceItemReference(data,
					wildBlueHeader);
		}
		catch (WebServiceException wse)
		{
			throw makeWebServiceException(wse, WSEType.SERVICE_ITEM, serviceItemReference);
		}

		return  response.getCustomerHierarchy();
	}
}
