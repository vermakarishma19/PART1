package com.viasat.facade.provisioning.sdp.util;

import java.util.List;

import com.viasat.facade.provisioning.sdp.processor.ReferenceDataProcessor;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy;

/**
 * Created by sryally on 12/21/2016.
 */
public class ServiceProviderFinder
{
	public static String getServiceProviderNameFromBusinessTransactionCustomerHierarchy(
			CustomerHierarchy btsCustomerHierarchy) throws WebServiceException
	{
		AccountHierarchy accountHierarchy = null;
		List<AccountHierarchy> accountHierarchies = null;

		if (btsCustomerHierarchy != null) {
			accountHierarchies = btsCustomerHierarchy.getAccounts();

			if ((accountHierarchies != null) && !accountHierarchies.isEmpty())
			{
				accountHierarchy = accountHierarchies.get(0);
			}
		}
		return getServiceProviderNameFromBusinessTransactionAccountHierarchy(accountHierarchy);
	}

	public static String getServiceProviderNameFromBusinessTransactionAccountHierarchy(
			AccountHierarchy btsAccountHierarchy) throws WebServiceException
	{
		String externalSystemName = btsAccountHierarchy.getExternalSystemName();
		// We will assume that Sales Channel/ Service Provider will always be
		// the same over all service agreements.
		String salesChannel = null;
		List<ServiceAgreementHierarchy> serviceAgreementHierarchies = null;
		if(btsAccountHierarchy!=null) {
			serviceAgreementHierarchies = btsAccountHierarchy.getServiceAgreements();
			if ((serviceAgreementHierarchies != null) && serviceAgreementHierarchies.size()>0) {
				salesChannel = serviceAgreementHierarchies.get(0).getSalesChannelName();
			}
		}

		return ReferenceDataProcessor.getServiceProviderNameFromExternalSystemAndSalesChannel(
				externalSystemName, salesChannel);
	}
}
