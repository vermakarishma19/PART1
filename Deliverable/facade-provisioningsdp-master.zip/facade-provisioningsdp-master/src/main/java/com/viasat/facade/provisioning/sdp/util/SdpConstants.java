package com.viasat.facade.provisioning.sdp.util;

public class SdpConstants
{
	public static final String CONTACT_TYPE_SERVICE = "Service";

	// catalog
	public static final String INTERNET_ACCESS_SERVICE = "INTERNET_ACCESS_SERVICE";
	public static final String VOIP = "VOIP";
	public static final String ISP_SERVICE = "EMAIL";
	public static final String SDP_SUSPEND_PACKAGE = "SDP_SUSPEND_PACKAGE";

	// provisioning status
	public static final String ACTIVE = "ACTIVE";
	public static final String SUSPENDED = "SUSPENDED";
	public static final String NEW = "NEW";

	public static final String FACADE_OWNER_NAME = "PROVISIONING";
	public static final String COUNTRY_CODE = "US";
	public static final String PHONE_TYPE_PRIMARY = "Primary";

	public static final String PHONE_TYPE_SECONDARY = "Secondary";
	public static final String CONTACT_TYPE_CUSTOMER = "Customer";
	public static final String CONTACT_TYPE_ACCOUNT = "Account";
	public static final String PENDING = "PENDING";
	public static final String DEACTIVATING = "DEACTIVATING";
	public static final String DEACTIVATED = "DEACTIVATED";

	public static final String VB_PRODUCT_NAME = "Liberty18";

}
