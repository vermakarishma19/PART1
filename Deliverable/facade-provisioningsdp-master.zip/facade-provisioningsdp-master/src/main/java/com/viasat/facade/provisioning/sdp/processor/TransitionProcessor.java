package com.viasat.facade.provisioning.sdp.processor;

import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.facade.provisioning.sdp.wrapper.*;
import com.viasat.sdp.api.data.CommandState;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.NewConfigureFixedNTDInput;
import com.viasat.sdp.api.data.NewConfigureLayer3ServiceInput;
import com.viasat.wildblue.common.commondata.BeamTechnicalInfo;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.common.location.GeoPosition;
import com.viasat.wildblue.facade.provisioning.data.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class TransitionProcessor
{
	private static final Logger LOGGER = LoggerFactory.getLogger(TransitionProcessor.class);

	private BusinessTransactionWrapper btsWrapper;
	private CatalogWrapper catalogWrapper;
	private SDPWrapper sdpWrapper;
	private ValidationProcessor validationProcessor;

	public void setContactsWrapper(ContactsWrapper contactsWrapper)
	{
		this.contactsWrapper = contactsWrapper;
	}

	private ContactsWrapper contactsWrapper;

	public void setServiceLocationWrapper(ServiceLocationWrapper serviceLocationWrapper)
	{
		this.serviceLocationWrapper = serviceLocationWrapper;
	}

	private ServiceLocationWrapper serviceLocationWrapper;

	public void setTransactionValidationProcessor(
			TransactionValidationProcessor transactionValidationProcessor)
	{
		this.transactionValidationProcessor = transactionValidationProcessor;
	}

	private TransactionValidationProcessor transactionValidationProcessor;

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.btsWrapper = businessTransactionWrapper;
	}

	public void setCatalogWrapper(CatalogWrapper catalogWrapper)
	{
		this.catalogWrapper = catalogWrapper;
	}

	public void setSdpWrapper(SDPWrapper sdpWrapper)
	{
		this.sdpWrapper = sdpWrapper;
	}

	public void setValidationProcessor(ValidationProcessor validationProcessor)
	{
		this.validationProcessor = validationProcessor;
	}

	public TransitionServiceItemResponse transitionServiceItem(TransitionServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		TransitionServiceItemResponse response = new TransitionServiceItemResponse();

		String svcAgrmtRef = parameter.getServiceAgreementReference();

		// start facade transaction
		String businessTransactionReference = btsWrapper.addBusinessTransaction(
				BusinessTransactionWrapper.TRANSACTION_CANCEL_ADD_CUSTOMER_HIERARCHY,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(), null, null,
				svcAgrmtRef, wildBlueHeader);

		try
		{
			// validate parameters
			ValidateTransitionServiceItemResponse validationResponse = validationProcessor
					.validateTransitionServiceItem(parameter, wildBlueHeader);
			validationProcessor.checkValidationResult(validationResponse.getValidationResult());

			// update facade transaction
			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			// deactivate old service
			sdpWrapper.deactivateLayer3Service(parameter.getOldServiceItemReference());

			// delete old service
			sdpWrapper.deleteLayer3Service(parameter.getOldServiceItemReference());

			// add new service
			NewConfigureLayer3ServiceInput input = new NewConfigureLayer3ServiceInput();
			input.setNtdId(svcAgrmtRef);
			input.setServiceCatalogId(parameter.getNewServiceItem().getCatalogNumber());
			sdpWrapper.configureLayer3Service(
					parameter.getNewServiceItem().getServiceItemReference(), input);

			// activate new service
			sdpWrapper
					.activateLayer3Service(parameter.getNewServiceItem().getServiceItemReference());
		}
		catch (Exception e)
		{
			String msg = "Exception processing transitionServiceItem(): serviceAgreementReference: "
					+ svcAgrmtRef + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		btsWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);

		return response;
	}

	public TransitionServiceEquipmentResponse transitionServiceEquipment(
			TransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		Layer3Service layer3ServiceForVoip = new Layer3Service();
		Layer3Service layerServiceForInternet = new Layer3Service();
		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = new com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem();
		Layer3Service configureLayer3ServiceForVoip = new Layer3Service();

		String transactionType = BusinessTransactionWrapper.TRANSACTION_TRANSITION_SERVICE_EQUIPMENT;

		TransitionServiceEquipmentResponse response = new TransitionServiceEquipmentResponse();

		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String businessTransactionReference = null;
		try
		{

			String accountReference = btsWrapper
					.getAccountReferenceFromInternalServiceAgreementReference(
							serviceAgreementReference, wildBlueHeader);

			businessTransactionReference = btsWrapper.addBusinessTransaction(transactionType,
					SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(), null,
					accountReference, serviceAgreementReference, wildBlueHeader);

			String oldServiceItemReference = parameter.getOldServiceItemReference();

			ServiceItem newServiceItem = parameter.getNewServiceItem();

			ValidateTransitionServiceEquipmentResponse validateTransitionServiceEquipmentResponse = validationProcessor
					.validateTransitionServiceEquipment(parameter, wildBlueHeader);

			validationProcessor.checkValidationResult(
					validateTransitionServiceEquipmentResponse.getValidationResult());

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy = btsWrapper
					.getServiceAgreementHierarchyFromInternalServiceAgreementReference(
							serviceAgreementReference, wildBlueHeader);

			List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
					.map(si -> {
						return si.getMasterCatalogKey();
					}).collect(Collectors.toList());

			GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
					wildBlueHeader);

			CatalogComponent internetComponent = catalogComponents.getComponents().stream()
					.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE.equals(c.getComponentType()))
					.findFirst().orElse(null);

			String internetMCR = internetComponent.getCharges().get(0).getMasterCatalogReference();

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = serviceAgreementHierarchy
					.getServiceItems().stream() // for each serviceItem
					.filter(serviceItem -> internetMCR.equals(serviceItem.getMasterCatalogKey()))
					.findFirst().orElse(null);

			layerServiceForInternet = sdpWrapper
					.getLayer3Service(internetSvcItem.getServiceItemReference());

			if (layerServiceForInternet != null)
			{
				NewConfigureLayer3ServiceInput newConfigureLayer3ServiceForInternet = new NewConfigureLayer3ServiceInput();
				newConfigureLayer3ServiceForInternet
						.setServiceCatalogId(newServiceItem.getCatalogNumber());
				newConfigureLayer3ServiceForInternet.setNtdId(serviceAgreementReference);

				Layer3Service configureLayer3ServiceForInternet = sdpWrapper.configureLayer3Service(
						newServiceItem.getServiceItemReference(),
						newConfigureLayer3ServiceForInternet);

			}
		}
		catch (WebServiceException e)
		{
			String msg = "Exception processing transitionServiceEquipment(): serviceAgreementReference: "
					+ serviceAgreementReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			throw e;
		}
		catch (Exception e)
		{
			String msg = "Exception processing transitionServiceEquipment(): serviceAgreementReference: "
					+ serviceAgreementReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			throw new WildBlueWebServiceException(msg, e);
		}

		btsWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);

		return response;
	}

	public TransitionServiceAgreementResponse transitionServiceAgreement(
			TransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		String transactionType = BusinessTransactionWrapper.TRANSACTION_TRANSITION_SERVICE_AGREEMENT;

		TransitionServiceAgreementResponse response = new TransitionServiceAgreementResponse();

		CustomerHierarchy customerHierarchy = parameter.getCustomerHierarchy();

		Customer customer = customerHierarchy.getCustomer();

		String customerReference = customerHierarchy.getCustomer().getCustomerReference();

		List<AccountHierarchy> accountHierarchyList = customerHierarchy.getAccountHierarchy();

		AccountHierarchy accountHierarchy = accountHierarchyList.get(0);

		Account account = accountHierarchy.getAccount();

		String accountReference = accountHierarchy.getAccount().getAccountReference();

		List<ServiceAgreementHierarchy> serviceAgreementHierarchyList = accountHierarchy
				.getServiceAgreementHierarchy();

		ServiceAgreementHierarchy serviceAgreementHierarchy = serviceAgreementHierarchyList.get(0);

		ServiceAgreement serviceAgreement = serviceAgreementHierarchy.getServiceAgreement();

		String serviceAgreementReference = serviceAgreementHierarchy.getServiceAgreement()
				.getServiceAgreementReference();

		String businessTransactionReference = btsWrapper.addBusinessTransaction(transactionType,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(),
				customerReference, accountReference, serviceAgreementReference, wildBlueHeader);

		AddCustomerHierarchy addCustomerHierarchy = new AddCustomerHierarchy();

		addCustomerHierarchy.setCustomerHierarchy(customerHierarchy);
		addCustomerHierarchy.setTransactionReference(businessTransactionReference);

		try
		{
			ValidateTransitionServiceAgreementResponse validationResponse = validationProcessor
					.validateTransitionServiceAgreement(parameter, wildBlueHeader);
			validationProcessor.checkValidationResult(validationResponse.getValidationResult());

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			// pre-provision modem SDP API NewConfigureFixedNTD
			BeamTechnicalInfo beamInfo = serviceAgreement.getBeamInfo().getBeamTechnicalInfo();
			GeoPosition geoPosition = serviceAgreement.getServiceContact().getContactInfo()
					.getLocation().getGeoPosition();

			NewConfigureFixedNTDInput fixedNTD = new NewConfigureFixedNTDInput();
			fixedNTD.setSatelliteId(
					sdpWrapper.satelliteIdFromSatelliteName(beamInfo.getSatelliteName()));
			fixedNTD.setCsaId(beamInfo.getBeamNumber().toString());
			fixedNTD.setLatitude(BigDecimal.valueOf(geoPosition.getLatitude()));
			fixedNTD.setLongitude(BigDecimal.valueOf(geoPosition.getLongitude()));

			sdpWrapper.configureFixedNTD(serviceAgreementReference, null, fixedNTD);

			// internet-access service
			ServiceItem internetSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
					.filter(si -> "INTERNET_ACCESS_SERVICE".equals(si.getType())).findFirst()
					.orElse(null);

			// add service for internet access
			NewConfigureLayer3ServiceInput internetLayer3Service = new NewConfigureLayer3ServiceInput();
			internetLayer3Service.setServiceCatalogId(internetSvcItem.getCatalogNumber());
			internetLayer3Service.setNtdId(serviceAgreementReference);

			sdpWrapper.configureLayer3Service(internetSvcItem.getServiceItemReference(),
					internetLayer3Service);

			// check for a VoIP service item
			ServiceItem voIpSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
					.filter(si -> "VOIP".equals(si.getType())).findFirst().orElse(null);

			if (voIpSvcItem != null)
			{
				// add service for VoIP
				NewConfigureLayer3ServiceInput voIpLayer3Service = new NewConfigureLayer3ServiceInput();
				voIpLayer3Service.setServiceCatalogId(voIpSvcItem.getCatalogNumber());
				voIpLayer3Service.setNtdId(serviceAgreementReference);

				// TODO pending defect with sdp api
				// https://jira.viasat.com/browse/SDP-6195
				// sdpWrapper.configureLayer3Service(voIpSvcItem.getServiceItemReference(),
				// voIpLayer3Service);
			}
			String deviceProtocol = transactionValidationProcessor.getTransitionFromDeviceProtocol(
					accountReference, ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			if (deviceProtocol.equals("SB"))
			{
				// contact service
				contactsWrapper.createCustomerContactAggregate(customer, serviceAgreementReference,
						accountReference);

				contactsWrapper.createAccountContactAggregate(account, serviceAgreementReference);

			}

			contactsWrapper.createServiceAgreementContactAggregate(serviceAgreement,
					serviceAgreementReference, accountReference);

			// service location
			serviceLocationWrapper.createServiceLocation(serviceAgreementHierarchy,
					ConfigurationConstants.COMMON_WILDBLUE_HEADER);

		}
		catch (Exception e)
		{
			String msg = "Exception processing transitionServiceAgreement(): customerRef: "
					+ customerReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		btsWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);
		return response;
	}

	public TransitionServiceEquipmentCompleteResponse transitionServiceEquipmentComplete(
			TransitionServiceEquipmentComplete parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		String transactionType = BusinessTransactionWrapper.TRANSACTION_TRANSITION_SERVICE_EQUIPMENT_COMPLETE;

		TransitionServiceEquipmentCompleteResponse response = new TransitionServiceEquipmentCompleteResponse();

		String serviceAgreementReference = parameter.getServiceAgreementReference();

		String businessTransactionReference = btsWrapper.addBusinessTransaction(transactionType,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(), null, null,
				serviceAgreementReference, wildBlueHeader);
		String oldServiceItemReference = parameter.getOldServiceItemReference();

		try
		{

			ValidateTransitionServiceEquipmentCompleteResponse validationResult = validationProcessor
					.validateTransitionServiceEquipmentComplete(parameter, wildBlueHeader);

			validationProcessor.checkValidationResult(validationResult.getValidationResult());

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy = btsWrapper
					.getServiceAgreementHierarchyFromInternalServiceAgreementReference(
							serviceAgreementReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem serviceItem = serviceAgreementHierarchy
					.getServiceItems().stream().filter(service -> service.getServiceItemReference()
							.equals(oldServiceItemReference))
					.findFirst().orElse(null);

			if (serviceItem != null)
			{
				String mcKey = serviceItem.getMasterCatalogKey();
				GetComponentsResponse getComponentsResponse = catalogWrapper.getComponent(mcKey,
						wildBlueHeader);

				CatalogComponent internetComponent = getComponentsResponse.getComponents().stream()
						.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE
								.equals(c.getComponentType()))
						.findFirst().orElse(null);

				if (internetComponent != null)
				{
					CommandState commandStateDeactivate = sdpWrapper
							.deactivateLayer3Service(serviceItem.getServiceItemReference());

					if (commandStateDeactivate.equals(CommandState.SUCCEEDED))
					{
						CommandState commandStateDelete = sdpWrapper
								.deleteLayer3Service(serviceItem.getServiceItemReference());
					}
				}

			}

		}
		catch (Exception e)
		{
			String msg = "Exception processing transitionServiceEquipmentComplete(): oldServiceItemReference: "
					+ oldServiceItemReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}
		btsWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);
		return response;

	}

}
