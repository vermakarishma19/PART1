package com.viasat.facade.provisioning.sdp.util;

/**
 * Created by sryally on 12/21/2016.
 */
public enum DeviceProtocol {

    /**
     * Surf beam 1.
     */
    SB,

    /**
     * Surf beam 2.
     */
    SB2,

    AB,

    AB_FIELD_TRIAL;
}
