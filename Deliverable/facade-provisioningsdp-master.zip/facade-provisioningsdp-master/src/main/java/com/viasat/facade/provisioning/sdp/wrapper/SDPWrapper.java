package com.viasat.facade.provisioning.sdp.wrapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.sdp.api.data.CommandState;
import com.viasat.sdp.api.data.FixedNTD;
import com.viasat.sdp.api.data.FixedNtdState;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.Layer3ServiceState;
import com.viasat.sdp.api.data.NewConfigureFixedNTDInput;
import com.viasat.sdp.api.data.NewConfigureLayer3ServiceInput;
import com.viasat.sdp.api.data.NewFixedNTDActivateInput;
import com.viasat.sdp.api.data.NewInterrogateDeviceInput;
import com.viasat.sdp.api.data.SatelliteId;
import com.viasat.sdp.api.data.ServiceArea;
import com.viasat.sdp.client.SDPClient;
import com.viasat.sdp.client.SDPServiceFault;
import com.viasat.wildblue.common.exception.ExceptionDetail;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;

public class SDPWrapper
{
	private static final Logger LOGGER = LoggerFactory.getLogger(SDPWrapper.class);

	private static final String ERR_CODE_NOT_FOUND = "2002";

	private SDPClient sdpClient;

	public void setSdpClient(SDPClient sdpClient)
	{
		this.sdpClient = sdpClient;
	}

	public FixedNTD getFixedNTD(String deviceId) throws WebServiceException
	{
		try
		{
			return sdpClient.getFixedNTD(deviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public boolean pendingFixedNTDExists(String deviceId) throws WebServiceException
	{
		try
		{
			FixedNTD fixedNTD = sdpClient.getFixedNTD(deviceId);
			return (fixedNTD.getState() == FixedNtdState.PENDING);
		}
		catch (SDPServiceFault e)
		{
			if (ERR_CODE_NOT_FOUND.equals(e.getCode()))
				return false;

			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public FixedNTD configureFixedNTD(String deviceId, String mac, NewConfigureFixedNTDInput input)
			throws WebServiceException
	{
		try
		{
			return sdpClient.configureFixedNTD(deviceId, formatMac(mac), input);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public CommandState activateFixedNTD(String deviceId, NewFixedNTDActivateInput input)
			throws WebServiceException
	{
		return null;
	}

	public CommandState deactivateFixedNTD(String deviceId) throws WebServiceException
	{
		try
		{
			return sdpClient.deactivateFixedNTD(deviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public CommandState deleteFixedNTD(String deviceId) throws WebServiceException
	{
		try
		{
			return sdpClient.deleteFixedNTD(deviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public CommandState rebootFixedNTD(String deviceId, String mac) throws WebServiceException
	{
		return null;
	}

	public FixedNTD interrogateDevice(String mac) throws WebServiceException
	{
		NewInterrogateDeviceInput input = new NewInterrogateDeviceInput();
		input.setMacAddress(formatMac(mac));

		try
		{
			return sdpClient.interrogateDevice(input);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public Layer3Service getLayer3Service(String serviceId) throws WebServiceException
	{
		try
		{
			return sdpClient.getLayer3Service(serviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public boolean layer3ServiceExists(String serviceId) throws WebServiceException
	{
		try
		{
			sdpClient.getLayer3Service(serviceId);
			return true;
		}
		catch (SDPServiceFault e)
		{
			if (ERR_CODE_NOT_FOUND.equals(e.getCode()))
				return false;

			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public boolean pendingLayer3ServiceExists(String serviceId) throws WebServiceException
	{
		try
		{
			Layer3Service service = sdpClient.getLayer3Service(serviceId);
			return (service.getState() == Layer3ServiceState.PENDING);
		}
		catch (SDPServiceFault e)
		{
			if (ERR_CODE_NOT_FOUND.equals(e.getCode()))
				return false;

			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public Layer3Service configureLayer3Service(String serviceId,
			NewConfigureLayer3ServiceInput input) throws WebServiceException
	{
		try
		{
			return sdpClient.configureLayer3Service(serviceId, input);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public CommandState activateLayer3Service(String serviceId) throws WebServiceException
	{

		try
		{
			return sdpClient.activateLayer3Service(serviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public CommandState deactivateLayer3Service(String serviceId) throws WebServiceException
	{
		try
		{
			return sdpClient.deactivateLayer3Service(serviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public CommandState deleteLayer3Service(String serviceId) throws WebServiceException
	{
		try
		{
			return sdpClient.deleteLayer3Service(serviceId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public ServiceArea getServiceArea(String serviceAreaId) throws WebServiceException
	{
		try
		{
			return sdpClient.getServiceArea(serviceAreaId);
		}
		catch (SDPServiceFault e)
		{
			throw convertSDPFaultToWebServiceException(e);
		}
	}

	public String getInternetAccessLayer3ServiceStatus(CatalogComponent internetAccessComponent,
			String serviceId) throws WebServiceException
	{
		// get the suspend package target system value from catalog component
		String suspendPackage = internetAccessComponent.getCharges().get(0)
				.getTargetSystemReferences().stream()
				.filter(tsr -> SdpConstants.SDP_SUSPEND_PACKAGE.equals(tsr.getTargetSystemXref()))
				.map(tsr -> tsr.getTargetSystemXrefValue()).findFirst().orElse(null);

		// throws exception if not found
		Layer3Service internetService = getLayer3Service(serviceId);

		if (suspendPackage.equals(internetService.getConfiguration().getServiceCatalogId()))
			return SdpConstants.SUSPENDED;
		else
			return SdpConstants.ACTIVE;
	}

	private WebServiceException convertSDPFaultToWebServiceException(SDPServiceFault e)
	{
		ExceptionDetail ed = new ExceptionDetail();

		String codePfx = (e.getCode() != null ? "Code: " + e.getCode() + " " : "");
		ed.setDetail(codePfx + "Message: " + e.getMessage());

		WildBlueWebServiceException wse = new WildBlueWebServiceException(
				"Received error from SDP API!", ed, e);

		return wse;
	}

	public SatelliteId satelliteIdFromSatelliteName(String name) throws SDPServiceFault
	{
		if ("ViaSat-1".equals(name))
			return SatelliteId.VIASAT_1;

		if ("ViaSat-2".equals(name))
			return SatelliteId.VIASAT_2;

		if ("Anik-F2".equals(name))
			return SatelliteId.ANIK_F_2;

		if ("Anik-F2-SB2".equals(name))
			return SatelliteId.ANIK_F_2;

		if ("WildBlue-1".equals(name))
			return SatelliteId.WB_1;

		if ("WildBlue-1-SB2".equals(name))
			return SatelliteId.WB_1;

		if ("WildBlue-1-AB-Alpha".equals(name))
			return SatelliteId.WB_1;

		throw new SDPServiceFault("Satellite not supported: " + name);
	}

	private String formatMac(String mac)
	{
		if (mac == null)
			return null;

		if (mac.contains(":"))
			return mac.replaceAll(":", "");

		return mac;
	}
}
