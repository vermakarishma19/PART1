package com.viasat.facade.provisioning.sdp.processor;

import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.isp.api.model.IspCommand;
import com.viasat.facade.isp.api.model.TransactionType;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.facade.provisioning.sdp.wrapper.*;
import com.viasat.internalservice.contact.api.model.Contact;
import com.viasat.internalservice.contact.api.model.Contacts;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocation;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocations;
import com.viasat.sdp.api.data.CommandState;
import com.viasat.sdp.api.data.FixedNTD;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.Layer3ServiceState;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.data.*;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreement;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused") // spring beans
public class CancellationProcessor
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CancellationProcessor.class);

	private BusinessTransactionWrapper btsWrapper;
	private CatalogWrapper catalogWrapper;
	private ContactsWrapper contactsWrapper;
	private SDPWrapper sdpWrapper;
	private ServiceLocationWrapper serviceLocationWrapper;
	private ValidationProcessor validationProcessor;
	private FetchProcessor fetchProcessor;
	private ISPWrapper ispWrapper;

	public void setIspWrapper(ISPWrapper ispWrapper)
	{
		this.ispWrapper = ispWrapper;
	}

	public void setTransactionValidationProcessor(
			TransactionValidationProcessor transactionValidationProcessor)
	{
		this.transactionValidationProcessor = transactionValidationProcessor;
	}

	private TransactionValidationProcessor transactionValidationProcessor;

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.btsWrapper = businessTransactionWrapper;
	}

	public void setCatalogWrapper(CatalogWrapper catalogWrapper)
	{
		this.catalogWrapper = catalogWrapper;
	}

	public void setContactsWrapper(ContactsWrapper contactsWrapper)
	{
		this.contactsWrapper = contactsWrapper;
	}

	public void setSdpWrapper(SDPWrapper sdpWrapper)
	{
		this.sdpWrapper = sdpWrapper;
	}

	public void setServiceLocationWrapper(ServiceLocationWrapper serviceLocationWrapper)
	{
		this.serviceLocationWrapper = serviceLocationWrapper;
	}

	public void setValidationProcessor(ValidationProcessor validationProcessor)
	{
		this.validationProcessor = validationProcessor;
	}

	public CancelAddCustomerHierarchyResponse cancelAddCustomerHierarchy(
			CancelAddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		CancelAddCustomerHierarchyResponse response = new CancelAddCustomerHierarchyResponse();

		// find associated newConnect transaction
		// throws exception if no result
		SoaTransactionXml soaTrans = btsWrapper.getSoaTransactionByInternalReference(
				parameter.getTargetTransactionReference(), wildBlueHeader);
		String extSystemName = soaTrans.getExternalSystemName();
		String extSvcAgreementRef = soaTrans.getExternalServiceAgreementReference();
		String extAccountRef = soaTrans.getExternalAccountReference();

		// get service agreement ref for facade transaction
		ServiceAgreement btsSvcAgreement = btsWrapper.getServiceAgreementByExternalReference(
				extSvcAgreementRef, extSystemName, wildBlueHeader);
		String serviceAgreementRef = btsSvcAgreement.getServiceAgreementReference();
		String accountRef = btsSvcAgreement.getAccountReference();

		// start facade transaction
		String businessTransactionReference = btsWrapper.addBusinessTransaction(
				BusinessTransactionWrapper.TRANSACTION_CANCEL_ADD_CUSTOMER_HIERARCHY,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(), null, null,
				serviceAgreementRef, wildBlueHeader);

		try
		{
			// validate parameters
			ValidateCancelAddCustomerHierarchyResponse validationResponse = validationProcessor
					.validateCancelAddCustomerHierarchy(parameter, wildBlueHeader);
			validationProcessor.checkValidationResult(validationResponse.getValidationResult());

			// update facade transaction
			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			// get bts customer hierarchy
			com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustHierarchy = btsWrapper
					.getCustomerHierarchyByInternalServiceAgreementReference(serviceAgreementRef,
							wildBlueHeader);

			// filter account and service agreement
			AccountHierarchy btsAcctHierarchy = btsCustHierarchy.getAccounts().stream()
					.filter(a -> extAccountRef.equals(a.getExternalAccountReference())).findFirst()
					.orElse(null);
			ServiceAgreementHierarchy btsServiceAgrmtHierarchy = btsAcctHierarchy
					.getServiceAgreements().stream()
					.filter(s -> serviceAgreementRef.equals(s.getServiceAgreementReference()))
					.findFirst().orElse(null);

			// extract list of catalog refs
			List<String> mcrs = btsServiceAgrmtHierarchy.getServiceItems().stream()
					.map(ServiceItem::getMasterCatalogKey).collect(Collectors.toList());

			// get catalog components to associate type
			GetComponentsResponse catalogComponents = catalogWrapper.getComponents(mcrs,
					wildBlueHeader);

			// filter internet component
			CatalogComponent internetComponent = catalogComponents.getComponents().stream()
					.filter(c -> "INTERNET_ACCESS_SERVICE".equals(c.getComponentType())).findFirst()
					.orElse(null);

			// associate internet service component to bts service item
			String internetMCR = internetComponent.getCharges().get(0).getMasterCatalogReference();
			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = btsServiceAgrmtHierarchy
					.getServiceItems().stream() // for each serviceItem
					.filter(serviceItem -> internetMCR.equals(serviceItem.getMasterCatalogKey()))
					.findFirst().orElse(null);

			// delete internet service in SDP
			sdpWrapper.deleteLayer3Service(internetSvcItem.getServiceItemReference());

			// filter voip component
			CatalogComponent voipComponent = catalogComponents.getComponents().stream()
					.filter(c -> "VOIP".equals(c.getComponentType())).findFirst().orElse(null);

			// skip if no voip
			if (voipComponent != null)
			{
				// associate voip service component to bts service item
				String voipCatalogRef = voipComponent.getCharges().get(0)
						.getMasterCatalogReference();
				com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = btsServiceAgrmtHierarchy
						.getServiceItems().stream()
						.filter(si -> voipCatalogRef.equals(si.getMasterCatalogKey())).findFirst()
						.orElse(null);

				// delete voip service in SDP
				sdpWrapper.deleteLayer3Service(voipSvcItem.getServiceItemReference());
			}

			// delete device in SDP
			sdpWrapper.deleteFixedNTD(serviceAgreementRef);

			// delete (end date) contacts
			contactsWrapper.deleteAllContactAggregates(btsAcctHierarchy.getAccountReference(),
					serviceAgreementRef, wildBlueHeader);

			// delete (end date) service locations
			serviceLocationWrapper.deleteServiceLocationAggregates(serviceAgreementRef,
					wildBlueHeader);
		}
		catch (Exception e)
		{
			String msg = "Exception processing cancelAddCustomerHierarchy(): serviceAgreementReference: "
					+ serviceAgreementRef + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		btsWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);
		return response;
	}

	public DisconnectAccountResponse disconnectAccount(DisconnectAccount parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{

		String transactionType = BusinessTransactionWrapper.TRANSACTION_DISCONNECT_ACCOUNT;

		TransactionType transactionTypeIn = TransactionType.DELETE;
		Layer3Service layer3Service = new Layer3Service();

		DisconnectAccountResponse response = new DisconnectAccountResponse();

		String accountRef = parameter.getAccountReference();

		String businessTransactionReference = btsWrapper.addBusinessTransaction(transactionType,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(), null,
				accountRef, null, wildBlueHeader);
		try
		{

			ValidateDisconnectAccountResponse validateDisconnectAccountResponse = validationProcessor
					.validateDisconnectAccount(parameter, wildBlueHeader);

			validationProcessor
					.checkValidationResult(validateDisconnectAccountResponse.getValidationResult());

			// ValidateDisconnectAccountResponse validateResponse
			// =transactionValidationProcessor.validateDisconnectAccount(parameter,wildBlueHeader);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			AccountHierarchy btsAccountHierarchy;

			btsAccountHierarchy = btsWrapper.getAccountHierarchyByInternalReference(accountRef,
					ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
					.getServiceAgreements();

			for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
			{

				AccountHierarchy accountHierarchy = btsWrapper
						.getAccountHierarchyByInternalReference(accountRef, wildBlueHeader);
				List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
						.map(si -> {
							return si.getMasterCatalogKey();
						}).collect(Collectors.toList());

				GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
						wildBlueHeader);
				// InternetComponent
				CatalogComponent internetComponent = catalogComponents.getComponents().stream()
						.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE
								.equals(c.getComponentType()))
						.findFirst().orElse(null);

				String internetMCR = internetComponent.getCharges().get(0)
						.getMasterCatalogReference();

				com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = serviceAgreementHierarchy
						.getServiceItems().stream() // for each serviceItem
						.filter(serviceItem -> internetMCR
								.equals(serviceItem.getMasterCatalogKey()))
						.findFirst().orElse(null);

				layer3Service = sdpWrapper
						.getLayer3Service(internetSvcItem.getServiceItemReference());

				if (layer3Service.getState().equals(Layer3ServiceState.ACTIVE))
				{
					CommandState commandStateDeactivateInternetAccess = sdpWrapper
							.deactivateLayer3Service(internetSvcItem.getServiceItemReference());

					if (commandStateDeactivateInternetAccess.equals(CommandState.SUCCEEDED))
					{
						CommandState commandStateDeleteInternetAccess = sdpWrapper
								.deleteLayer3Service(internetSvcItem.getServiceItemReference());
					}

					// voipComponent
					CatalogComponent voipComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
							.orElse(null);

					if (voipComponent != null)
					{
						String voipMcr = voipComponent.getCharges().get(0)
								.getMasterCatalogReference();

						com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = serviceAgreementHierarchy
								.getServiceItems().stream() // for each
								// serviceItem
								.filter(serviceItem -> voipMcr
										.equals(serviceItem.getMasterCatalogKey()))
								.findFirst().orElse(null);

						Layer3Service layer3ServiceVoip = sdpWrapper
								.getLayer3Service(voipSvcItem.getServiceItemReference());

						if (layer3ServiceVoip.getState().equals(SdpConstants.ACTIVE))

						{
							CommandState commandStateDeactivateVoip = sdpWrapper
									.deactivateLayer3Service(voipSvcItem.getServiceItemReference());

							if (commandStateDeactivateVoip.equals(CommandState.SUCCEEDED))
							{
								CommandState commandStateDeleteVoip = sdpWrapper
										.deleteLayer3Service(voipSvcItem.getServiceItemReference());
							}
						}
					}
					// FixedNtd Component

					FixedNTD fixedNTD = sdpWrapper
							.getFixedNTD(serviceAgreementHierarchy.getServiceAgreementReference());

					if (fixedNTD != null)
					{
						CommandState commandStateDeactivatefixedNTD = sdpWrapper.deactivateFixedNTD(
								serviceAgreementHierarchy.getServiceAgreementReference());
						if (commandStateDeactivatefixedNTD.equals(CommandState.SUCCEEDED))
						{
							CommandState commandStateDeletefixedNTD = sdpWrapper.deleteFixedNTD(
									serviceAgreementHierarchy.getServiceAgreementReference());
						}

						// isp

						CatalogComponent ispComponent = catalogComponents.getComponents().stream()
								.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
								.findFirst().orElse(null);

						if (ispComponent != null)
						{
							String ispMCR = ispComponent.getCharges().get(0)
									.getMasterCatalogReference();
							com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem ispSvcItem = serviceAgreementHierarchy
									.getServiceItems().stream() // for each
									// serviceItem
									.filter(serviceItem -> ispMCR
											.equals(serviceItem.getMasterCatalogKey()))
									.findFirst().orElse(null);

							if (ispSvcItem != null)
							{
								IspCommand ispCommandsIn = new IspCommand();
								ispCommandsIn.setIspAccountId(new BigDecimal(
										serviceAgreementHierarchy.getServiceAgreementReference()));
								ispCommandsIn.setTransactionType(transactionTypeIn);

								ispWrapper.createIspCommands(new BigDecimal(
										serviceAgreementHierarchy.getServiceAgreementReference()),
										ispCommandsIn);
							}

						}

						Contacts customerContacts = contactsWrapper.getCustomerContacts(
								serviceAgreementHierarchy.getServiceAgreementReference(), null,
								null);
						if (customerContacts != null && customerContacts.size() > 0)
						{
							Contact customerContact = customerContacts.stream()
									.filter(contact -> contact.getEndDate()
											.compareTo(OffsetDateTime.now()) == 1)
									.findAny().orElse(null);
						}

						Contacts accountContacts = contactsWrapper.getAccountContacts(
								serviceAgreementHierarchy.getServiceAgreementReference(), null,
								null);
						if (accountContacts != null && accountContacts.size() > 0)
						{
							Contact accountContact = accountContacts.stream()
									.filter(contact -> contact.getEndDate()
											.compareTo(OffsetDateTime.now()) == 1)
									.findAny().orElse(null);
						}

						Contacts serviceAgreementContacts = contactsWrapper
								.getServiceAgreementContacts(
										serviceAgreementHierarchy.getServiceAgreementReference(),
										null, null);
						if (serviceAgreementContacts != null && serviceAgreementContacts.size() > 0)
						{

							Contact serviceAgreementContact = serviceAgreementContacts.stream()
									.filter(contact -> contact.getEndDate()
											.compareTo(OffsetDateTime.now()) == 1)
									.findAny().orElse(null);

							if (serviceAgreementContact != null)
							{
								contactsWrapper.deleteContactAggregate(
										serviceAgreementContact.getContactId());
							}
						}

						ServiceLocations serviceLocations = serviceLocationWrapper
								.getServiceLocations(
										serviceAgreementHierarchy.getServiceAgreementReference(),
										null, ConfigurationConstants.COMMON_WILDBLUE_HEADER);
						if (serviceLocations != null && serviceLocations.size() > 0)
						{

							ServiceLocation serviceLocation = serviceLocations.stream()
									.filter(contact -> contact.getEndDate()
											.compareTo(OffsetDateTime.now()) == 1)
									.findAny().orElse(null);

							if (serviceLocation != null)
							{
								serviceLocationWrapper.deleteServiceLocationAggregates(
										serviceAgreementHierarchy.getServiceAgreementReference(),
										ConfigurationConstants.COMMON_WILDBLUE_HEADER);
							}

						}

					}

				}
			}
		}

		catch (InternalServiceFault internalServiceFault)
		{
			String msg = "Exception processing DisconnectAccount(): Account Reference: "
					+ accountRef + ", Error: " + internalServiceFault.getMessage();
			LOGGER.error(msg, internalServiceFault);
		}
		catch (Exception e)
		{

			String msg = "Exception processing DisconnectAccount(): Account Reference: "
					+ accountRef + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);
		}
		return response;

	}

	public DisconnectServiceItemResponse disconnectServiceItem(DisconnectServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{

		String transactionType = BusinessTransactionWrapper.TRANSACTION_DISCONNECT_SERVICE_ITEM;

		TransactionType transactionTypeIn = TransactionType.DELETE;
		Layer3Service layer3Service = new Layer3Service();

		DisconnectServiceItemResponse response = new DisconnectServiceItemResponse();

		String serviceItemReference = parameter.getServiceItemReference();

		CustomerHierarchy btsCustomerHierarchy;

		btsCustomerHierarchy = btsWrapper.getCustomerHierarchyByInternalServiceItemReference(
				serviceItemReference, wildBlueHeader);
		AccountHierarchy btsAccountHierarchy = btsCustomerHierarchy.getAccounts().get(0);

		List<ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
				.getServiceAgreements();

		ServiceAgreementHierarchy serviceAgreementHierarchy = serviceAgreementHierarchies.stream()
				.findFirst().orElse(null);

		String serviceAgreementReference = serviceAgreementHierarchy.getServiceAgreementReference();

		String businessTransactionReference = btsWrapper.addBusinessTransaction(transactionType,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(),
				btsAccountHierarchy.getCustomerReference(),
				btsAccountHierarchy.getAccountReference(), serviceAgreementReference,
				wildBlueHeader);

		try
		{

			ValidateDisconnectServiceItemResponse validateDisconnectServiceItemResponse = validationProcessor
					.validateDisconnectServiceItem(parameter, wildBlueHeader);

			validationProcessor.checkValidationResult(
					validateDisconnectServiceItemResponse.getValidationResult());

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem serviceItem = serviceAgreementHierarchy
					.getServiceItems().stream()
					.filter(service -> parameter.getServiceItemReference()
							.compareTo(service.getServiceItemReference()) == 0)
					.findFirst().orElse(null);

			String mcKey = serviceItem.getMasterCatalogKey();
			GetComponentsResponse getComponentsResponse = catalogWrapper.getComponent(mcKey,
					wildBlueHeader);

			CatalogComponent voipComponent = getComponentsResponse.getComponents().stream()
					.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
					.orElse(null);

			if (voipComponent != null)
			{

				com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = serviceAgreementHierarchy
						.getServiceItems().stream() // for each
						// serviceItem
						.filter(service -> mcKey.equals(service.getMasterCatalogKey())).findFirst()
						.orElse(null);

				if (voipSvcItem != null)
				{

					CommandState commandStateDeactivateVoip = sdpWrapper
							.deactivateLayer3Service(voipSvcItem.getServiceItemReference());

					if (commandStateDeactivateVoip.equals(CommandState.SUCCEEDED))
					{
						CommandState commandStateDeleteVoip = sdpWrapper
								.deleteLayer3Service(voipSvcItem.getServiceItemReference());
					}

				}
			}
		}
		catch (Exception e)
		{

			String msg = "Exception processing DisconnectServiceItem(): ServiceAgrementReference: "
					+ serviceAgreementReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);
		}

		return response;

	}

	public CancelTransitionServiceAgreementResponse cancelTransitionServiceAgreement(
			CancelTransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{

		CancelTransitionServiceAgreementResponse cancelTransitionServiceAgreementResponse = new CancelTransitionServiceAgreementResponse();
		String transactionType = BusinessTransactionWrapper.TRANSACTION_CANCEL_TRANSITION_SERVICE_AGREEMENT;

		String targetTransactionRef = parameter.getTargetTransactionReference();

		SoaTransactionXml soaTrans = btsWrapper.getSoaTransactionByInternalReference(
				parameter.getTargetTransactionReference(), wildBlueHeader);

		String extSystemName = soaTrans.getExternalSystemName();
		String extSvcAgreementRef = soaTrans.getExternalServiceAgreementReference();
		String extAccountRef = soaTrans.getExternalAccountReference();

		// get service agreement ref for facade transaction
		ServiceAgreement btsSvcAgreement = btsWrapper.getServiceAgreementByExternalReference(
				extSvcAgreementRef, extSystemName, wildBlueHeader);
		String serviceAgreementRef = btsSvcAgreement.getServiceAgreementReference();
		String accountRef = btsSvcAgreement.getAccountReference();

		String businessTransactionReference = btsWrapper.addBusinessTransaction(transactionType,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(), null, null,
				serviceAgreementRef, wildBlueHeader);

		try
		{
			// validate parameters
			ValidateCancelTransitionServiceAgreementResponse validationResponse = validationProcessor
					.validateCancelTransitionServiceAgreement(parameter, wildBlueHeader);
			validationProcessor.checkValidationResult(validationResponse.getValidationResult());

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			// get bts customer hierarchy
			com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustHierarchy = btsWrapper
					.getCustomerHierarchyByInternalServiceAgreementReference(serviceAgreementRef,
							wildBlueHeader);

			// filter account and service agreement
			AccountHierarchy btsAcctHierarchy = btsCustHierarchy.getAccounts().stream()
					.filter(a -> extAccountRef.equals(a.getExternalAccountReference())).findFirst()
					.orElse(null);
			ServiceAgreementHierarchy btsServiceAgrmtHierarchy = btsAcctHierarchy
					.getServiceAgreements().stream()
					.filter(s -> serviceAgreementRef.equals(s.getServiceAgreementReference()))
					.findFirst().orElse(null);

			// extract list of catalog refs
			List<String> mcrs = btsServiceAgrmtHierarchy.getServiceItems().stream()
					.map(ServiceItem::getMasterCatalogKey).collect(Collectors.toList());

			// get catalog components to associate type
			GetComponentsResponse catalogComponents = catalogWrapper.getComponents(mcrs,
					wildBlueHeader);

			// filter internet component
			CatalogComponent internetComponent = catalogComponents.getComponents().stream()
					.filter(c -> "INTERNET_ACCESS_SERVICE".equals(c.getComponentType())).findFirst()
					.orElse(null);

			// associate internet service component to bts service item
			String internetMCR = internetComponent.getCharges().get(0).getMasterCatalogReference();
			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = btsServiceAgrmtHierarchy
					.getServiceItems().stream() // for each serviceItem
					.filter(serviceItem -> internetMCR.equals(serviceItem.getMasterCatalogKey()))
					.findFirst().orElse(null);

			// delete internet service in SDP
			sdpWrapper.deleteLayer3Service(internetSvcItem.getServiceItemReference());

			// filter voip component
			CatalogComponent voipComponent = catalogComponents.getComponents().stream()
					.filter(c -> "VOIP".equals(c.getComponentType())).findFirst().orElse(null);

			// skip if no voip
			if (voipComponent != null)
			{
				// associate voip service component to bts service item
				String voipCatalogRef = voipComponent.getCharges().get(0)
						.getMasterCatalogReference();
				com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = btsServiceAgrmtHierarchy
						.getServiceItems().stream()
						.filter(si -> voipCatalogRef.equals(si.getMasterCatalogKey())).findFirst()
						.orElse(null);

				// delete voip service in SDP
				sdpWrapper.deleteLayer3Service(voipSvcItem.getServiceItemReference());
			}

			// delete device in SDP
			sdpWrapper.deleteFixedNTD(serviceAgreementRef);

			String deviceProtocol = btsServiceAgrmtHierarchy.getDeviceProtocol();

			if (deviceProtocol.equals("SB"))
			{
				Contacts customerContacts = contactsWrapper.getCustomerContacts(
						btsServiceAgrmtHierarchy.getAccountReference(), null, null);

				if (customerContacts != null && customerContacts.size() > 0)
				{

					for (com.viasat.internalservice.contact.api.model.Contact custContact : customerContacts)
					{
						BigDecimal contactId = custContact.getContactId();
						// only delete if it's not already deleted
						if (contactId != null
								&& (custContact.getEndDate().isAfter(OffsetDateTime.now())
										|| custContact.getEndDate().isEqual(OffsetDateTime.now())))
							contactsWrapper.deleteContactAggregate(contactId);
					}
				}

				Contacts accountContacts = contactsWrapper.getAccountContacts(
						btsServiceAgrmtHierarchy.getAccountReference(), null, null);

				if (accountContacts != null && accountContacts.size() > 0)
				{
					for (com.viasat.internalservice.contact.api.model.Contact accountContact : accountContacts)
					{
						BigDecimal contactId = accountContact.getContactId();
						// only delete if it's not already deleted
						if (contactId != null && (accountContact.getEndDate()
								.isAfter(OffsetDateTime.now())
								|| accountContact.getEndDate().isEqual(OffsetDateTime.now())))
							contactsWrapper.deleteContactAggregate(contactId);
					}
				}

			}

			Contacts serviceAgreementContacts = contactsWrapper.getServiceAgreementContacts(
					btsServiceAgrmtHierarchy.getServiceAgreementReference(), null, null);

			if (serviceAgreementContacts != null && serviceAgreementContacts.size() > 0)
			{
				for (com.viasat.internalservice.contact.api.model.Contact svcContact : serviceAgreementContacts)
				{
					BigDecimal contactId = svcContact.getContactId();
					// only delete if it's not already deleted
					if (contactId != null && (svcContact.getEndDate().isAfter(OffsetDateTime.now())
							|| svcContact.getEndDate().isEqual(OffsetDateTime.now())))
						contactsWrapper.deleteContactAggregate(contactId);
				}

			}

			ServiceLocations serviceLocations = serviceLocationWrapper.getServiceLocations(
					btsServiceAgrmtHierarchy.getServiceAgreementReference(), null, wildBlueHeader);

			if (serviceLocations != null && serviceLocations.size() > 0)
			{
				for (ServiceLocation serviceLocation : serviceLocations)
				{
					BigDecimal serviceLocationId = serviceLocation.getServiceLocationId();
					// only delete if it's not already deleted
					if (serviceLocationId != null
							&& (serviceLocation.getEndDate().isAfter(OffsetDateTime.now())
									|| serviceLocation.getEndDate().isEqual(OffsetDateTime.now())))
						serviceLocationWrapper.deleteServiceLocationAgggregate(serviceLocationId);
				}
			}

		}
		catch (Exception e)
		{
			String msg = "Exception processing cancelTransitionServiceAgreement(): serviceAgreementReference: "
					+ serviceAgreementRef + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			btsWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		btsWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);
		return cancelTransitionServiceAgreementResponse;

	}

}
