package com.viasat.facade.provisioning.sdp.wrapper;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.internalservice.contact.api.model.ContactAggregate;
import com.viasat.internalservice.contact.api.model.ContactAggregates;
import com.viasat.internalservice.contact.api.model.ContactRole;
import com.viasat.internalservice.contact.api.model.ContactRoleType;
import com.viasat.internalservice.contact.api.model.ContactRoleTypes;
import com.viasat.internalservice.contact.api.model.ContactRoles;
import com.viasat.internalservice.contact.api.model.Contacts;
import com.viasat.internalservice.contact.api.model.EmailAddress;
import com.viasat.internalservice.contact.api.model.EmailAddressAggregate;
import com.viasat.internalservice.contact.api.model.EmailAddressAggregates;
import com.viasat.internalservice.contact.api.model.EmailAddressLight;
import com.viasat.internalservice.contact.api.model.PhoneNumberAggregate;
import com.viasat.internalservice.contact.api.model.PhoneNumberAggregates;
import com.viasat.internalservice.contact.api.model.PostalAddressAggregate;
import com.viasat.internalservice.contact.api.model.PostalAddressAggregates;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.fault.utils.FaultUtil;
import com.viasat.wildblue.common.commondata.Contact;
import com.viasat.wildblue.common.commondata.ContactInfo;
import com.viasat.wildblue.common.commondata.Person;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.common.location.Location;
import com.viasat.wildblue.facade.provisioning.data.Account;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.CorrectedContact;
import com.viasat.wildblue.facade.provisioning.data.Customer;
import com.viasat.wildblue.facade.provisioning.data.CustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.ServiceAgreement;

public class ContactsWrapper
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ContactsWrapper.class);

	public static final String CUSTOMER_CONTACT_ROLE_TYPE = "CUSTOMER_CONTACT";
	public static final String ACCOUNT_CONTACT_ROLE_TYPE = "ACCOUNT_CONTACT";
	public static final String SERVICE_AGREEMENT_CONTACT_ROLE_TYPE = "SERVICE_AGREEMENT_CONTACT";
	// cancel constants
	private static final String PENDING_STATUS = "PENDING";

	private ContactServiceClient contactService;

	public void setContactService(ContactServiceClient contactService)
	{
		this.contactService = contactService;
	}

	private ContactRoles createContactRoles(String serviceAgreementReference, String accountId,
											String customerRoleType)
	{
		ContactRoles contactRoles = new ContactRoles();
		ContactRole contactRole = new ContactRole();
		// Business rules being enforced defined in the design
		// If CONTACT_ROLE_TYPE = CUSTOMER_CONTACT then ACCOUNT_ID must be
		// populated
		// If CONTACT_ROLE_TYPE = ACCOUNT_CONTACT then ACCOUNT_ID must be
		// populated
		// If CONTACT_ROLE_TYPE = SERVICE_CONTACT then SERVICE_AGREEMENT_ID must
		// be populated
		// If CONTACT_ROLE_TYPE = SHIPPING_CONTACT then SERVICE_AGREEMENT_ID
		// must be populated

		if (serviceAgreementReference != null
				&& customerRoleType.equals(SERVICE_AGREEMENT_CONTACT_ROLE_TYPE))
			contactRole.setServiceAgreementId(new BigDecimal(serviceAgreementReference));

		if (accountId != null && (customerRoleType.equals(CUSTOMER_CONTACT_ROLE_TYPE)
				|| customerRoleType.equals(ACCOUNT_CONTACT_ROLE_TYPE)))
			contactRole.setAccountId(new BigDecimal(accountId));

		ContactRoleTypes contactRoleTypes = new ContactRoleTypes();
		ContactRoleType contactRoleType = new ContactRoleType();
		contactRoleType.setContactRoleType(customerRoleType);
		contactRoleTypes.add(contactRoleType);

		contactRole.setContactRoleType(contactRoleTypes);

		contactRoles.add(contactRole);

		return contactRoles;
	}

	private PostalAddressAggregates createPostalAggregates(Location location)
	{
		PostalAddressAggregates postalAddressAggregates = new PostalAddressAggregates();

		PostalAddressAggregate postalAddressAggregate = new PostalAddressAggregate();

		postalAddressAggregate.setAddressLine1(location.getAddress().getAddressLine().get(0));
		if (location.getAddress().getAddressLine().size() > 1)
		{
			postalAddressAggregate.setAddressLine2(location.getAddress().getAddressLine().get(1));
		}
		postalAddressAggregate.setMunicipality(location.getAddress().getMunicipality());
		postalAddressAggregate.setRegion(location.getAddress().getRegion());
		postalAddressAggregate.setPostalCode(location.getAddress().getPostalCode());
		postalAddressAggregate.setCountryCode(location.getAddress().getCountryCode());

		postalAddressAggregates.add(postalAddressAggregate);

		return postalAddressAggregates;
	}

	private PhoneNumberAggregates createPhoneNumberAggregates(ContactInfo contactInfo)
	{
		String primaryPhone = formatPhone(contactInfo.getPrimaryPhone());
		String secondaryPhone = formatPhone(contactInfo.getSecondaryPhone());

		PhoneNumberAggregates phoneNumberAggregates = new PhoneNumberAggregates();
		PhoneNumberAggregate phoneNumberAggregate = new PhoneNumberAggregate();

		if (primaryPhone == null)
		{
			if (secondaryPhone == null)
				// no valid phone numbers provided, this was acceptable in VB
				return null;
			else
				// this mimics the behavior of the data migration script
				phoneNumberAggregate.setPrimaryPhoneNumber(secondaryPhone);
		}
		else
		{
			phoneNumberAggregate.setPrimaryPhoneNumber(primaryPhone);
			phoneNumberAggregate.setSecondaryPhoneNumber(secondaryPhone);
		}

		phoneNumberAggregates.add(phoneNumberAggregate);
		return phoneNumberAggregates;
	}

	private String formatPhone(String phone)
	{
		if (phone == null)
			return null;

		return phone.toUpperCase().replaceAll("[^0-9X]", "");
	}

	private EmailAddressAggregates createEmailAddressAggregates(ContactInfo contactInfo)
	{
		EmailAddressAggregates emailAddressAggregates = new EmailAddressAggregates();
		EmailAddressAggregate emailAddressAggregate = new EmailAddressAggregate();
		emailAddressAggregate.setEmailAddress(contactInfo.getEmailAddress());
		emailAddressAggregates.add(emailAddressAggregate);

		return emailAddressAggregates;
	}

	public ContactAggregate createCustomerContactAggregate(Customer customer,
														   String serviceAgreementReference, String accountReference) throws WebServiceException
	{
		ContactAggregate contactAggregate = new ContactAggregate();

		// Customer Contact
		com.viasat.wildblue.common.commondata.Contact customerContact = customer
				.getCustomerContact();
		Location location = customerContact.getContactInfo().getLocation();

		// basic contact
		contactAggregate.setFirstName(customer.getCustomerContact().getPerson().getFirstName());
		contactAggregate.setLastName(customer.getCustomerContact().getPerson().getLastName());
		contactAggregate.setMiddleName(customer.getCustomerContact().getPerson().getMiddleName());
		contactAggregate.setSuffix(customer.getCustomerContact().getPerson().getSuffix());

		// contact role
		ContactRoles contactRoles = createContactRoles(serviceAgreementReference, accountReference,
				CUSTOMER_CONTACT_ROLE_TYPE);
		contactAggregate.setContactRoles(contactRoles);

		// PostalAddress
		PostalAddressAggregates postalAddressAggregates = createPostalAggregates(location);
		contactAggregate.setPostalAddresses(postalAddressAggregates);

		// PhoneNumbers
		ContactInfo contactInfo = customerContact.getContactInfo();
		PhoneNumberAggregates phoneNumberAggregates = createPhoneNumberAggregates(contactInfo);
		contactAggregate.setPhoneNumbers(phoneNumberAggregates);

		// EmailAddress
		EmailAddressAggregates emailAddressAggregates = createEmailAddressAggregates(contactInfo);
		contactAggregate.setEmailAddresses(emailAddressAggregates);

		return (contactAggregate);
	}

	public ContactAggregate createAccountContactAggregate(Account account,
														  String serviceAgreementReference)
	{
		ContactAggregate contactAggregate = new ContactAggregate();

		Contact accountContact = account.getAccountContact();
		Location location = accountContact.getContactInfo().getLocation();
		ContactInfo contactInfo = accountContact.getContactInfo();

		// basic contact
		contactAggregate.setFirstName(account.getAccountContact().getPerson().getFirstName());
		contactAggregate.setLastName(account.getAccountContact().getPerson().getLastName());
		contactAggregate.setMiddleName(account.getAccountContact().getPerson().getMiddleName());
		contactAggregate.setSuffix(account.getAccountContact().getPerson().getSuffix());

		// contact role
		String accountId = account.getAccountReference();
		ContactRoles contactRoles = createContactRoles(serviceAgreementReference, accountId,
				ACCOUNT_CONTACT_ROLE_TYPE);
		contactAggregate.setContactRoles(contactRoles);

		// PostalAddress
		PostalAddressAggregates postalAddressAggregates = createPostalAggregates(location);
		contactAggregate.setPostalAddresses(postalAddressAggregates);

		// PhoneNumbers
		PhoneNumberAggregates phoneNumberAggregates = createPhoneNumberAggregates(contactInfo);
		contactAggregate.setPhoneNumbers(phoneNumberAggregates);

		// EmailAddress
		EmailAddressAggregates emailAddressAggregates = createEmailAddressAggregates(contactInfo);
		contactAggregate.setEmailAddresses(emailAddressAggregates);

		return (contactAggregate);
	}

	public ContactAggregate createServiceAgreementContactAggregate(
			ServiceAgreement serviceAgreement, String serviceAgreementReference,
			String accountReference)
	{
		ContactAggregate contactAggregate = new ContactAggregate();

		Contact serviceContactContact = serviceAgreement.getServiceContact();
		Location location = serviceContactContact.getContactInfo().getLocation();
		ContactInfo contactInfo = serviceContactContact.getContactInfo();

		// basic contact
		contactAggregate.setFirstName(serviceContactContact.getPerson().getFirstName());
		contactAggregate.setLastName(serviceContactContact.getPerson().getLastName());
		contactAggregate.setMiddleName(serviceContactContact.getPerson().getMiddleName());
		contactAggregate.setSuffix(serviceContactContact.getPerson().getSuffix());

		// contact role
		ContactRoles contactRoles = createContactRoles(serviceAgreementReference, accountReference,
				SERVICE_AGREEMENT_CONTACT_ROLE_TYPE);
		contactAggregate.setContactRoles(contactRoles);

		// PostalAddress
		PostalAddressAggregates postalAddressAggregates = createPostalAggregates(location);
		contactAggregate.setPostalAddresses(postalAddressAggregates);

		// PhoneNumbers
		PhoneNumberAggregates phoneNumberAggregates = createPhoneNumberAggregates(contactInfo);
		contactAggregate.setPhoneNumbers(phoneNumberAggregates);

		// EmailAddress
		EmailAddressAggregates emailAddressAggregates = createEmailAddressAggregates(contactInfo);
		contactAggregate.setEmailAddresses(emailAddressAggregates);

		return (contactAggregate);
	}

	public void createContactAggregate(AddCustomerHierarchy addCustomerHierarchy, String user,
									   String application) throws WebServiceException
	{
		try
		{
			CustomerHierarchy customerHierarchy = addCustomerHierarchy.getCustomerHierarchy();

			String accountReference = customerHierarchy.getAccountHierarchy().get(0).getAccount()
					.getAccountReference();

			String serviceAgreementReference = customerHierarchy.getAccountHierarchy().get(0)
					.getServiceAgreementHierarchy().get(0).getServiceAgreement()
					.getServiceAgreementReference();

			// Customer Contact
			Customer customer = customerHierarchy.getCustomer();

			ContactAggregate customerContactAggregate = createCustomerContactAggregate(customer,
					serviceAgreementReference, accountReference);

			customerContactAggregate = contactService
					.createContactAggregate(customerContactAggregate, user, application);

			// Account Contact
			Account account = customerHierarchy.getAccountHierarchy().get(0).getAccount();

			ContactAggregate accountContactAggregate = createAccountContactAggregate(account,
					serviceAgreementReference);

			contactService.createContactAggregate(accountContactAggregate, user, application);

			// Service Contact
			ServiceAgreement serviceAgreement = customerHierarchy.getAccountHierarchy().get(0)
					.getServiceAgreementHierarchy().get(0).getServiceAgreement();

			ContactAggregate serviceAgreementContactAggregate = createServiceAgreementContactAggregate(
					serviceAgreement, serviceAgreementReference, accountReference);

			contactService.createContactAggregate(serviceAgreementContactAggregate, user,
					application);
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("createContactAggregate", e);
		}
	}

	private Contacts getContacts(BigDecimal accountId, BigDecimal serviceAgreementId,
								 String contactRoleType, String user, String application) throws WebServiceException
	{
		if (user == null)
			user = ContactsWrapper.class.getSimpleName();
		if (application == null)
			application = "F-PVB";

		try
		{
			// this should be using Contacts not a raw list
			OffsetDateTime endDate = OffsetDateTime.parse("2099-12-31T00:00:00Z");
			List<com.viasat.internalservice.contact.api.model.Contact> contacts = contactService
					.getContacts(accountId, serviceAgreementId, null, null, null, null, null,
							contactRoleType, null, endDate, null, null, user, application);

			Contacts resp = new Contacts();
			resp.addAll(contacts);
			return resp;
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("getContacts", e);
		}
	}

	public Contacts getCustomerContacts(String accountRef, String user, String application)
			throws WebServiceException
	{
		// use the account reference instead of the customer reference because
		// the database has a referential integrity constraint
		BigDecimal accountId = new BigDecimal(accountRef);

		return getContacts(accountId, null, CUSTOMER_CONTACT_ROLE_TYPE, user, application);
	}

	public Contacts getAccountContacts(String accountRef, String user, String application)
			throws WebServiceException
	{
		BigDecimal accountId = new BigDecimal(accountRef);

		return getContacts(accountId, null, ACCOUNT_CONTACT_ROLE_TYPE, user, application);
	}

	public Contacts getServiceAgreementContacts(String serviceAgreementRef, String user,
												String application) throws WebServiceException
	{

		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);

		return getContacts(null, serviceAgreementId, SERVICE_AGREEMENT_CONTACT_ROLE_TYPE, user,
				application);
	}

	private ContactAggregates getContactAggregates(BigDecimal accountId,
												   BigDecimal serviceAgreementId, String contactRoleType, String user, String application)
			throws WebServiceException
	{
		try
		{
			OffsetDateTime endDate = OffsetDateTime.parse("2099-12-31T00:00:00Z");
			return contactService.getContactAggregates(accountId, serviceAgreementId, null, null,
					null, null, null, contactRoleType, null, endDate, null, null, user,
					application);
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("getContactAggregates", e);
		}
	}

	public ContactAggregates getCustomerContactAggregates(String accountRef, String user,
														  String application) throws WebServiceException
	{
		BigDecimal accountId = new BigDecimal(accountRef);

		return getContactAggregates(accountId, null, CUSTOMER_CONTACT_ROLE_TYPE, user, application);
	}

	public ContactAggregates getAccountContactAggregates(String accountRef, String user,
														 String application) throws WebServiceException
	{
		BigDecimal accountId = new BigDecimal(accountRef);

		return getContactAggregates(accountId, null, ACCOUNT_CONTACT_ROLE_TYPE, user, application);
	}

	public ContactAggregates getServiceAgreementContactAggregates(String serviceAgreementRef,
																  String user, String application) throws Exception
	{
		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);

		return getContactAggregates(null, serviceAgreementId, SERVICE_AGREEMENT_CONTACT_ROLE_TYPE,
				user, application);
	}

	public void deleteServiceAgreementContact(String serviceAgreementRef, String user,
											  String application) throws WebServiceException
	{
		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);

		List<com.viasat.internalservice.contact.api.model.Contact> contacts = getContacts(null,
				serviceAgreementId, SERVICE_AGREEMENT_CONTACT_ROLE_TYPE, user, application);

		try
		{
			for (com.viasat.internalservice.contact.api.model.Contact contact : contacts)
			{
				if (contact.getContactId() != null)
					contactService.deleteContactAggregate(contact.getContactId());
			}
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("deleteContactAggregate", e);
		}
	}

	public void updateContactEmailAddress(String serviceAgreementRef, String accountRef,
										  String emailAdd) throws WebServiceException
	{
		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);
		BigDecimal accountId = new BigDecimal(accountRef);
		EmailAddress emailAddress = new EmailAddress();

		// Account Contact
		List<com.viasat.internalservice.contact.api.model.Contact> contacts = getContacts(accountId,
				serviceAgreementId, ACCOUNT_CONTACT_ROLE_TYPE, null, null);
		try
		{
			for (com.viasat.internalservice.contact.api.model.Contact contact : contacts)
			{
				BigDecimal contactId = contact.getContactId();
				emailAddress.setEmailAddress(emailAdd);
				ArrayList<EmailAddressLight> emailLight = contact.getEmailAddresses();
				if (CollectionUtils.isNotEmpty(emailLight))
				{
					BigDecimal emailAddressID = emailLight.get(0).getEmailAddressId();
					contactService.updateEmailAddress(contactId, emailAddressID, emailAddress);
				}
			}
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("updateEmailAddress", e);
		}
	}

	public void updateAccountContactName(Person person, String accountRef, String user,
										 String application) throws WebServiceException
	{
		// Convert the serviceAgreementRef and accountRef from string to
		// BigDecimal for database access
		BigDecimal accountId = new BigDecimal(accountRef);

		// Get Contact
		List<com.viasat.internalservice.contact.api.model.Contact> contacts = getContacts(accountId,
				null, ACCOUNT_CONTACT_ROLE_TYPE, user, application);

		try
		{
			if (contacts.size() > 0)
			{
				for (com.viasat.internalservice.contact.api.model.Contact contact : contacts)
				{
					if (person.getFirstName().equals(""))
						person.setFirstName(null);
					contact.setFirstName(person.getFirstName());
					if (person.getMiddleName().equals(""))
						person.setMiddleName(null);
					contact.setMiddleName(person.getMiddleName());
					if (person.getLastName().equals(""))
						person.setLastName(null);
					contact.setLastName(person.getLastName());
					if (person.getSuffix().equals(""))
						person.setSuffix(null);
					contact.setSuffix(person.getSuffix());
					contact.setContactId(contact.getContactId());
					BigDecimal contactId = new BigDecimal(contact.getContactId().toString());
					// update Contact
					contactService.updateContact(contactId, contact);
				}
			}
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("updateContact", e);
		}
	}

	public void deleteAllContactAggregates(String accountRef, String serviceAgreementRef,
										   WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// maybe refactor this method out and just use header only?
		deleteAllContactAggregates(accountRef, serviceAgreementRef,
				getUserFromHeader(wildBlueHeader), getAppFromHeader(wildBlueHeader));
	}

	public void deleteAllContactAggregates(String accountRef, String serviceAgreementRef,
										   String user, String application) throws WebServiceException
	{
		BigDecimal accountId = new BigDecimal(accountRef);
		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);

		// Get Contacts
		List<com.viasat.internalservice.contact.api.model.Contact> customerContacts = getContacts(
				accountId, null, CUSTOMER_CONTACT_ROLE_TYPE, user, application);

		List<com.viasat.internalservice.contact.api.model.Contact> accountContacts = getContacts(
				accountId, null, ACCOUNT_CONTACT_ROLE_TYPE, user, application);

		List<com.viasat.internalservice.contact.api.model.Contact> serviceContacts = getContacts(
				null, serviceAgreementId, SERVICE_AGREEMENT_CONTACT_ROLE_TYPE, user, application);

		try
		{
			for (com.viasat.internalservice.contact.api.model.Contact custContact : customerContacts)
			{
				BigDecimal contactId = custContact.getContactId();
				// only delete if it's not already deleted
				if (contactId != null && (custContact.getEndDate().isAfter(OffsetDateTime.now())
						|| custContact.getEndDate().isEqual(OffsetDateTime.now())))
					contactService.deleteContactAggregate(contactId);
			}

			for (com.viasat.internalservice.contact.api.model.Contact accountContact : accountContacts)
			{
				BigDecimal contactId = accountContact.getContactId();
				// only delete if it's not already deleted
				if (contactId != null && (accountContact.getEndDate().isAfter(OffsetDateTime.now())
						|| accountContact.getEndDate().isEqual(OffsetDateTime.now())))
					contactService.deleteContactAggregate(contactId);
			}

			for (com.viasat.internalservice.contact.api.model.Contact svcContact : serviceContacts)
			{
				BigDecimal contactId = svcContact.getContactId();
				// only delete if it's not already deleted
				if (contactId != null && (svcContact.getEndDate().isAfter(OffsetDateTime.now())
						|| svcContact.getEndDate().isEqual(OffsetDateTime.now())))
					contactService.deleteContactAggregate(contactId);
			}

		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("deleteContactAggregate", e);
		}
	}

	public void updateAllContactAggregates(String serviceAgreementRef, String accountRef,
										   CorrectedContact cc, String user, String application) throws WebServiceException
	{
		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);
		BigDecimal accountId = new BigDecimal(accountRef);

		List<ContactAggregate> customerContactAggregates = getContactAggregates(accountId, null,
				CUSTOMER_CONTACT_ROLE_TYPE, user, application);
		List<ContactAggregate> accountContactAggregates = getContactAggregates(accountId, null,
				ACCOUNT_CONTACT_ROLE_TYPE, user, application);
		List<ContactAggregate> serviceContactAggregates = getContactAggregates(null,
				serviceAgreementId, SERVICE_AGREEMENT_CONTACT_ROLE_TYPE, user, application);

		try
		{
			for (ContactAggregate customerContactAgg : customerContactAggregates)
			{
				updateContactAggregate(customerContactAgg, cc);
				contactService.updateContactAggregate(customerContactAgg.getContactId(),
						customerContactAgg);
			}

			for (ContactAggregate accountContactAgg : accountContactAggregates)
			{
				updateContactAggregate(accountContactAgg, cc);
				contactService.updateContactAggregate(accountContactAgg.getContactId(),
						accountContactAgg);
			}

			for (ContactAggregate serviceContactAgg : serviceContactAggregates)
			{
				updateContactAggregate(serviceContactAgg, cc);
				contactService.updateContactAggregate(serviceContactAgg.getContactId(),
						serviceContactAgg);
			}
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("updateContactAggregate", e);
		}
	}

	public void updateContactAggregate(ContactAggregate contactAggregate,
									   CorrectedContact correctedContact)
	{
		if (correctedContact == null)
			return;

		if (correctedContact.getPerson() != null)
		{

			if (correctedContact.getPerson().getFirstName() != null)
				contactAggregate.setFirstName(correctedContact.getPerson().getFirstName());

			if (correctedContact.getPerson().getMiddleName() != null)
				contactAggregate.setMiddleName(correctedContact.getPerson().getMiddleName());

			if (correctedContact.getPerson().getLastName() != null)
				contactAggregate.setLastName(correctedContact.getPerson().getLastName());

			if (correctedContact.getPerson().getSuffix() != null)
				contactAggregate.setSuffix(correctedContact.getPerson().getSuffix());
		}

		// updating PostalAddress
		List<PostalAddressAggregate> postalAddressAggs = contactAggregate.getPostalAddresses();

		if (CollectionUtils.isNotEmpty(postalAddressAggs))
		{

			if (correctedContact.getServiceAddress() != null)
			{
				if (correctedContact.getServiceAddress().getCountryCode() != null)
					postalAddressAggs.get(0)
							.setCountryCode(correctedContact.getServiceAddress().getCountryCode());

				if (correctedContact.getServiceAddress().getMunicipality() != null)
					postalAddressAggs.get(0).setMunicipality(
							correctedContact.getServiceAddress().getMunicipality());

				if (correctedContact.getServiceAddress().getRegion() != null)
					postalAddressAggs.get(0)
							.setRegion(correctedContact.getServiceAddress().getRegion());

				if (correctedContact.getServiceAddress().getPostalCode() != null)
					postalAddressAggs.get(0)
							.setPostalCode(correctedContact.getServiceAddress().getPostalCode());

				if (correctedContact.getServiceAddress().getAddressLine() != null)
				{
					List<String> addressLine = correctedContact.getServiceAddress()
							.getAddressLine();
					if (!addressLine.isEmpty())
						postalAddressAggs.get(0).setAddressLine1(addressLine.get(0));
					if (addressLine.size() == 2)
						postalAddressAggs.get(0).setAddressLine2(addressLine.get(1));
				}
				contactAggregate.setPostalAddresses((PostalAddressAggregates) postalAddressAggs);
			}
		}

		// Updating PhoneNumbers
		List<PhoneNumberAggregate> phoneNumbers = contactAggregate.getPhoneNumbers();
		if (CollectionUtils.isNotEmpty(phoneNumbers))
		{

			if (correctedContact.getPhonePrimary() != null)
				phoneNumbers.get(0).setPrimaryPhoneNumber(correctedContact.getPhonePrimary());

			if (correctedContact.getPhoneSecondary() != null)
				phoneNumbers.get(0).setSecondaryPhoneNumber(correctedContact.getPhoneSecondary());

			contactAggregate.setPhoneNumbers((PhoneNumberAggregates) phoneNumbers);
		}

		// Updating EmailAddress
		List<EmailAddressAggregate> emails = contactAggregate.getEmailAddresses();
		if (CollectionUtils.isNotEmpty(emails))
		{

			if (correctedContact.getEmailAddress() != null)
				emails.get(0).setEmailAddress(correctedContact.getEmailAddress());

			contactAggregate.setEmailAddresses((EmailAddressAggregates) emails);
		}
	}

	private String getUserFromHeader(WildBlueHeader wbHeader)
	{
		if (wbHeader != null && wbHeader.getInvokedBy() != null)
			return wbHeader.getInvokedBy().getUsername();

		return null;
	}

	private String getAppFromHeader(WildBlueHeader wbHeader)
	{
		if (wbHeader != null && wbHeader.getInvokedBy() != null)
			return wbHeader.getInvokedBy().getApplication();

		return null;
	}

	private WebServiceException convertInternalServiceFaultToWebServiceException(String request,
																				 InternalServiceFault e)
	{
		String msg = "Failed to call IS-Contact: " + request;
		LOGGER.error(msg, e);
		return new WildBlueWebServiceException(msg,
				FaultUtil.internalServiceFaultToExceptionDetail(e));
	}

	public void deleteContactAggregate(BigDecimal contactId) throws InternalServiceFault
	{
		contactService.deleteContactAggregate(contactId);
	}
}