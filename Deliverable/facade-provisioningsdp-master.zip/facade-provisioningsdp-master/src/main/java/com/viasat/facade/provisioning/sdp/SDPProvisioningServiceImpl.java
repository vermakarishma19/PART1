package com.viasat.facade.provisioning.sdp;

import com.viasat.facade.provisioning.sdp.processor.*;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.*;

import javax.jws.WebService;

@WebService(endpointInterface = "com.viasat.wildblue.facade.provisioning.ProvisioningService", wsdlLocation = "wsdl/ProvisioningService.wsdl", targetNamespace = "http://www.wildblue.viasat.com/WSDL/v4/ProvisioningFacade", portName = "ProvisioningServiceEndpoint", serviceName = "ProvisioningService")
public class SDPProvisioningServiceImpl implements ProvisioningService
{
	private ValidationProcessor validationProcessor;
	private TransactionValidationProcessor transactionValidationProcessor;
	private CancellationProcessor cancellationProcessor;
	private CreationProcessor creationProcessor;
	private FetchProcessor fetchProcessor;
	private SuspendResumeProcessor suspendResumeProcessor;
	private TransitionProcessor transitionProcessor;
	private UpdateProcessor updateProcessor;

	public void setValidationProcessor(ValidationProcessor validationProcessor)
	{
		this.validationProcessor = validationProcessor;
	}

	public void setTransactionValidationProcessor(
			TransactionValidationProcessor transactionValidationProcessor)
	{
		this.transactionValidationProcessor = transactionValidationProcessor;
	}

	public void setCancellationProcessor(CancellationProcessor cancellationProcessor)
	{
		this.cancellationProcessor = cancellationProcessor;
	}

	public void setUpdateProcessor(UpdateProcessor updateProcessor)
	{
		this.updateProcessor = updateProcessor;
	}

	public void setCreationProcessor(CreationProcessor creationProcessor)
	{
		this.creationProcessor = creationProcessor;
	}

	public void setFetchProcessor(FetchProcessor fetchProcessor)
	{
		this.fetchProcessor = fetchProcessor;
	}

	public void setSuspendResumeProcessor(SuspendResumeProcessor suspendResumeProcessor)
	{
		this.suspendResumeProcessor = suspendResumeProcessor;
	}

	public void setTransitionProcessor(TransitionProcessor transitionProcessor)
	{
		this.transitionProcessor = transitionProcessor;
	}

	@Override
	public AddCustomerHierarchyResponse addCustomerHierarchy(AddCustomerHierarchy parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return creationProcessor.addCustomerHierarchy(parameter, wildBlueHeader);
	}

	@Override
	public AddServiceItemResponse addServiceItem(AddServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return creationProcessor.addServiceItem(parameter, wildBlueHeader);
	}

	@Override
	public AddUsageQuotaResponse addUsageQuota(AddUsageQuota parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public AdjustUsageResponse adjustUsage(AdjustUsage parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public CancelAddCustomerHierarchyResponse cancelAddCustomerHierarchy(
			CancelAddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return cancellationProcessor.cancelAddCustomerHierarchy(parameter, wildBlueHeader);
	}

	@Override
	public CancelTransitionServiceAgreementResponse cancelTransitionServiceAgreement(
			CancelTransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return cancellationProcessor.cancelTransitionServiceAgreement(parameter, wildBlueHeader);
	}

	@Override
	public CancelTransitionServiceEquipmentResponse cancelTransitionServiceEquipment(
			CancelTransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return null;
	}

	@Override
	public DisconnectAccountResponse disconnectAccount(DisconnectAccount parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return cancellationProcessor.disconnectAccount(parameter, wildBlueHeader);
	}

	@Override
	public DisconnectServiceAgreementResponse disconnectServiceAgreement(
			DisconnectServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return null;
	}

	@Override
	public DisconnectServiceItemResponse disconnectServiceItem(DisconnectServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return cancellationProcessor.disconnectServiceItem(parameter, wildBlueHeader);
	}

	@Override
	public GetAccountResponse getAccount(GetAccount parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return fetchProcessor.getAccount(parameter, SdpConstants.CONTACT_TYPE_ACCOUNT);
	}

	@Override
	public GetAccountHierarchyResponse getAccountHierarchy(GetAccountHierarchy parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return fetchProcessor.getAccountHierarchy(parameter, wildBlueHeader);
	}

	@Override
	public GetAllServiceAgreementHierarchiesResponse getAllServiceAgreementHierarchies(
			GetAllServiceAgreementHierarchies parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return fetchProcessor.getAllServiceAgreementHierarchies(parameter,wildBlueHeader);
	}

	@Override
	public GetContactsForAccountsResponse getContactsForAccounts(GetContactsForAccounts parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return fetchProcessor.getContactsForAccounts(parameter);
	}

	@Override
	public GetCustomerResponse getCustomer(GetCustomer parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return fetchProcessor.getCustomer(parameter);
	}

	@Override
	public GetCustomerHierarchyResponse getCustomerHierarchy(GetCustomerHierarchy parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return fetchProcessor.getCustomerHierarchy(parameter, wildBlueHeader);
	}

	@Override
	public GetMacHistoryResponse getMacHistory(GetMacHistory parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return null;
	}

	@Override
	public GetProvisioningDetailsResponse getProvisioningDetails(GetProvisioningDetails parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return fetchProcessor.getProvisioningDetails(parameter, wildBlueHeader);
	}

	@Override
	public GetRemainingBuyMoreQuotaResponse getRemainingBuyMoreQuota(
			GetRemainingBuyMoreQuota parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public GetServiceAgreementResponse getServiceAgreement(GetServiceAgreement parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return fetchProcessor.getServiceAgreement(parameter, wildBlueHeader);
	}

	@Override
	public GetServiceAgreementHierarchyResponse getServiceAgreementHierarchy(
			GetServiceAgreementHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return fetchProcessor.getServiceAgreementHierarchy(parameter, wildBlueHeader);
	}

	@Override
	public GetServiceItemResponse getServiceItem(GetServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return fetchProcessor.getSeviceItem(parameter, wildBlueHeader);
	}

	@Override
	public GetServiceProviderResponse getServiceProvider(GetServiceProvider parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return null;
	}

	@Override
	public GetServiceProvisioningStatusResponse getServiceProvisioningStatus(
			GetServiceProvisioningStatus parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return fetchProcessor.getServiceProvisioningStatus(parameter, wildBlueHeader);
	}

	@Override
	public OverrideSatelliteResponse overrideSatellite(OverrideSatellite parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public RemoveUsageQuotaResponse removeUsageQuota(RemoveUsageQuota parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ResumeAllServiceAgreementsResponse resumeAllServiceAgreements(
			ResumeAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return suspendResumeProcessor.resumeAllServiceAgreements(parameter, wildBlueHeader);
	}

	@Override
	public SuspendAllServiceAgreementsResponse suspendAllServiceAgreements(
			SuspendAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return suspendResumeProcessor.suspendAllServiceAgreements(parameter, wildBlueHeader);
	}

	@Override
	public TransitionServiceAgreementResponse transitionServiceAgreement(
			TransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return transitionProcessor.transitionServiceAgreement(parameter, wildBlueHeader);
	}

	@Override
	public TransitionServiceEquipmentResponse transitionServiceEquipment(
			TransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return transitionProcessor.transitionServiceEquipment(parameter, wildBlueHeader);
	}

	@Override
	public TransitionServiceEquipmentCompleteResponse transitionServiceEquipmentComplete(
			TransitionServiceEquipmentComplete parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return transitionProcessor.transitionServiceEquipmentComplete(parameter, wildBlueHeader);
	}

	@Override
	public TransitionServiceItemResponse transitionServiceItem(TransitionServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return transitionProcessor.transitionServiceItem(parameter, wildBlueHeader);
	}

	@Override
	public UpdateAccountContactAddressResponse updateAccountContactAddress(
			UpdateAccountContactAddress parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateAccountContactEmailResponse updateAccountContactEmail(
			UpdateAccountContactEmail parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateAccountContactNameResponse updateAccountContactName(
			UpdateAccountContactName parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateAccountContactPhoneResponse updateAccountContactPhone(
			UpdateAccountContactPhone parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateContactsResponse updateContacts(UpdateContacts parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return updateProcessor.updateContacts(parameter, wildBlueHeader);
	}

	@Override
	public UpdateCustomerContactAddressResponse updateCustomerContactAddress(
			UpdateCustomerContactAddress parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateCustomerContactEmailResponse updateCustomerContactEmail(
			UpdateCustomerContactEmail parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateCustomerContactNameResponse updateCustomerContactName(
			UpdateCustomerContactName parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateCustomerContactPhoneResponse updateCustomerContactPhone(
			UpdateCustomerContactPhone parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateEquipmentResponse updateEquipment(UpdateEquipment parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return null;
	}

	@Override
	public UpdateServiceContactEmailResponse updateServiceContactEmail(
			UpdateServiceContactEmail parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateServiceContactNameResponse updateServiceContactName(
			UpdateServiceContactName parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateServiceContactPhoneResponse updateServiceContactPhone(
			UpdateServiceContactPhone parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public UpdateVolumeCapDateResponse updateVolumeCapDate(UpdateVolumeCapDate parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateAddCustomerHierarchyResponse validateAddCustomerHierarchy(
			AddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateAddCustomerHierarchyResponse response = validationProcessor
				.validateAddCustomerHierarchy(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateAddCustomerHierarchy(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateAddServiceItemResponse validateAddServiceItem(AddServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateAddServiceItemResponse response = validationProcessor
				.validateAddServiceItem(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateAddServiceItem(parameter, wildBlueHeader);

		return response;
	}

	@Override
	public ValidateAddUsageQuotaResponse validateAddUsageQuota(AddUsageQuota parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateCancelAddCustomerHierarchyResponse validateCancelAddCustomerHierarchy(
			CancelAddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelAddCustomerHierarchyResponse response = validationProcessor
				.validateCancelAddCustomerHierarchy(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateCancelAddCustomerHierarchy(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateCancelTransitionServiceAgreementResponse validateCancelTransitionServiceAgreement(
			CancelTransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelTransitionServiceAgreementResponse response = validationProcessor
				.validateCancelTransitionServiceAgreement(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor
					.validateCancelTransitionServiceAgreement(parameter, wildBlueHeader);

		return response;
	}

	@Override
	public ValidateCancelTransitionServiceEquipmentResponse validateCancelTransitionServiceEquipment(
			CancelTransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelTransitionServiceEquipmentResponse response = validationProcessor
				.validateCancelTransitionServiceEquipment(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor
					.validateCancelTransitionServiceEquipment(parameter, wildBlueHeader);

		return response;
	}

	@Override
	public ValidateDisconnectAccountResponse validateDisconnectAccount(DisconnectAccount parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateDisconnectAccountResponse response = validationProcessor
				.validateDisconnectAccount(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateDisconnectAccount(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateDisconnectServiceAgreementResponse validateDisconnectServiceAgreement(
			DisconnectServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateDisconnectServiceAgreementResponse response = validationProcessor
				.validateDisconnectServiceAgreement(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateDisconnectServiceAgreement(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateDisconnectServiceItemResponse validateDisconnectServiceItem(
			DisconnectServiceItem parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateDisconnectServiceItemResponse response = validationProcessor
				.validateDisconnectServiceItem(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateDisconnectServiceItem(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateOverrideSatelliteResponse validateOverrideSatellite(OverrideSatellite parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateRemoveUsageQuotaResponse validateRemoveUsageQuota(RemoveUsageQuota parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateResumeAllServiceAgreementsResponse validateResumeAllServiceAgreements(
			ResumeAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateResumeAllServiceAgreementsResponse response = validationProcessor
				.validateResumeAllServiceAgreements(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateResumeAllServiceAgreements(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateSuspendAllServiceAgreementsResponse validateSuspendAllServiceAgreements(
			SuspendAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateSuspendAllServiceAgreementsResponse response = validationProcessor
				.validateSuspendAllServiceAgreements(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateSuspendAllServiceAgreements(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateTransitionServiceAgreementResponse validateTransitionServiceAgreement(
			TransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceAgreementResponse response = validationProcessor
				.validateTransitionServiceAgreement(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateTransitionServiceAgreement(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateTransitionServiceEquipmentResponse validateTransitionServiceEquipment(
			TransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceEquipmentResponse response = validationProcessor
				.validateTransitionServiceEquipment(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateTransitionServiceEquipment(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateTransitionServiceEquipmentCompleteResponse validateTransitionServiceEquipmentComplete(
			TransitionServiceEquipmentComplete parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceEquipmentCompleteResponse response = validationProcessor
				.validateTransitionServiceEquipmentComplete(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor
					.validateTransitionServiceEquipmentComplete(parameter, wildBlueHeader);

		return response;
	}

	@Override
	public ValidateTransitionServiceItemResponse validateTransitionServiceItem(
			TransitionServiceItem parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceItemResponse response = validationProcessor
				.validateTransitionServiceItem(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateTransitionServiceItem(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateUpdateAccountContactAddressResponse validateUpdateAccountContactAddress(
			UpdateAccountContactAddress parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateAccountContactEmailResponse validateUpdateAccountContactEmail(
			UpdateAccountContactEmail parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateAccountContactNameResponse validateUpdateAccountContactName(
			UpdateAccountContactName parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateAccountContactPhoneResponse validateUpdateAccountContactPhone(
			UpdateAccountContactPhone parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateContactsResponse validateUpdateContacts(UpdateContacts parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateUpdateContactsResponse response = validationProcessor
				.validateUpdateContacts(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateUpdateContacts(parameter, wildBlueHeader);

		return response;
	}

	@Override
	public ValidateUpdateCustomerContactAddressResponse validateUpdateCustomerContactAddress(
			UpdateCustomerContactAddress parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateCustomerContactEmailResponse validateUpdateCustomerContactEmail(
			UpdateCustomerContactEmail parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateCustomerContactNameResponse validateUpdateCustomerContactName(
			UpdateCustomerContactName parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateCustomerContactPhoneResponse validateUpdateCustomerContactPhone(
			UpdateCustomerContactPhone parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateEquipmentResponse validateUpdateEquipment(UpdateEquipment parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateUpdateEquipmentResponse response = validationProcessor
				.validateUpdateEquipment(parameter, wildBlueHeader);

		if (response.getValidationResult() == null)
			return transactionValidationProcessor.validateUpdateEquipment(parameter,
					wildBlueHeader);

		return response;
	}

	@Override
	public ValidateUpdateServiceContactEmailResponse validateUpdateServiceContactEmail(
			UpdateServiceContactEmail parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateServiceContactNameResponse validateUpdateServiceContactName(
			UpdateServiceContactName parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateServiceContactPhoneResponse validateUpdateServiceContactPhone(
			UpdateServiceContactPhone parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		// not used
		return null;
	}

	@Override
	public ValidateUpdateVolumeCapDateResponse validateUpdateVolumeCapDate(
			UpdateVolumeCapDate parameter, WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		// not used
		return null;
	}
}
