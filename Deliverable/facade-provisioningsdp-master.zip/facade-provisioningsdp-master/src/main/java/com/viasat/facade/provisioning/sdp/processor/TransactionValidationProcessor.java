package com.viasat.facade.provisioning.sdp.processor;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.isp.api.model.IspAccount;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.facade.provisioning.sdp.wrapper.BusinessTransactionWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.CatalogWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ContactsWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ISPWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.SDPWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ServiceLocationWrapper;
import com.viasat.internalservice.contact.api.model.ContactAggregate;
import com.viasat.internalservice.contact.api.model.Contacts;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocation;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocationAggregates;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocations;
import com.viasat.sdp.api.data.FixedNTD;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.Layer3ServiceState;
import com.viasat.wildblue.common.commondata.ValidationError;
import com.viasat.wildblue.common.commondata.ValidationResult;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.data.AccountHierarchy;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.AddServiceItem;
import com.viasat.wildblue.facade.provisioning.data.CancelAddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.CancelTransitionServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.CancelTransitionServiceEquipment;
import com.viasat.wildblue.facade.provisioning.data.CorrectedContact;
import com.viasat.wildblue.facade.provisioning.data.CustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.DisconnectAccount;
import com.viasat.wildblue.facade.provisioning.data.DisconnectServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.DisconnectServiceItem;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatus;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatusResponse;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.ServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.ServiceAgreementHierarchy;
import com.viasat.wildblue.facade.provisioning.data.ServiceItem;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceEquipment;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceEquipmentComplete;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceItem;
import com.viasat.wildblue.facade.provisioning.data.UpdateContacts;
import com.viasat.wildblue.facade.provisioning.data.UpdateEquipment;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelAddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelTransitionServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelTransitionServiceEquipmentResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectAccountResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateResumeAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateSuspendAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceEquipmentCompleteResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceEquipmentResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateUpdateContactsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateUpdateEquipmentResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.DeviceTypeAttribute;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementDevice;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.SoaTransactionXml;

@SuppressWarnings("unused") // spring beans
public class TransactionValidationProcessor
{
	private static final Logger LOGGER = LoggerFactory
			.getLogger(TransactionValidationProcessor.class);
	private static final String SB = "SB";

	private ResourceBundle messageBundle = ResourceBundle.getBundle("validationErrors");

	private BusinessTransactionWrapper btsWrapper;
	private CatalogWrapper catalogWrapper;
	private ServiceLocationWrapper svcLocWrapper;
	private SDPWrapper sdpWrapper;

	public void setContactsWrapper(ContactsWrapper contactsWrapper)
	{
		this.contactsWrapper = contactsWrapper;
	}

	private ContactsWrapper contactsWrapper;

	public void setIspWrapper(ISPWrapper ispWrapper)
	{
		this.ispWrapper = ispWrapper;
	}

	private ISPWrapper ispWrapper;

	public void setFetchProcessor(FetchProcessor fetchProcessor)
	{
		this.fetchProcessor = fetchProcessor;
	}

	private FetchProcessor fetchProcessor;

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.btsWrapper = businessTransactionWrapper;
	}

	public void setCatalogWrapper(CatalogWrapper catalogWrapper)
	{
		this.catalogWrapper = catalogWrapper;
	}

	public void setServiceLocationWrapper(ServiceLocationWrapper serviceLocationWrapper)
	{
		this.svcLocWrapper = serviceLocationWrapper;
	}

	public void setSdpWrapper(SDPWrapper sdpWrapper)
	{
		this.sdpWrapper = sdpWrapper;
	}

	public ValidateAddCustomerHierarchyResponse validateAddCustomerHierarchy(
			AddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateAddCustomerHierarchyResponse response = new ValidateAddCustomerHierarchyResponse();
		ValidationResult result = new ValidationResult();

		CustomerHierarchy customerHierarchy = parameter.getCustomerHierarchy();

		AccountHierarchy accountHierarchy = customerHierarchy.getAccountHierarchy().get(0);

		ServiceAgreementHierarchy serviceAgreementHierarchy = accountHierarchy
				.getServiceAgreementHierarchy().get(0);
		ServiceAgreement serviceAgreement = serviceAgreementHierarchy.getServiceAgreement();
		String serviceAgreementReference = serviceAgreement.getServiceAgreementReference();

		// internet-access service
		ServiceItem internetSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
				.filter(si -> "INTERNET_ACCESS_SERVICE".equals(si.getType())).findFirst()
				.orElse(null);

		if (sdpWrapper.layer3ServiceExists(internetSvcItem.getServiceItemReference()))
			addValidationError(result, "accountFound");

		// optional VoIP service item
		ServiceItem voIPSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
				.filter(si -> "VOIP".equals(si.getType())).findFirst().orElse(null);

		if (voIPSvcItem != null
				&& sdpWrapper.layer3ServiceExists(voIPSvcItem.getServiceItemReference()))
			addValidationError(result, "voIPFound");

		// get customer code from BeamTechnicalInfo
		String customerCode = serviceAgreement.getBeamInfo().getBeamTechnicalInfo()
				.getCustomerCode();
		// fall back on service agreement reference
		if (customerCode == null || customerCode.isEmpty())
			customerCode = serviceAgreementReference;

		if (!svcLocWrapper.getServiceLocations(null, customerCode, wildBlueHeader).isEmpty())
			addValidationError(result, "CustomerCodeAlreadyExists");

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateAddServiceItemResponse validateAddServiceItem(AddServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		ValidateAddServiceItemResponse response = new ValidateAddServiceItemResponse();
		ValidationResult result = new ValidationResult();

		String serviceAgreementReference = parameter.getServiceAgreementReference();

		String voIPSvcItem = parameter.getServiceItem().getType();

		if (voIPSvcItem.equals(SdpConstants.VOIP))
		{
			Layer3Service layer3Service = sdpWrapper
					.getLayer3Service(parameter.getServiceItem().getServiceItemReference());
			if (layer3Service != null)
			{
				addValidationError(result, "AccountAlreadyExists");
				response.setValidationResult(result);
				return response;
			}

		}
		return response;
	}

	public ValidateCancelAddCustomerHierarchyResponse validateCancelAddCustomerHierarchy(
			CancelAddCustomerHierarchy parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateCancelAddCustomerHierarchyResponse response = new ValidateCancelAddCustomerHierarchyResponse();
		ValidationResult result = new ValidationResult();

		// find associated newConnect transaction
		// retrieving external account info
		String extAcctRef;
		String extSystemName;
		try
		{
			// find associated newConnect transaction
			// throws exception if no result
			SoaTransactionXml soaTrans = btsWrapper.getSoaTransactionByInternalReference(
					parameter.getTargetTransactionReference(), wildBlueHeader);
			extAcctRef = soaTrans.getExternalAccountReference();
			extSystemName = soaTrans.getExternalSystemName();
		}
		catch (WebServiceException e)
		{
			// should this only be for DATA_OBJECT_NOT_FOUND exceptions ?
			addValidationError(result, "soaTransactionNotFound");
			response.setValidationResult(result);
			return response; // can't go on from here w/o customer ref
		}

		// get business transaction data from external account
		com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAcctHierarchy;
		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy btsServiceAgrmtHierarchy;
		try
		{
			btsAcctHierarchy = btsWrapper.getAccountHierarchyByExternalReference(extAcctRef,
					extSystemName, wildBlueHeader);
			btsServiceAgrmtHierarchy = btsAcctHierarchy.getServiceAgreements().stream().findFirst()
					.orElse(null);
		}
		catch (WebServiceException e)
		{
			addValidationError(result, "accountNotFound");
			response.setValidationResult(result);
			return response;
		}

		// get master catalog data
		// lambda expression-style doesn't compile for clover, code block needed
		List<String> catalogRefs = btsServiceAgrmtHierarchy.getServiceItems().stream()
				.map(com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem::getMasterCatalogKey)
				.collect(Collectors.toList());

		GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
				wildBlueHeader);

		if (catalogComponents.getComponents().isEmpty())
		{
			addValidationError(result, "catalogComponentsNotFound");
			response.setValidationResult(result);
			return response;
		}

		// filter internet component
		CatalogComponent internetComponent = catalogComponents.getComponents().stream()
				.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE.equals(c.getComponentType()))
				.findFirst().orElse(null);

		// get internet service item from bts
		String internetMCR = internetComponent.getCharges().get(0).getMasterCatalogReference();

		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = btsServiceAgrmtHierarchy
				.getServiceItems().stream() // for each serviceItem
				.filter(serviceItem -> internetMCR.equals(serviceItem.getMasterCatalogKey()))
				.findFirst().orElse(null);

		// check sdp for layer 3 service
		if (!sdpWrapper.pendingLayer3ServiceExists(internetSvcItem.getServiceItemReference()))
		{
			addValidationError(result, "pendingServiceNotFound");
			response.setValidationResult(result);
			return response;
		}

		// filter voip component
		CatalogComponent voipComponent = catalogComponents.getComponents().stream()
				.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
				.orElse(null);

		// skip if no voip
		if (voipComponent != null)
		{
			// get voip service item from bts
			String voipCatalogRef = voipComponent.getCharges().get(0).getMasterCatalogReference();

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = btsServiceAgrmtHierarchy
					.getServiceItems().stream()
					.filter(si -> voipCatalogRef.equals(si.getMasterCatalogKey())).findFirst()
					.orElse(null);

			// check sdp for layer 3 service
			if (!sdpWrapper.pendingLayer3ServiceExists(voipSvcItem.getServiceItemReference()))
			{
				addValidationError(result, "pendingVoIPServiceNotFound");
				response.setValidationResult(result);
				return response;
			}
		}

		// check for device
		if (!sdpWrapper
				.pendingFixedNTDExists(btsServiceAgrmtHierarchy.getServiceAgreementReference()))
		{
			addValidationError(result, "pendingDeviceNotFound");
			response.setValidationResult(result);
			return response;
		}

		// check for service location
		if (svcLocWrapper
				.getServiceLocations(btsServiceAgrmtHierarchy.getServiceAgreementReference(), null,
						wildBlueHeader)
				.isEmpty())
		{
			addValidationError(result, "serviceLocationNotFound");
			response.setValidationResult(result);
			return response;
		}

		// success
		return response;
	}

	public ValidateCancelTransitionServiceAgreementResponse validateCancelTransitionServiceAgreement(
			CancelTransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return null;
	}

	public ValidateCancelTransitionServiceEquipmentResponse validateCancelTransitionServiceEquipment(
			CancelTransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return null;
	}

	public ValidateDisconnectAccountResponse validateDisconnectAccount(DisconnectAccount parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		int activeCount = 0;
		ValidateDisconnectAccountResponse response = new ValidateDisconnectAccountResponse();
		try
		{

			GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
			ValidationResult result = new ValidationResult();
			com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy;

			String accountRef = parameter.getAccountReference();

			try
			{
				btsAccountHierarchy = btsWrapper.getAccountHierarchyByInternalReference(accountRef,
						ConfigurationConstants.COMMON_WILDBLUE_HEADER);
			}
			catch (WebServiceException e)
			{
				// should this only be for DATA_OBJECT_NOT_FOUND exceptions ?
				addValidationError(result, "serviceAgreementNotFound");
				response.setValidationResult(result);
				return response;
			}

			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
					.getServiceAgreements();

			for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
			{
				List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
						.map(com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem::getMasterCatalogKey)
						.collect(Collectors.toList());

				GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
						wildBlueHeader);

				Layer3Service layer3ServiceForInternet = fetchProcessor
						.getLayer3ServiceForInternet(serviceAgreementHierarchy, catalogComponents);

				if (layer3ServiceForInternet.getState().equals(SdpConstants.ACTIVE))
				{
					activeCount++;
					CatalogComponent voipComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
							.orElse(null);

					if (voipComponent != null)
					{
						String voipMcr = voipComponent.getCharges().get(0)
								.getMasterCatalogReference();

						com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = serviceAgreementHierarchy
								.getServiceItems().stream() // for each
								// serviceItem
								.filter(serviceItem -> voipMcr
										.equals(serviceItem.getMasterCatalogKey()))
								.findFirst().orElse(null);
						Layer3Service layer3ServiceVoip = sdpWrapper
								.getLayer3Service(voipSvcItem.getServiceItemReference());
						if (!layer3ServiceVoip.getState().equals(SdpConstants.ACTIVE))
						{
							addValidationError(result, "VoipNotFound");
							response.setValidationResult(result);
							return response;
						}

					}

					FixedNTD fixedNTD = sdpWrapper
							.getFixedNTD(serviceAgreementHierarchy.getServiceAgreementReference());

					if (fixedNTD == null)
					{
						addValidationError(result, "FixedNTDNotFound");
						response.setValidationResult(result);
						return response;
					}

					CatalogComponent ispServiceComp = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
							.findFirst().orElse(null);
					if (ispServiceComp != null)
					{
						IspAccount ispAccount = ispWrapper.getIspAccount(new BigDecimal(
								serviceAgreementHierarchy.getServiceAgreementReference()));

						if (!ispAccount.getStatusDescription().equals(SdpConstants.ACTIVE))
						{
							addValidationError(result, "ActiveIspAccountNotFound");
							response.setValidationResult(result);
							return response;
						}
					}

					ServiceLocations serviceLocations = svcLocWrapper.getServiceLocations(
							serviceAgreementHierarchy.getServiceAgreementReference(), null,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

					ServiceLocation serviceLocationEndDateGreter = serviceLocations.stream()
							.filter(s -> OffsetDateTime.now().compareTo(s.getEndDate()) == -1)
							.findFirst().orElse(null);
					if (serviceLocationEndDateGreter == null)
					{
						addValidationError(result, "ServiceLocationNotFound");
						response.setValidationResult(result);
						return response;
					}

				}

			}
			if (activeCount == 0)
			{
				addValidationError(result, "InternetAccessLayer3ServiceNotActive");
				response.setValidationResult(result);
				return response;
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return response;
	}

	// FCSDP- Implemented validateDisconnectServiceAgreement
	public ValidateDisconnectServiceAgreementResponse validateDisconnectServiceAgreement(
			DisconnectServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		ValidateDisconnectServiceAgreementResponse response = new ValidateDisconnectServiceAgreementResponse();
		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		ValidationResult result = new ValidationResult();
		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy btsServiceAgreementHier;
		// by this step we are going to get BTS
		try
		{
			btsServiceAgreementHier = btsWrapper
					.getServiceAgreementHierarchyFromInternalServiceAgreementReference(
							serviceAgreementReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
		}
		catch (WebServiceException e)
		{
			addValidationError(result, "serviceAgreementNotFound");
			response.setValidationResult(result);
			return response;
		}

		List<String> catalogRefs = btsServiceAgreementHier.getServiceItems().stream()
				.map(com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem::getMasterCatalogKey)
				.collect(Collectors.toList());

		GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
				wildBlueHeader);

		// here we are getting Layer3ServiceForInternet
		Layer3Service layer3ServiceForInternet = fetchProcessor
				.getLayer3ServiceForInternet(btsServiceAgreementHier, catalogComponents);

		if (!layer3ServiceForInternet.getState().equals(SdpConstants.ACTIVE))
		{
			addValidationError(result, "InternetAccessLayer3ServiceNotActive");
			response.setValidationResult(result);
			return response;
		}

		CatalogComponent voipComponent = catalogComponents.getComponents().stream()
				.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
				.orElse(null);
		// here we are checking whether voip Component present or not

		if (voipComponent != null)
		{
			String voipMcr = voipComponent.getCharges().get(0).getMasterCatalogReference();

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = btsServiceAgreementHier
					.getServiceItems().stream() // for each
					// serviceItem
					.filter(serviceItem -> voipMcr.equals(serviceItem.getMasterCatalogKey()))
					.findFirst().orElse(null);
			Layer3Service layer3ServiceVoip = sdpWrapper
					.getLayer3Service(voipSvcItem.getServiceItemReference());
			if (layer3ServiceVoip.getState().equals(SdpConstants.ACTIVE))
			{
				addValidationError(result, "ActiveVoipLayer3ServiceNotFound");
				response.setValidationResult(result);
				return response;
			}

		}

		FixedNTD fixedNTD = sdpWrapper.getFixedNTD(serviceAgreementReference);

		if (fixedNTD.getState().equals(SdpConstants.ACTIVE))
		{
			addValidationError(result, "FixedNTDNotFound");
			response.setValidationResult(result);
			return response;
		}

		IspAccount ispAccount = ispWrapper.getIspAccount(new BigDecimal(serviceAgreementReference));

		if (ispAccount != null)
		{
			if (!ispAccount.getStatusDescription().equals(SdpConstants.ACTIVE))
			{
				addValidationError(result, "ActiveIspAccountNotFound");
				response.setValidationResult(result);
				return response;
			}
		}

		ServiceLocations serviceLocations = svcLocWrapper.getServiceLocations(
				serviceAgreementReference, null, ConfigurationConstants.COMMON_WILDBLUE_HEADER);

		ServiceLocation serviceLocationEndDateGreter = serviceLocations.stream()
				.filter(s -> OffsetDateTime.now().compareTo(s.getEndDate()) == -1).findFirst()
				.orElse(null);
		if (serviceLocationEndDateGreter == null)
		{
			addValidationError(result, "ServiceLocationNotFound");
			response.setValidationResult(result);
			return response;
		}

		return response;
	}

	public ValidateDisconnectServiceItemResponse validateDisconnectServiceItem(
			DisconnectServiceItem parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateDisconnectServiceItemResponse response = new ValidateDisconnectServiceItemResponse();
		ValidationResult result = new ValidationResult();
		String serviceItemRef = parameter.getServiceItemReference();
		com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustomerHierarchy;

		btsCustomerHierarchy = btsWrapper
				.getCustomerHierarchyByInternalServiceItemReference(serviceItemRef, wildBlueHeader);
		com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy accountHierarchy = btsCustomerHierarchy
				.getAccounts().get(0);

		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy = accountHierarchy
				.getServiceAgreements().get(0);

		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem serviceItem = serviceAgreementHierarchy
				.getServiceItems().stream()
				.filter(service -> parameter.getServiceItemReference()
						.compareTo(service.getServiceItemReference()) == 0)
				.findFirst().orElse(null);

		String mcKey = serviceItem.getMasterCatalogKey();
		GetComponentsResponse getComponentsResponse = catalogWrapper.getComponent(mcKey,
				wildBlueHeader);

		CatalogComponent voipComponent = getComponentsResponse.getComponents().stream()
				.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
				.orElse(null);

		if (voipComponent != null)
		{
			String voipMcr = voipComponent.getCharges().get(0).getMasterCatalogReference();

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = serviceAgreementHierarchy
					.getServiceItems().stream() // for each
					// serviceItem
					.filter(s -> voipMcr.equals(s.getMasterCatalogKey())).findFirst().orElse(null);

			Layer3Service layer3ServiceVoip = sdpWrapper
					.getLayer3Service(voipSvcItem.getServiceItemReference());

			if (!layer3ServiceVoip.getState().equals(SdpConstants.ACTIVE))

			{
				addValidationError(result, "ActiveVoipLayer3ServiceNotFound");
				response.setValidationResult(result);
				return response;
			}
		}
		return response;
	}

	public ValidateResumeAllServiceAgreementsResponse validateResumeAllServiceAgreements(
			ResumeAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		int suspendedInternetAccessLayer3Service = 0;
		ValidateResumeAllServiceAgreementsResponse response = new ValidateResumeAllServiceAgreementsResponse();

		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		ValidationResult result = new ValidationResult();
		com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy;

		String accountRef = parameter.getAccountReference();
		IspAccount ispAccount = null;

		try
		{
			btsAccountHierarchy = btsWrapper.getAccountHierarchyByInternalReference(accountRef,
					ConfigurationConstants.COMMON_WILDBLUE_HEADER);
		}
		catch (WebServiceException e)
		{
			// should this only be for DATA_OBJECT_NOT_FOUND exceptions ?
			addValidationError(result, "serviceAgreementNotFound");
			response.setValidationResult(result);
			return response;
		}
		List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreements = btsAccountHierarchy
				.getServiceAgreements();

		for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreements)
		{
			getServiceProvisioningStatus.setServiceAgreementReference(
					serviceAgreementHierarchy.getServiceAgreementReference());
			List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
					.map(si -> {
						return si.getMasterCatalogKey();
					}).collect(Collectors.toList());

			GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
					wildBlueHeader);

			GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = fetchProcessor
					.getServiceProvisioningStatus(getServiceProvisioningStatus,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			// check for Layer3ServiceForInternet
			if (getServiceProvisioningStatusResponse.getServiceProvisioningStatus()
					.equals(SdpConstants.SUSPENDED))
			{
				suspendedInternetAccessLayer3Service++;
			}
			if (getServiceProvisioningStatusResponse.getServiceProvisioningStatus()
					.equals(SdpConstants.SUSPENDED))
			{
				CatalogComponent ispComponent = catalogComponents.getComponents().stream()
						.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
						.findFirst().orElse(null);
				if (ispComponent != null)
				{
					String ispMCR = ispComponent.getCharges().get(0).getMasterCatalogReference();

					com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem ispSvcItem = serviceAgreementHierarchy
							.getServiceItems().stream() // for each serviceItem
							.filter(serviceItem -> ispMCR.equals(serviceItem.getMasterCatalogKey()))
							.findFirst().orElse(null);
					if (ispSvcItem != null)
					{
						ispAccount = ispWrapper.getIspAccount(new BigDecimal(
								serviceAgreementHierarchy.getServiceAgreementReference()));

					}
					if (ispAccount == null)
					{
						addValidationError(result, "IspServiceNotFound");
						response.setValidationResult(result);
						return response;
					}

				}
			}

			if (suspendedInternetAccessLayer3Service < 1)
			{
				addValidationError(result, "SuspendedInternetAccessLayer3ServiceNotFound");
				response.setValidationResult(result);
				return response;

			}
		}
		return response;
	}

	public ValidateSuspendAllServiceAgreementsResponse validateSuspendAllServiceAgreements(
			SuspendAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateSuspendAllServiceAgreementsResponse response = new ValidateSuspendAllServiceAgreementsResponse();
		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		ValidationResult result = new ValidationResult();
		int activeInternetAccessLayer3Service = 0;
		IspAccount ispAccount = null;

		com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy;

		String accountRef = parameter.getAccountReference();

		try
		{
			btsAccountHierarchy = btsWrapper.getAccountHierarchyByInternalReference(accountRef,
					ConfigurationConstants.COMMON_WILDBLUE_HEADER);
		}
		catch (WebServiceException e)
		{
			// should this only be for DATA_OBJECT_NOT_FOUND exceptions ?
			addValidationError(result, "serviceAgreementNotFound");
			response.setValidationResult(result);
			return response;
		}

		List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
				.getServiceAgreements();
		for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
		{
			List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
					.map(si -> {
						return si.getMasterCatalogKey();
					}).collect(Collectors.toList());

			GetComponentsResponse getComponentsResponse = catalogWrapper.getComponents(catalogRefs,
					wildBlueHeader);

			// getting Layer3ServiceForInternet
			Layer3Service layer3ServiceForInternet = fetchProcessor
					.getLayer3ServiceForInternet(serviceAgreementHierarchy, getComponentsResponse);

			Layer3ServiceState state = layer3ServiceForInternet.getState();

			// check for Layer3ServiceForInternet
			if (state.toString().equals(SdpConstants.ACTIVE))
			{
				activeInternetAccessLayer3Service++;
			}

			List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem> serviceItems = serviceAgreementHierarchy
					.getServiceItems();

			String serviceAgreementRef = serviceAgreementHierarchy.getServiceAgreementReference();

			GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = null;
			getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementRef);

			// getting ProvisioningStatus
			getServiceProvisioningStatusResponse = fetchProcessor
					.getServiceProvisioningStatus(getServiceProvisioningStatus, wildBlueHeader);

			if (getServiceProvisioningStatusResponse != null)
			{
				if (getServiceProvisioningStatus.equals(SdpConstants.ACTIVE))
				{
					CatalogComponent ispComponent = getComponentsResponse.getComponents().stream()
							.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
							.findFirst().orElse(null);
					String ispMcr = ispComponent.getCharges().get(0).getMasterCatalogReference();
					com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem ispSvcItem = serviceAgreementHierarchy
							.getServiceItems().stream()
							.filter(serviceItem -> ispMcr.equals(serviceItem.getMasterCatalogKey()))
							.findFirst().orElse(null);
					if (ispSvcItem != null)
					{
						ispAccount = ispWrapper.getIspAccount(new BigDecimal(serviceAgreementRef));
					}

					if (ispAccount != null
							&& !ispAccount.getStatusCode().equals(SdpConstants.SUSPENDED))
					{
						addValidationError(result, "ISPServiceNotFound");
						response.setValidationResult(result);
						return response;
					}
				}

			}

			if (activeInternetAccessLayer3Service < 1)
			{
				addValidationError(result, "InternetAccessLayer3ServiceNotActive");
				response.setValidationResult(result);
				return response;
			}

		}

		return response;
	}

	public ValidateTransitionServiceAgreementResponse validateTransitionServiceAgreement(
			TransitionServiceAgreement parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceAgreementResponse response = new ValidateTransitionServiceAgreementResponse();
		ValidationResult result = new ValidationResult();

		CustomerHierarchy customerHierarchy = parameter.getCustomerHierarchy();

		AccountHierarchy accountHierarchy = customerHierarchy.getAccountHierarchy().get(0);

		ServiceAgreementHierarchy serviceAgreementHierarchy = accountHierarchy
				.getServiceAgreementHierarchy().get(0);
		ServiceAgreement serviceAgreement = serviceAgreementHierarchy.getServiceAgreement();
		String serviceAgreementReference = serviceAgreement.getServiceAgreementReference();
		String accountRef = serviceAgreement.getAccountReference();

		// internet-access service
		ServiceItem internetSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
				.filter(si -> "INTERNET_ACCESS_SERVICE".equals(si.getType())).findFirst()
				.orElse(null);

		if (sdpWrapper.layer3ServiceExists(internetSvcItem.getServiceItemReference()) == false)
		{
			addValidationError(result, "Layer3ServiceNotFound");
			response.setValidationResult(result);
			return response;
		}

		FixedNTD fixedNTD = sdpWrapper.getFixedNTD(serviceAgreementReference);

		if (fixedNTD == null)
		{
			addValidationError(result, "FixedNTDNotFound");
			response.setValidationResult(result);
			return response;
		}

		ServiceItem voIpSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
				.filter(si -> "VOIP".equals(si.getType())).findFirst().orElse(null);

		if (voIpSvcItem != null)
		{
			if (sdpWrapper.layer3ServiceExists(voIpSvcItem.getServiceItemReference()) == false)
			{
				addValidationError(result, "VoipLayer3ServiceNotFound");
				response.setValidationResult(result);
				return response;
			}

		}

		String deviceProtocol = getTransitionFromDeviceProtocol(accountRef, wildBlueHeader);

		if (deviceProtocol.equals("SB"))
		{
			Contacts customerContacts = contactsWrapper.getCustomerContacts(accountRef, "", "");

			if (customerContacts != null)
			{
				addValidationError(result, "CustomerContactAlreadyExists");
				response.setValidationResult(result);
				return response;
			}
			else
			{
				Contacts accountContacts = contactsWrapper.getAccountContacts(accountRef, "", "");

				if (accountContacts != null)
				{
					addValidationError(result, "AccountContactAlreadyExists");
					response.setValidationResult(result);
					return response;
				}
			}
		}

		Contacts serviceAgreementContacts = contactsWrapper
				.getServiceAgreementContacts(serviceAgreementReference, " ", "");

		if (serviceAgreementContacts != null && serviceAgreementContacts.size() > 0)
		{
			addValidationError(result, "ServiceAgreementContactAlreadyExists");
			response.setValidationResult(result);
			return response;
		}

		ServiceLocations serviceLocations = svcLocWrapper.getServiceLocations(
				serviceAgreementReference,
				serviceAgreement.getBeamInfo().getBeamTechnicalInfo().getCustomerCode(),
				wildBlueHeader);

		if (serviceLocations != null)
		{
			addValidationError(result, "CustomerCodeAlreadyExists");
			response.setValidationResult(result);
			return response;

		}

		return response;
	}

	public ValidateTransitionServiceEquipmentResponse validateTransitionServiceEquipment(
			TransitionServiceEquipment parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceEquipmentResponse response = new ValidateTransitionServiceEquipmentResponse();
		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		ValidationResult result = new ValidationResult();

		String svcAgrmtRef = parameter.getServiceAgreementReference();
		getServiceProvisioningStatus.setServiceAgreementReference(svcAgrmtRef);

		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy btsServiceAgreementHier;

		try
		{
			btsServiceAgreementHier = btsWrapper
					.getServiceAgreementHierarchyFromInternalServiceAgreementReference(svcAgrmtRef,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);
		}
		catch (WebServiceException e)
		{
			// should this only be for DATA_OBJECT_NOT_FOUND exceptions ?
			addValidationError(result, "serviceAgreementNotFound");
			response.setValidationResult(result);
			return response; // can't go on from here w/o service agreement
		}

		List<String> catalogRefs = btsServiceAgreementHier.getServiceItems().stream()
				.map(com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem::getMasterCatalogKey)
				.collect(Collectors.toList());

		GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
				wildBlueHeader);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = fetchProcessor
				.getServiceProvisioningStatus(getServiceProvisioningStatus,
						ConfigurationConstants.COMMON_WILDBLUE_HEADER);

		if (SdpConstants.SUSPENDED
				.equals(getServiceProvisioningStatusResponse.getServiceProvisioningStatus()))
		{
			addValidationError(result, "serviceSuspended");
			response.setValidationResult(result);
			return response;
		}

		Boolean layer3ServiceExists = sdpWrapper
				.layer3ServiceExists(parameter.getNewServiceItem().getServiceItemReference());
		if (layer3ServiceExists.equals("true"))
		{
			addValidationError(result, "InternetLayer3ServiceFound");
			response.setValidationResult(result);
			return response;
		}

		FixedNTD fixedNTD = sdpWrapper.getFixedNTD(svcAgrmtRef);

		if (fixedNTD == null)
		{
			addValidationError(result, "FixedNTDNotFound");
			response.setValidationResult(result);
			return response;
		}

		CatalogComponent voipComponent = catalogComponents.getComponents().stream()
				.filter(c -> SdpConstants.VOIP.equals(c.getComponentType())).findFirst()
				.orElse(null);

		if (voipComponent != null)
		{
			String voipMcr = voipComponent.getCharges().get(0).getMasterCatalogReference();

			com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem voipSvcItem = btsServiceAgreementHier
					.getServiceItems().stream() // for each
					// serviceItem
					.filter(serviceItem -> voipMcr.equals(serviceItem.getMasterCatalogKey()))
					.findFirst().orElse(null);
			Layer3Service layer3ServiceVoip = sdpWrapper
					.getLayer3Service(voipSvcItem.getServiceItemReference());
			if (layer3ServiceVoip == null)
			{
				addValidationError(result, "VoipNotFound");
				response.setValidationResult(result);
				return response;
			}

		}

		return response;
	}

	public ValidateTransitionServiceEquipmentCompleteResponse validateTransitionServiceEquipmentComplete(
			TransitionServiceEquipmentComplete parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		return null;
	}

	public ValidateTransitionServiceItemResponse validateTransitionServiceItem(
			TransitionServiceItem parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		ValidateTransitionServiceItemResponse response = new ValidateTransitionServiceItemResponse();
		ValidationResult result = new ValidationResult();

		String svcAgrmtRef = parameter.getServiceAgreementReference();

		com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy btsCustHierarchy;
		try
		{
			btsCustHierarchy = btsWrapper.getCustomerHierarchyByInternalServiceAgreementReference(
					svcAgrmtRef, wildBlueHeader);
		}
		catch (WebServiceException e)
		{
			// should this only be for DATA_OBJECT_NOT_FOUND exceptions ?
			addValidationError(result, "serviceAgreementNotFound");
			response.setValidationResult(result);
			return response; // can't go on from here w/o service agreement
		}

		// find the relevant service agreement ref from the customer hierarchy
		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy btsServiceAgrmtHierarchy = btsCustHierarchy
				.getAccounts().stream()
				.flatMap(ah -> ah.getServiceAgreements().stream()
						.filter(sah -> svcAgrmtRef.equals(sah.getServiceAgreementReference())))
				.findFirst().orElse(null);

		if (btsServiceAgrmtHierarchy == null)
		{
			addValidationError(result, "serviceAgreementNotFound");
			response.setValidationResult(result);
			return response;
		}

		// get master catalog data
		List<String> catalogRefs = btsServiceAgrmtHierarchy.getServiceItems().stream()
				.map(com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem::getMasterCatalogKey)
				.collect(Collectors.toList());

		GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
				wildBlueHeader);

		CatalogComponent internetComponent = catalogComponents.getComponents().stream()
				.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE.equals(c.getComponentType()))
				.findFirst().orElse(null);

		String internetMCR = internetComponent.getCharges().get(0).getMasterCatalogReference();

		com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem internetSvcItem = btsServiceAgrmtHierarchy
				.getServiceItems().stream() // for each serviceItem
				.filter(serviceItem -> internetMCR.equals(serviceItem.getMasterCatalogKey()))
				.findFirst().orElse(null);

		// get service status from SDP
		String layer3ServiceStatus = sdpWrapper.getInternetAccessLayer3ServiceStatus(
				internetComponent, internetSvcItem.getServiceItemReference());

		if (SdpConstants.SUSPENDED.equals(layer3ServiceStatus))
		{
			addValidationError(result, "serviceSuspended");
			response.setValidationResult(result);
			return response;
		}

		if (!result.getValidationError().isEmpty())
			response.setValidationResult(result);

		return response;
	}

	public ValidateUpdateContactsResponse validateUpdateContacts(UpdateContacts parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		String serviceAgreementReference = parameter.getServiceAgreementReference();
		ValidateUpdateContactsResponse response = new ValidateUpdateContactsResponse();
		ValidationResult result = new ValidationResult();
		// validateUpdateContacts for the services
		try
		{
			String accountReference = btsWrapper
					.getAccountReferenceFromInternalServiceAgreementReference(
							parameter.getServiceAgreementReference(), wildBlueHeader);
			String serviceAgreementRef = parameter.getServiceAgreementReference();
			ContactsWrapper contactsWrapper = new ContactsWrapper();

			List<ContactAggregate> allContacts = new ArrayList<ContactAggregate>();

			List<ContactAggregate> accountContacts = contactsWrapper.getAccountContactAggregates(
					accountReference, wildBlueHeader.getInvokedBy().getUsername(),
					wildBlueHeader.getInvokedBy().getApplication());
			List<ContactAggregate> customerContacts = contactsWrapper.getCustomerContactAggregates(
					accountReference, wildBlueHeader.getInvokedBy().getUsername(),
					wildBlueHeader.getInvokedBy().getApplication());
			List<ContactAggregate> serviceContacts = null;

			serviceContacts = contactsWrapper.getServiceAgreementContactAggregates(
					serviceAgreementRef, wildBlueHeader.getInvokedBy().getUsername(),
					wildBlueHeader.getInvokedBy().getApplication());

			allContacts.addAll(accountContacts);
			allContacts.addAll(customerContacts);
			allContacts.addAll(serviceContacts);

			CorrectedContact cc = parameter.getCorrectedContact();

			if (allContacts == null)
			{

				addValidationError(result, "ServiceContactNotFound");
				response.setValidationResult(result);
				return response;
			}
			else if (cc.getServiceAddress() != null)
			{
				ServiceLocationAggregates serviceLocationAggregates = svcLocWrapper
						.getServiceLocationAggregates(serviceAgreementRef, wildBlueHeader);

				if (serviceLocationAggregates.isEmpty())
				{
					addValidationError(result, "ServiceLocationNotFound");
					response.setValidationResult(result);
					return response;
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return response;
	}

	public ValidateUpdateEquipmentResponse validateUpdateEquipment(UpdateEquipment parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		return null;
	}

	private void addValidationError(ValidationResult validationResult, String msgKey)
	{
		ValidationError ve = new ValidationError();

		ve.setErrorCode("VALIDATION_ERROR");
		ve.setMessage(messageBundle.getString(msgKey));

		validationResult.getValidationError().add(ve);
	}

	public String getTransitionFromDeviceProtocol(String accountRef, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		String deviceProtocol = "";

		List<com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy> serviceAgreementHierarchyList = btsWrapper
				.getAccountHierarchyByInternalReference(accountRef, wildBlueHeader)
				.getServiceAgreements();

		endLooping: // break out of all loops when deviceProtocol found for the
		// active device
		for (com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchyList)
		{
			List<ServiceAgreementDevice> deviceList = serviceAgreementHierarchy
					.getServiceAgreementDevice();

			for (ServiceAgreementDevice device : deviceList)
			{
				for (DeviceTypeAttribute attribute : device.getDeviceType()
						.getDeviceTypeAttribute())
				{
					if ("DEVICE_CATEGORY".equals(attribute.getAttributeName())
							&& "MODEM".equals(attribute.getAttributeValue())
							&& "ACTIVE".equals(device.getDeviceStatus()))
					{
						deviceProtocol = serviceAgreementHierarchy.getDeviceProtocol();
						break endLooping;
					}
				}
			}
		}

		LOGGER.debug("***** transition from deviceProtocol = " + deviceProtocol);

		return deviceProtocol;
	}
}
