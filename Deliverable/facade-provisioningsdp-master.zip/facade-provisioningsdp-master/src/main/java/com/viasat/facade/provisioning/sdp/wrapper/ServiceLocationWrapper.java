package com.viasat.facade.provisioning.sdp.wrapper;

import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.fault.utils.FaultUtil;
import com.viasat.internalservice.servicelocation.api.model.*;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.wildblue.common.commondata.Beam;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.common.location.Address;
import com.viasat.wildblue.common.location.Location;
import com.viasat.wildblue.facade.provisioning.data.CorrectedContact;
import com.viasat.wildblue.facade.provisioning.data.ServiceAgreementHierarchy;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;

public class ServiceLocationWrapper
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceLocationWrapper.class);

	private ServiceLocationServiceClient serviceLocationClient;

	public void setServiceLocationClient(ServiceLocationServiceClient serviceLocationClient)
	{
		this.serviceLocationClient = serviceLocationClient;
	}

	public void updateServiceLocationAggregates(String serviceAgreementRef, CorrectedContact cc,
			WildBlueHeader wbHeader) throws Exception
	{
		// Convert the serviceAgreementRef and accountRef from string to
		// BigDecimal for database access
		BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);
		BigDecimal serviceLocationId;
		List<ServiceLocationAggregate> serviceLocationAggregates;

		try
		{
			// Get method to get ServiceLocationaggregates
			serviceLocationAggregates = serviceLocationClient.getServiceLocationAggregates(
					serviceAgreementId, null, null, null, null, null, null, null, null, null, null,
					null, null, null, null, null, null);
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("getServiceLocationAggregates",
					e);
		}

		try
		{

			if (CollectionUtils.isNotEmpty(serviceLocationAggregates))
			{
				for (ServiceLocationAggregate serviceLocationagg : serviceLocationAggregates)
				{
					serviceLocationId = serviceLocationagg.getServiceLocationId();
					if (cc.getServiceAddress() != null)
					{
						if (cc.getServiceAddress().getAddressLine() != null)
						{
							List<String> addressLine = cc.getServiceAddress().getAddressLine();
							if (!addressLine.isEmpty())
								serviceLocationagg.setAddressLine1(addressLine.get(0));
							if (addressLine.size() == 2)
								serviceLocationagg.setAddressLine2(addressLine.get(1));
						}

						if (cc.getServiceAddress().getMunicipality() != null)
							serviceLocationagg
									.setMunicipality(cc.getServiceAddress().getMunicipality());

						if (cc.getServiceAddress().getRegion() != null)
							serviceLocationagg.setRegion(cc.getServiceAddress().getRegion());

						if (cc.getServiceAddress().getPostalCode() != null)
							serviceLocationagg
									.setPostalCode(cc.getServiceAddress().getPostalCode());

						if (cc.getServiceAddress().getCountryCode() != null)
							serviceLocationagg
									.setCountryCode(cc.getServiceAddress().getCountryCode());

						Double azimuth = null;
						Double elevation = null;
						Double skew = null;
						Double boomArmAngle = null;
						if (cc.getServiceAddress().getAntennaLookAngles() != null)
						{
							azimuth = cc.getServiceAddress().getAntennaLookAngles().getAzimuth();
							elevation = cc.getServiceAddress().getAntennaLookAngles()
									.getElevation();
							skew = cc.getServiceAddress().getAntennaLookAngles().getSkew();
							boomArmAngle = cc.getServiceAddress().getAntennaLookAngles()
									.getBoomArmAngle();

							List<InstallationAttribute> installationAttribute = serviceLocationagg
									.getInstallationAttributes();
							if (CollectionUtils.isNotEmpty(installationAttribute))
							{

								installationAttribute.get(0).setAzimuth(azimuth.toString());
								installationAttribute.get(0).setElevation(elevation.toString());
								installationAttribute.get(0).setSkew(skew.toString());
								installationAttribute.get(0)
										.setBoomArmAngle(boomArmAngle.toString());
								serviceLocationagg.setInstallationAttributes(
										(InstallationAttributes) installationAttribute);
							}
						}
					}
					serviceLocationClient.updateServiceLocationAggregate(serviceLocationId,
							serviceLocationagg, null, null);
				}
			}

		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("updateServiceLocationAggregate",
					e);
		}

	}

	public void createServiceLocation(ServiceAgreementHierarchy serviceAgreementHierarchy,
			WildBlueHeader wbHeader) throws WebServiceException
	{
		try
		{
			ServiceLocationAggregate serviceLocationAggregate = new ServiceLocationAggregate();

			Location serviceLocation = serviceAgreementHierarchy.getServiceAgreement()
					.getServiceContact().getContactInfo().getLocation();

			Address serviceAddress = serviceLocation.getAddress();

			// Service Location
			serviceLocationAggregate.setCountryCode(serviceAddress.getCountryCode());
			serviceLocationAggregate.setStartDate(OffsetDateTime.now());
			serviceLocationAggregate.setAddressLine1(serviceAddress.getAddressLine().get(0));
			serviceLocationAggregate.setMunicipality(serviceAddress.getMunicipality());
			serviceLocationAggregate.setPostalCode(serviceAddress.getPostalCode());
			serviceLocationAggregate.setRegion(serviceAddress.getRegion());
			serviceLocationAggregate.setActualLatitude(
					String.valueOf(serviceLocation.getGeoPosition().getLatitude()));
			serviceLocationAggregate.setActualLongitude(
					String.valueOf(serviceLocation.getGeoPosition().getLongitude()));
			serviceLocationAggregate.setRequestedLatitude(
					String.valueOf(serviceLocation.getGeoPosition().getLatitude()));
			serviceLocationAggregate.setRequestedLongitude(
					String.valueOf(serviceLocation.getGeoPosition().getLongitude()));
			serviceLocationAggregate.setServiceAgreementId(new BigDecimal(serviceAgreementHierarchy
					.getServiceAgreement().getServiceAgreementReference()));

			// InstallationAttributes

			serviceLocationAggregate.setInstallationAttributes(
					createInstallationAttributes(serviceAgreementHierarchy));

			// LegacyAttributes
			serviceLocationAggregate
					.setLegacyAttributes(createLegacyAttributes(serviceAgreementHierarchy));

			serviceLocationClient.createServiceLocationAggregate(serviceLocationAggregate,
					getUserFromHeader(wbHeader), getAppFromHeader(wbHeader));
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("createServiceLocationAggregate",
					e);
		}
	}

	private LegacyAttributes createLegacyAttributes(
			ServiceAgreementHierarchy serviceAgreementHierarchy)
	{

		LegacyAttributes legacyAttributes = new LegacyAttributes();
		LegacyAttribute legacyAttribute = new LegacyAttribute();

		Beam beamInfo = serviceAgreementHierarchy.getServiceAgreement().getBeamInfo();

		// legacyAttribute.setServiceLocationId(serviceLocationId);
		legacyAttribute.setGatewayNumber(beamInfo.getBeamTechnicalInfo().getGatewayId());
		legacyAttribute.setGatewayName(beamInfo.getBeamTechnicalInfo().getGatewayName());

		legacyAttribute.setIspUsername(
				serviceAgreementHierarchy.getServiceAgreement().getInstallationLogin());
		legacyAttribute.setIspPassword(
				serviceAgreementHierarchy.getServiceAgreement().getInstallationPassword());
		// legacyAttribute.setModemSerialNumber("12345");
		// legacyAttribute.setTriaSerialNumber("67090");

		legacyAttribute.setStartDate(OffsetDateTime.now());
		legacyAttributes.add(legacyAttribute);

		return legacyAttributes;
	}

	private InstallationAttributes createInstallationAttributes(
			ServiceAgreementHierarchy serviceAgreementHierarchy)
	{

		Beam beamInfo = serviceAgreementHierarchy.getServiceAgreement().getBeamInfo();

		InstallationAttributes installationAttributes = new InstallationAttributes();

		InstallationAttribute ia = new InstallationAttribute();
		// ia.setInstallerId("123456");

		// beamTechInfo
		ia.setAntennaPointingAid(beamInfo.getBeamTechnicalInfo().getAntennaPointingAid());
		// ia.setBeamId(new
		// BigDecimal(beamInfo.getBeamTechnicalInfo().getBeamNumber()));
		ia.setBeamNumber(new BigDecimal(beamInfo.getBeamTechnicalInfo().getBeamNumber()));
		// ia.setSatelliteId(BigDecimal.ONE);
		ia.setSatelliteName(beamInfo.getBeamTechnicalInfo().getSatelliteName());
		ia.setPolarization(beamInfo.getBeamTechnicalInfo().getPolarization());

		if (beamInfo.getBeamTechnicalInfo().getCustomerCode() != null
				&& beamInfo.getBeamTechnicalInfo().getCustomerCode().length() > 0)
			ia.setCustomerCode(beamInfo.getBeamTechnicalInfo().getCustomerCode());
		else
			ia.setCustomerCode(
					serviceAgreementHierarchy.getServiceAgreement().getServiceAgreementReference());

		// antennaLookAngles
		ia.setAzimuth(String
				.valueOf(beamInfo.getBeamTechnicalInfo().getAntennaLookAngles().getAzimuth()));
		ia.setElevation(String
				.valueOf(beamInfo.getBeamTechnicalInfo().getAntennaLookAngles().getElevation()));
		ia.setSkew(
				String.valueOf(beamInfo.getBeamTechnicalInfo().getAntennaLookAngles().getSkew()));
		ia.setBoomArmAngle(String
				.valueOf(beamInfo.getBeamTechnicalInfo().getAntennaLookAngles().getBoomArmAngle()));
		ia.setStartDate(OffsetDateTime.now());
		ia.setEndDate(OffsetDateTime.of(2099, 1, 1, 0, 0, 0, 0, ZoneOffset.UTC));

		installationAttributes.add(ia);

		return installationAttributes;
	}

	public void deleteServiceLocationAggregates(String serviceAgreementRef, WildBlueHeader wbHeader)
			throws WebServiceException
	{
		try
		{
			ServiceLocationAggregates serviceLocationAggregates = getServiceLocationAggregates(
					serviceAgreementRef, wbHeader);

			for (ServiceLocationAggregate serviceLocationAggregate : serviceLocationAggregates)
			{
				serviceLocationClient.deleteServiceLocationAggregate(
						serviceLocationAggregate.getServiceLocationId(),
						getUserFromHeader(wbHeader), getAppFromHeader(wbHeader));
			}
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("deleteServiceLocationAggregate",
					e);
		}
	}

	public ServiceLocationAggregates getServiceLocationAggregates(String serviceAgreementRef,
			WildBlueHeader wbHeader) throws WebServiceException
	{
		try
		{
			BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);
			OffsetDateTime endDate = OffsetDateTime.parse("2099-12-31T00:00:00Z");
			return serviceLocationClient.getServiceLocationAggregates(serviceAgreementId, null,
					null, null, null, null, null, null, null, null, null, null, endDate, null, null,
					getUserFromHeader(wbHeader), getAppFromHeader(wbHeader));
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("getServiceLocationAggregates",
					e);
		}
	}

	public ServiceLocations getServiceLocations(String serviceAgreementRef, String customerCode,
			WildBlueHeader wbHeader) throws WebServiceException
	{
		BigDecimal serviceAgreementId = null;

		if (serviceAgreementRef != null)
			serviceAgreementId = new BigDecimal(serviceAgreementRef);
		try
		{
			OffsetDateTime endDate = OffsetDateTime.parse("2099-12-31T00:00:00Z");
			return serviceLocationClient.getServiceLocations(serviceAgreementId, null, null, null,
					null, null, null, null, null, customerCode, null, endDate, null, null,
					getUserFromHeader(wbHeader), getAppFromHeader(wbHeader));
		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("getServiceLocations", e);
		}
	}

	private String getUserFromHeader(WildBlueHeader wbHeader)
	{
		if (wbHeader != null && wbHeader.getInvokedBy() != null)
			return wbHeader.getInvokedBy().getUsername();

		return null;
	}

	private String getAppFromHeader(WildBlueHeader wbHeader)
	{
		if (wbHeader != null && wbHeader.getInvokedBy() != null)
			return wbHeader.getInvokedBy().getApplication();

		return null;
	}

	private WebServiceException convertInternalServiceFaultToWebServiceException(String request,
			InternalServiceFault e)
	{
		String msg = "Failed to call IS-ServiceLocation: " + request;
		LOGGER.error(msg, e);
		return new WildBlueWebServiceException(msg,
				FaultUtil.internalServiceFaultToExceptionDetail(e));
	}

	// getProvisioningDetailsServiceLocation
	public List<ServiceLocationAggregate> getProvisioningDetailsServiceLocation(
			String serviceAgreementRef) throws WebServiceException
	{
		List<ServiceLocationAggregate> serviceLocationAggregates;

		try
		{
			BigDecimal serviceAgreementId = new BigDecimal(serviceAgreementRef);
			OffsetDateTime endDate = OffsetDateTime.parse("2099-12-31T00:00:00Z");
			serviceLocationAggregates = serviceLocationClient.getServiceLocationAggregates(
					serviceAgreementId, null, null, null, null, null, null, null, null, null, null,
					null, endDate, null, null, "", "");

		}
		catch (InternalServiceFault e)
		{
			throw convertInternalServiceFaultToWebServiceException("getServiceLocationAggregates",
					e);
		}

		return serviceLocationAggregates;

	}

	public void deleteServiceLocationAgggregate(BigDecimal serviceLocationId)
			throws InternalServiceFault
	{
		serviceLocationClient.deleteServiceLocation(serviceLocationId, "", "");
	}
}
