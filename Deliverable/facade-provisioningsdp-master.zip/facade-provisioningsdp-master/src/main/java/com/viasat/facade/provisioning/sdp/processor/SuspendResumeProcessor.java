package com.viasat.facade.provisioning.sdp.processor;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.catalog.data.CatalogComponent;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.isp.api.model.IspAccount;
import com.viasat.facade.isp.api.model.IspCommand;
import com.viasat.facade.isp.api.model.TransactionType;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.facade.provisioning.sdp.wrapper.BusinessTransactionWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.CatalogWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ISPWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.SDPWrapper;
import com.viasat.sdp.api.data.NewConfigureLayer3ServiceInput;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatus;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatusResponse;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateResumeAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateSuspendAllServiceAgreementsResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem;

public class SuspendResumeProcessor
{
	private static final Logger LOGGER = LoggerFactory.getLogger(SuspendResumeProcessor.class);

	public void setValidationProcessor(ValidationProcessor validationProcessor)
	{
		this.validationProcessor = validationProcessor;
	}

	private ValidationProcessor validationProcessor;

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.businessTransactionWrapper = businessTransactionWrapper;
	}

	private BusinessTransactionWrapper businessTransactionWrapper;

	public void setCatalogWrapper(CatalogWrapper catalogWrapper)
	{
		this.catalogWrapper = catalogWrapper;
	}

	private CatalogWrapper catalogWrapper;

	public void setFetchProcessor(FetchProcessor fetchProcessor)
	{
		this.fetchProcessor = fetchProcessor;
	}

	private FetchProcessor fetchProcessor;

	public void setSdpWrapper(SDPWrapper sdpWrapper)
	{
		this.sdpWrapper = sdpWrapper;
	}

	private SDPWrapper sdpWrapper;

	public void setIspWrapper(ISPWrapper ispWrapper)
	{
		this.ispWrapper = ispWrapper;
	}

	private ISPWrapper ispWrapper;

	public ResumeAllServiceAgreementsResponse resumeAllServiceAgreements(
			ResumeAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException

	{
		ResumeAllServiceAgreementsResponse resumeAllServiceAgreementsResponse = new ResumeAllServiceAgreementsResponse();

		String transactionType = BusinessTransactionWrapper.TRANSACTION_RESUME_ALL_SERVICE_AGREEMENTS;

		TransactionType transactionTypeIn = TransactionType.DELETE;

		String accountReference = parameter.getAccountReference();

		String businessTransactionReference = businessTransactionWrapper.addBusinessTransaction(
				transactionType, SdpConstants.FACADE_OWNER_NAME,
				parameter.getTransactionReference(), null, accountReference, null, wildBlueHeader);

		try
		{

			ValidateResumeAllServiceAgreementsResponse validationResult = validationProcessor
					.validateResumeAllServiceAgreements(parameter, wildBlueHeader);

			validationProcessor.checkValidationResult(validationResult.getValidationResult());

			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			AccountHierarchy accountHierarchy = businessTransactionWrapper
					.getAccountHierarchyByInternalReference(accountReference,
							ConfigurationConstants.COMMON_WILDBLUE_HEADER);

			List<ServiceAgreementHierarchy> serviceAgreements = accountHierarchy
					.getServiceAgreements();

			for (ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreements)
			{
				GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
				getServiceProvisioningStatus.setServiceAgreementReference(
						serviceAgreementHierarchy.getServiceAgreementReference());
				List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
						.map(si -> {
							return si.getMasterCatalogKey();
						}).collect(Collectors.toList());

				GetComponentsResponse catalogComponents = catalogWrapper.getComponents(catalogRefs,
						wildBlueHeader);

				GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = fetchProcessor
						.getServiceProvisioningStatus(getServiceProvisioningStatus,
								ConfigurationConstants.COMMON_WILDBLUE_HEADER);

				if (getServiceProvisioningStatusResponse.getServiceProvisioningStatus()
						.equals(SdpConstants.SUSPENDED))
				{

					CatalogComponent internetComponent = catalogComponents.getComponents().stream()
							.filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE
									.equals(c.getComponentType()))
							.findFirst().orElse(null);

					if (internetComponent != null)
					{

						String internetMCR = internetComponent.getCharges().get(0)
								.getMasterCatalogReference();

						ServiceItem internetSvcItem = serviceAgreementHierarchy.getServiceItems()
								.stream() // for each serviceItem
								.filter(serviceItem -> internetMCR
										.equals(serviceItem.getMasterCatalogKey()))
								.findFirst().orElse(null);

						NewConfigureLayer3ServiceInput newConfigureLayer3ServiceInput = new NewConfigureLayer3ServiceInput();
						newConfigureLayer3ServiceInput
								.setNtdId(serviceAgreementHierarchy.getServiceAgreementReference());
						newConfigureLayer3ServiceInput.setServiceCatalogId(internetMCR);

						sdpWrapper.configureLayer3Service(internetSvcItem.getServiceItemReference(),
								newConfigureLayer3ServiceInput);

						CatalogComponent ispComponent = catalogComponents.getComponents().stream()
								.filter(c -> SdpConstants.ISP_SERVICE.equals(c.getComponentType()))
								.findFirst().orElse(null);

						if (ispComponent != null)
						{
							String ispMCR = internetComponent.getCharges().get(0)
									.getMasterCatalogReference();

							ServiceItem ispSvcItem = serviceAgreementHierarchy.getServiceItems()
									.stream() // for each serviceItem
									.filter(serviceItem -> ispMCR
											.equals(serviceItem.getMasterCatalogKey()))
									.findFirst().orElse(null);
							if (ispSvcItem != null)
							{
								IspAccount ispAccount = ispWrapper.getIspAccount(new BigDecimal(
										serviceAgreementHierarchy.getServiceAgreementReference()));

								if (ispAccount.getStatusDescription().equals("ABUSE")
										|| ispAccount.getStatusDescription().equals("NON_PAY"))
								{
									IspCommand ispCommandsIn = new IspCommand();
									ispCommandsIn.setIspAccountId(
											new BigDecimal(serviceAgreementHierarchy
													.getServiceAgreementReference()));
									ispCommandsIn.setTransactionType(transactionTypeIn);

									ispWrapper.createIspCommands(
											new BigDecimal(serviceAgreementHierarchy
													.getServiceAgreementReference()),
											ispCommandsIn);

								}
							}
						}

					}

				}
			}

		}
		catch (Exception e)
		{
			String msg = "Exception processing resumeAllServiceAgreements(): accountReference: "
					+ accountReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);
		}

		businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);

		return resumeAllServiceAgreementsResponse;
	}

	public SuspendAllServiceAgreementsResponse suspendAllServiceAgreements(
			SuspendAllServiceAgreements parameter, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		SuspendAllServiceAgreementsResponse response = new SuspendAllServiceAgreementsResponse();
		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		IspAccount ispAccount = new IspAccount();
		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = null;

		String businessTransactionReference = null;
		String accountRef = parameter.getAccountReference();
		String transactionType = BusinessTransactionWrapper.TRANSACTION_SUSPEND_ALL_SERVICE_AGREEMENTS;

		try
		{
			businessTransactionReference = businessTransactionWrapper.addBusinessTransaction(
					transactionType, SdpConstants.FACADE_OWNER_NAME,
					parameter.getTransactionReference(), null, accountRef, null, wildBlueHeader);

			// ValidationProcessor
			ValidateSuspendAllServiceAgreementsResponse validationResult = validationProcessor
					.validateSuspendAllServiceAgreements(parameter, wildBlueHeader);

			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy btsAccountHierarchy;

			btsAccountHierarchy = businessTransactionWrapper
					.getAccountHierarchyByInternalReference(accountRef, wildBlueHeader);

			List<ServiceAgreementHierarchy> serviceAgreementHierarchies = btsAccountHierarchy
					.getServiceAgreements();

			for (ServiceAgreementHierarchy serviceAgreementHierarchy : serviceAgreementHierarchies)
			{
				List<String> catalogRefs = serviceAgreementHierarchy.getServiceItems().stream()
						.map(si -> {
							return si.getMasterCatalogKey();
						}).collect(Collectors.toList());

				GetComponentsResponse getComponentsResponse = catalogWrapper
						.getComponents(catalogRefs, wildBlueHeader);

				String serviceAgreementRef = serviceAgreementHierarchy
						.getServiceAgreementReference();

				getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementRef);

				getServiceProvisioningStatusResponse = fetchProcessor
						.getServiceProvisioningStatus(getServiceProvisioningStatus, wildBlueHeader);

				if (getServiceProvisioningStatusResponse.getServiceProvisioningStatus()
						.equals(SdpConstants.ACTIVE))
				{
					CatalogComponent internetComponent = getComponentsResponse.getComponents()
							.stream().filter(c -> SdpConstants.INTERNET_ACCESS_SERVICE
									.equals(c.getComponentType()))
							.findFirst().orElse(null);

					String internetMCR = internetComponent.getCharges().get(0)
							.getMasterCatalogReference();

					ServiceItem internetSvcItem = serviceAgreementHierarchy.getServiceItems()
							.stream() // for
							// each
							// serviceItem
							.filter(serviceItem -> internetMCR
									.equals(serviceItem.getMasterCatalogKey()))
							.findFirst().orElse(null);

					String suspendPackage = internetComponent.getCharges().get(0)
							.getTargetSystemReferences().stream()
							.filter(tsr -> SdpConstants.SDP_SUSPEND_PACKAGE
									.equals(tsr.getTargetSystemXref()))
							.map(tsr -> tsr.getTargetSystemXrefValue()).findFirst().orElse(null);

					NewConfigureLayer3ServiceInput newConfigureLayer3ServiceInput = new NewConfigureLayer3ServiceInput();
					newConfigureLayer3ServiceInput.setNtdId(serviceAgreementRef);
					newConfigureLayer3ServiceInput.setServiceCatalogId(suspendPackage);
					sdpWrapper.configureLayer3Service(internetSvcItem.getServiceItemReference(),
							newConfigureLayer3ServiceInput);

					CatalogComponent ispComponent = getComponentsResponse.getComponents().stream()
							.filter(c -> "EMAIL".equals(c.getComponentType())).findFirst()
							.orElse(null);

					if (ispComponent != null)
					{
						String ispMcr = ispComponent.getCharges().get(0)
								.getMasterCatalogReference();
						com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceItem ispSvcItem = serviceAgreementHierarchy
								.getServiceItems().stream()
								.filter(serviceItem -> ispMcr
										.equals(serviceItem.getMasterCatalogKey()))
								.findFirst().orElse(null);
						if (ispSvcItem != null)
						{
							ispAccount = ispWrapper
									.getIspAccount(new BigDecimal(serviceAgreementRef));
						}
					}

					if (ispAccount != null
							&& !ispAccount.getStatusCode().equals(SdpConstants.ACTIVE))
					{
						TransactionType transactionTypeIn = TransactionType.SUSPEND;
						IspCommand ispCommandsIn = new IspCommand();
						ispCommandsIn.setTransactionType(transactionTypeIn);
						ispWrapper.createIspCommands(new BigDecimal(serviceAgreementRef),
								ispCommandsIn);
					}
				}
			}
		}
		catch (Exception e)
		{
			String msg = "Exception processing suspendAllServiceAgreements(): accountRef: "
					+ accountRef + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);

		return response;
	}

}
