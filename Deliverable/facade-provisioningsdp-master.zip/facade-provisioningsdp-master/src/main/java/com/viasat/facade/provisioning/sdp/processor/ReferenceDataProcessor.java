package com.viasat.facade.provisioning.sdp.processor;

import java.util.List;

import com.viasat.common.client.EndpointInitException;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AccountHierarchy;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ServiceAgreementHierarchy;
import com.viasat.wildblue.internalwebservice.referencedata.ReferenceDataServiceInterface;
import com.viasat.wildblue.internalwebservice.referencedata.client.ReferenceDataClient;
import com.viasat.wildblue.internalwebservice.referencedata.data.ServiceProviderXml;

/**
 * Created by sryally on 12/21/2016.
 */
public class ReferenceDataProcessor {
    static ReferenceDataServiceInterface endpoint = null;

    protected static ReferenceDataServiceInterface getReferenceDataService()
            throws WebServiceException, EndpointInitException {
        return ReferenceDataClient.getInstance().getEndpoint();
    }

    public static String getServiceProviderNameFromExternalSystemAndSalesChannel(String externalSystem,
                                                                                 String salesChannel) throws WebServiceException
    {
        try
        {
            ReferenceDataServiceInterface referenceDataService = getReferenceDataService();
            ServiceProviderXml response = referenceDataService
                    .getServiceProviderBySalesChannelAndExternalSystemAndOrganizationName(
                            salesChannel, externalSystem, null,
                            ConfigurationConstants.COMMON_WILDBLUE_HEADER);
            return response.getProvisioningServiceProvider();
        }
        catch (Exception e)
        {
            throw new WebServiceException("Error getting service provider. " + e.getMessage(), e);
        }
    }

    public static String getServiceProviderNameFromBusinessTransactionAccountHierarchy(
            AccountHierarchy btsAccountHierarchy) throws WebServiceException
    {
        String externalSystemName = btsAccountHierarchy.getExternalSystemName();
        // We will assume that Sales Channel/ Service Provider will always be
        // the same over all service agreements.
        String salesChannel = null;
        List<ServiceAgreementHierarchy> serviceAgreementHierarchies =
                btsAccountHierarchy.getServiceAgreements();

        if ((serviceAgreementHierarchies != null)
                && !serviceAgreementHierarchies.isEmpty())
        {
            ServiceAgreementHierarchy serviceAgreementHierarchy =
                    serviceAgreementHierarchies.get(0);
            salesChannel = serviceAgreementHierarchy.getSalesChannelName();
        }

        return ReferenceDataProcessor
                .getServiceProviderNameFromExternalSystemAndSalesChannel(
                        externalSystemName, salesChannel);
    }
}
