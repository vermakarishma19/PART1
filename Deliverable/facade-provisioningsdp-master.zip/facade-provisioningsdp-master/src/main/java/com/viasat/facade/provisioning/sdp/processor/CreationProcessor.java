package com.viasat.facade.provisioning.sdp.processor;

import com.viasat.facade.provisioning.sdp.util.SdpConstants;
import com.viasat.facade.provisioning.sdp.wrapper.*;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.NewActivateLayer3Service;
import com.viasat.sdp.api.data.NewConfigureFixedNTDInput;
import com.viasat.sdp.api.data.NewConfigureLayer3ServiceInput;
import com.viasat.wildblue.common.commondata.BeamTechnicalInfo;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.exception.WildBlueWebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.common.location.GeoPosition;
import com.viasat.wildblue.facade.provisioning.data.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

@SuppressWarnings("unused") // spring beans
public class CreationProcessor
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CreationProcessor.class);

	private ValidationProcessor validationProcessor;
	private BusinessTransactionWrapper businessTransactionWrapper;
	private SDPWrapper sdpWrapper;
	private CatalogWrapper catalogWrapper;
	private ContactsWrapper contactsWrapper;
	private ServiceLocationWrapper serviceLocationWrapper;

	public void setValidationProcessor(ValidationProcessor validationProcessor)
	{
		this.validationProcessor = validationProcessor;
	}

	public void setBusinessTransactionWrapper(BusinessTransactionWrapper businessTransactionWrapper)
	{
		this.businessTransactionWrapper = businessTransactionWrapper;
	}

	public void setSdpWrapper(SDPWrapper sdpWrapper)
	{
		this.sdpWrapper = sdpWrapper;
	}

	public void setCatalogWrapper(CatalogWrapper catalogWrapper)
	{
		this.catalogWrapper = catalogWrapper;
	}

	public void setContactsWrapper(ContactsWrapper contactsWrapper)
	{
		this.contactsWrapper = contactsWrapper;
	}

	public void setServiceLocationWrapper(ServiceLocationWrapper serviceLocationWrapper)
	{
		this.serviceLocationWrapper = serviceLocationWrapper;
	}

	public AddCustomerHierarchyResponse addCustomerHierarchy(AddCustomerHierarchy parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		AddCustomerHierarchyResponse response = new AddCustomerHierarchyResponse();

		CustomerHierarchy customerHierarchy = parameter.getCustomerHierarchy();
		String customerReference = customerHierarchy.getCustomer().getCustomerReference();

		AccountHierarchy accountHierarchy = customerHierarchy.getAccountHierarchy().get(0);
		String accountReference = accountHierarchy.getAccount().getAccountReference();

		ServiceAgreementHierarchy serviceAgreementHierarchy = accountHierarchy
				.getServiceAgreementHierarchy().get(0);
		ServiceAgreement serviceAgreement = serviceAgreementHierarchy.getServiceAgreement();
		String serviceAgreementReference = serviceAgreement.getServiceAgreementReference();

		// start facade transaction
		String businessTransactionReference = businessTransactionWrapper.addBusinessTransaction(
				BusinessTransactionWrapper.TRANSACTION_ADD_CUSTOMER_HIERARCHY,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(),
				customerReference, accountReference, serviceAgreementReference, wildBlueHeader);

		try
		{
			// validate
			ValidateAddCustomerHierarchyResponse validationResponse = validationProcessor
					.validateAddCustomerHierarchy(parameter, wildBlueHeader);
			validationProcessor.checkValidationResult(validationResponse.getValidationResult());

			// update facade transaction
			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);

			// pre-provision modem SDP API NewConfigureFixedNTD
			BeamTechnicalInfo beamInfo = serviceAgreement.getBeamInfo().getBeamTechnicalInfo();
			GeoPosition geoPosition = serviceAgreement.getServiceContact().getContactInfo()
					.getLocation().getGeoPosition();

			NewConfigureFixedNTDInput fixedNTD = new NewConfigureFixedNTDInput();
			fixedNTD.setSatelliteId(
					sdpWrapper.satelliteIdFromSatelliteName(beamInfo.getSatelliteName()));
			fixedNTD.setCsaId(beamInfo.getBeamNumber().toString());
			fixedNTD.setLatitude(BigDecimal.valueOf(geoPosition.getLatitude()));
			fixedNTD.setLongitude(BigDecimal.valueOf(geoPosition.getLongitude()));

			sdpWrapper.configureFixedNTD(serviceAgreementReference, null, fixedNTD);

			// check for a VoIP service item
			ServiceItem voIpSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
					.filter(si -> "VOIP".equals(si.getType())).findFirst().orElse(null);

			if (voIpSvcItem != null)
			{
				// add service for VoIP
				NewConfigureLayer3ServiceInput voIpLayer3Service = new NewConfigureLayer3ServiceInput();
				voIpLayer3Service.setServiceCatalogId(voIpSvcItem.getCatalogNumber());
				voIpLayer3Service.setNtdId(serviceAgreementReference);

				// TODO pending defect with sdp api
				// https://jira.viasat.com/browse/SDP-6195
				// sdpWrapper.configureLayer3Service(voIpSvcItem.getServiceItemReference(),
				// voIpLayer3Service);
			}

			// internet-access service
			ServiceItem internetSvcItem = serviceAgreementHierarchy.getServiceItem().stream()
					.filter(si -> "INTERNET_ACCESS_SERVICE".equals(si.getType())).findFirst()
					.orElse(null);

			// add service for internet access
			NewConfigureLayer3ServiceInput internetLayer3Service = new NewConfigureLayer3ServiceInput();
			internetLayer3Service.setServiceCatalogId(internetSvcItem.getCatalogNumber());
			internetLayer3Service.setNtdId(serviceAgreementReference);

			sdpWrapper.configureLayer3Service(internetSvcItem.getServiceItemReference(),
					internetLayer3Service);

			// contact service
			contactsWrapper.createContactAggregate(parameter,
					wildBlueHeader.getInvokedBy().getUsername(),
					wildBlueHeader.getInvokedBy().getApplication());

			// service location
			serviceLocationWrapper.createServiceLocation(serviceAgreementHierarchy, wildBlueHeader);
		}
		catch (Exception e)
		{
			String msg = "Exception processing addCustomerHierarchy(): customerRef: "
					+ customerReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);
		return response;
	}

	public AddServiceItemResponse addServiceItem(AddServiceItem parameter,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		AddServiceItemResponse response = new AddServiceItemResponse();

		String serviceAgreementReference = parameter.getServiceAgreementReference();
		String serviceItemReference = parameter.getServiceItem().getServiceItemReference();

		com.viasat.wildblue.internalwebservice.businesstransaction.data.CustomerHierarchy customerHierarchy = businessTransactionWrapper
				.getCustomerHierarchyByInternalServiceAgreementReference(serviceAgreementReference,
						wildBlueHeader);

		String customerReference = customerHierarchy.getCustomerReference();

		String accountReference = customerHierarchy.getAccounts().get(0).getAccountReference();
		// start facade transaction
		String businessTransactionReference = businessTransactionWrapper.addBusinessTransaction(
				BusinessTransactionWrapper.TRANSACTION_ADD_SERVICE_ITEM,
				SdpConstants.FACADE_OWNER_NAME, parameter.getTransactionReference(),
				customerReference, accountReference, serviceAgreementReference, wildBlueHeader);
		try
		{
			ValidateAddServiceItemResponse validationResponse = validationProcessor
					.validateAddServiceItem(parameter, wildBlueHeader);
			validationProcessor.checkValidationResult(validationResponse.getValidationResult());

			// update facade transaction
			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_WORKING, wildBlueHeader);
			String voIpSvcItem = parameter.getServiceItem().getName();
			if (voIpSvcItem.equals(SdpConstants.VOIP))
			{
				// add service for VoIP
				NewConfigureLayer3ServiceInput voIpLayer3Service = new NewConfigureLayer3ServiceInput();
				voIpLayer3Service
						.setServiceCatalogId(parameter.getServiceItem().getCatalogNumber());
				voIpLayer3Service.setNtdId(serviceAgreementReference);
				Layer3Service configLayer3Service = sdpWrapper
						.configureLayer3Service(serviceItemReference, voIpLayer3Service);

				// activate
				if (configLayer3Service != null)
				{
					NewActivateLayer3Service voTpActivateLayer3Service = new NewActivateLayer3Service();
					voTpActivateLayer3Service.setTargetId(serviceItemReference);

					sdpWrapper.activateLayer3Service(voTpActivateLayer3Service.getTargetId());

				}
			}
		}
		catch (Exception e)
		{
			String msg = "Exception processing addServiceItem(): customerRef: "
					+ serviceAgreementReference + ", Error: " + e.getMessage();
			LOGGER.error(msg, e);

			businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
					BusinessTransactionWrapper.TRANSACTION_STATUS_FAILED, wildBlueHeader);

			if (e instanceof WebServiceException)
				throw (WebServiceException) e;
			else
				throw new WildBlueWebServiceException(msg, e);
		}

		businessTransactionWrapper.updateBusinessTransaction(businessTransactionReference,
				BusinessTransactionWrapper.TRANSACTION_STATUS_COMPLETE, wildBlueHeader);
		return response;

	}
}
