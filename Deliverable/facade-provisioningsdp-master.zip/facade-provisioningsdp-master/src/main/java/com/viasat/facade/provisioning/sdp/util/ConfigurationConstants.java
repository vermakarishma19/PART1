package com.viasat.facade.provisioning.sdp.util;

import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;

/**
 * Created by sryally on 12/21/2016.
 */
public class ConfigurationConstants {
    private static final String APP_NAME = "COMMON_VOLUBILL_CLIENT";
    private static final String USER_NAME = "COMMON_VOLUBILL_CLIENT_USER";

    public static final WildBlueHeader COMMON_WILDBLUE_HEADER;

    static
    {
        COMMON_WILDBLUE_HEADER = new WildBlueHeader();

        InvokedBy invokedBy = new InvokedBy();
        invokedBy.setApplication(APP_NAME);
        invokedBy.setUsername(USER_NAME);
        COMMON_WILDBLUE_HEADER.setInvokedBy(invokedBy);
    }

    public static final String VOLUBILL_PASSWORD_KEY = "volubillPassword";

    public static final String VOLUBILL_USERNAME_KEY = "volubillUsername";

    public static final String CONFIG_DOCUMENT_NAME = "VOLUBILL_COMMON";

    public static final String RATING_ENGINE_SUB_ID = "ratingCheckSubId";
}
