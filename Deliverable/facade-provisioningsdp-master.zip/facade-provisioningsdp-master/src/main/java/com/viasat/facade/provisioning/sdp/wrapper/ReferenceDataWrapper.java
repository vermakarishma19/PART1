package com.viasat.facade.provisioning.sdp.wrapper;

import com.viasat.common.client.EndpointInitException;
import com.viasat.common.client.StandardClient;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.internalwebservice.referencedata.ReferenceDataServiceInterface;
import com.viasat.wildblue.internalwebservice.referencedata.data.Gateway;
import com.viasat.wildblue.internalwebservice.referencedata.data.ReasonXml;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

// TODO copied from ReferenceDataProcessor in Facade-Provisioning-Volubill-CORE
public class ReferenceDataWrapper
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataWrapper.class);

	private StandardClient<ReferenceDataServiceInterface> referenceDataClient;

	public void setReferenceDataClient(
			StandardClient<ReferenceDataServiceInterface> referenceDataClient)
	{
		if (LOGGER.isDebugEnabled())
			LOGGER.debug("Setting referenceDataClient: " + referenceDataClient);

		this.referenceDataClient = referenceDataClient;
	}

	public String getGatewayName(String gatewayId, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{

		List<Gateway> gateways;
		try
		{
			gateways = referenceDataClient.getEndpoint().getGateways(wildBlueHeader);
		}
		catch (EndpointInitException e)
		{
			throw new WebServiceException("Failed to call Business Transaction!", e);
		}

		String gatewayName = null;

		try
		{
			Long gatewayNumber = Long.parseLong(gatewayId);

			for (Gateway gateway : gateways)
			{
				if (gatewayNumber.equals(gateway.getGatewayNumber()))
				{
					gatewayName = gateway.getGatewayName();
				}
			}
		}
		catch (NumberFormatException e)
		{
			// Log the error, then return null
			LOGGER.error(e.getMessage(), e);
		}

		return gatewayName;
	}

	public List<ReasonXml> getReasonsByTransactionTypeNameAndSalesChannelName(
			String transactionTypeName, String salesChannelName, WildBlueHeader wildBlueHeader)
			throws WebServiceException
	{
		try
		{
			return referenceDataClient.getEndpoint()
					.getReasonsByTransactionTypeNameAndSalesChannelName(transactionTypeName,
							salesChannelName, wildBlueHeader);
		}
		catch (EndpointInitException e)
		{
			throw new WebServiceException("Failed to call Business Transaction!", e);
		}
	}

	public boolean isValidReason(String reason, String transactionTypeName, String salesChannelName,
			WildBlueHeader wildBlueHeader) throws WebServiceException
	{
		boolean valid = false;
		List<ReasonXml> reasons = getReasonsByTransactionTypeNameAndSalesChannelName(
				transactionTypeName, salesChannelName, wildBlueHeader);

		for (ReasonXml reasonXml : reasons)
		{
			if (reasonXml.getName().equals(reason))
			{
				valid = true;
				break;
			}
		}

		return valid;
	}
}
