package com.viasat.facade.provisioning.sdp.wrapper;

import com.viasat.facade.isp.api.model.IspAccount;
import com.viasat.facade.isp.api.model.IspCommand;
import com.viasat.facade.isp.client.IspServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.wildblue.common.exception.WebServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

/**
 * Created by kverma on 3/16/2017.
 */
public class ISPWrapper
{

	private static final Logger LOGGER = LoggerFactory.getLogger(ISPWrapper.class);

	private IspServiceClient ispServiceClient;

	public void setIspServiceClient(IspServiceClient ispServiceClient)
	{
		this.ispServiceClient = ispServiceClient;
	}

	public IspAccount getIspAccount(BigDecimal ispAccountID) throws WebServiceException
	{
		IspAccount req = new IspAccount();
		try
		{
			req = ispServiceClient.getIspAccount(ispAccountID);
		}
		catch (InternalServiceFault internalServiceFault)
		{
			internalServiceFault.printStackTrace();
		}
		return req;
	}

	public IspCommand createIspCommands(BigDecimal ispAccountId , IspCommand ispCommand) throws WebServiceException {

		IspCommand req = new IspCommand();
		try {
			req = ispServiceClient.createIspCommands(ispAccountId,ispCommand);
		} catch (InternalServiceFault internalServiceFault) {
			internalServiceFault.printStackTrace();
		}
		return req;
	}

}
