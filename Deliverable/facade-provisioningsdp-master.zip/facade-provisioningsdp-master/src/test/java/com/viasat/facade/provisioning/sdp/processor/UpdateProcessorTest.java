package com.viasat.facade.provisioning.sdp.processor;

/**
 * Created by sjala on 3/7/2017.
 */

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.ServiceProviderFinder;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISContact;
import com.viasat.facade.provisioning.sdp.util.servicemocks.IWSBusinessTransaction;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.sdp.client.SDPClient;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.UpdateContacts;
import com.viasat.wildblue.facade.provisioning.data.UpdateContactsResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;
import com.viasat.wildblue.internalwebservice.referencedata.ReferenceDataServiceInterface;

// PowerMock for Mockito
@RunWith(PowerMockRunner.class)
@PrepareForTest(
        { BusinessTransaction.class, ReferenceDataServiceInterface.class, SDPClient.class,
                ServiceLocationServiceClient.class, ContactServiceClient.class,
                ServiceProviderFinder.class })
// spring context
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
        { "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spring beans
public class UpdateProcessorTest {
    private static final WildBlueHeader WB_HDR;
    private static final String CUSTOMER_CONTACT_ROLE_TYPE = "CUSTOMER_CONTACT";
    private static final String ACCOUNT_CONTACT_ROLE_TYPE = "ACCOUNT_CONTACT";

    static {
        WB_HDR = new WildBlueHeader();
        WB_HDR.setInvokedBy(new InvokedBy());
        WB_HDR.getInvokedBy().setApplication("UnitTest");
        WB_HDR.getInvokedBy().setUsername(CreationProcessorTest.class.getSimpleName());
    }

    // spring beans
    @Resource(name = "sdpProvisioningService")
    private ProvisioningService sdpProvisioningService;

    @Resource(name = "btsClient")
    private BusinessTransactionClient btsClient;

    @Resource(name = "sdpClient")
    private SDPClient sdpClient;

    @Resource(name = "serviceLocationServiceClient")
    private ServiceLocationServiceClient svcLocClient;

    @Resource(name = "contactClient")
    private ContactServiceClient contactClient;

    // endpoint mocks
    private BusinessTransaction bts = mock(BusinessTransaction.class);

    @Before
    public void prepMocks() throws Exception {
        reset(btsClient);
        reset(contactClient);
        reset(sdpClient);
        reset(svcLocClient);

        // workaround for client wrapper
        when(btsClient.getEndpoint()).thenReturn(bts);
    }
    // Testcase for updateContacts() service
    @Test
    public void updateContacts() throws WebServiceException, JAXBException, XMLStreamException, InternalServiceFault {
        String serviceAgreementReference="400541187";
        String accountRef = "303264845";

        when(bts.getServiceAgreementByInternalReference(any(),
                any())).then(IWSBusinessTransaction.getServiceAgreementByInternalReference(serviceAgreementReference));

        UpdateContacts parameter = JAXBUtility.unmarshalSoapEnvelope(
                getClass().getResourceAsStream("/requests/UpdateContacts.xml"),
                UpdateContacts.class);

        when(contactClient.getContactAggregates(any(), any(), any(), any(),
                any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .then(ISContact.getContactAggregates(accountRef, serviceAgreementReference, true));



        UpdateContactsResponse response = sdpProvisioningService.updateContacts(parameter,WB_HDR);
    }
}
