package com.viasat.facade.provisioning.sdp.processor;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.common.client.EndpointInitException;
import com.viasat.common.fault.WebServiceFault;
import com.viasat.facade.catalog.CatalogService;
import com.viasat.facade.catalog.client.CatalogServiceClient;
import com.viasat.facade.isp.api.model.IspAccount;
import com.viasat.facade.isp.client.IspServiceClient;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.ServiceProviderFinder;
import com.viasat.facade.provisioning.sdp.util.servicemocks.FCDCatalog;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISContact;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISServiceLocation;
import com.viasat.facade.provisioning.sdp.util.servicemocks.IWSBusinessTransaction;
import com.viasat.facade.provisioning.sdp.util.servicemocks.LibSDPAPI;
import com.viasat.facade.provisioning.sdp.wrapper.BusinessTransactionWrapper;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.sdp.client.SDPClient;
import com.viasat.sdp.client.SDPServiceFault;
import com.viasat.wildblue.common.commondata.Contact;
import com.viasat.wildblue.common.commondata.ContactInfo;
import com.viasat.wildblue.common.commondata.Person;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.Account;
import com.viasat.wildblue.facade.provisioning.data.AccountContactMap;
import com.viasat.wildblue.facade.provisioning.data.Customer;
import com.viasat.wildblue.facade.provisioning.data.GetAccount;
import com.viasat.wildblue.facade.provisioning.data.GetAccountHierarchy;
import com.viasat.wildblue.facade.provisioning.data.GetAccountHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.GetAccountResponse;
import com.viasat.wildblue.facade.provisioning.data.GetAllServiceAgreementHierarchies;
import com.viasat.wildblue.facade.provisioning.data.GetAllServiceAgreementHierarchiesResponse;
import com.viasat.wildblue.facade.provisioning.data.GetContactsForAccounts;
import com.viasat.wildblue.facade.provisioning.data.GetContactsForAccountsResponse;
import com.viasat.wildblue.facade.provisioning.data.GetCustomer;
import com.viasat.wildblue.facade.provisioning.data.GetCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.GetCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.GetCustomerResponse;
import com.viasat.wildblue.facade.provisioning.data.GetProvisioningDetails;
import com.viasat.wildblue.facade.provisioning.data.GetProvisioningDetailsResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreementHierarchy;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreementHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceItem;
import com.viasat.wildblue.facade.provisioning.data.GetServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatus;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatusResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetSalesChannelTypeForSalesChannelNameResponse;
import com.viasat.wildblue.internalwebservice.referencedata.ReferenceDataServiceInterface;

// PowerMock for Mockito
@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ BusinessTransaction.class, ReferenceDataServiceInterface.class, SDPClient.class,
		ServiceLocationServiceClient.class, CatalogService.class, ContactServiceClient.class,
		ServiceProviderFinder.class, IspServiceClient.class })
// spring context
@PowerMockIgnore(
{ "org.xml.*", "javax.xml.*", "org.apache.log4j.*", "com.sun.org.apache.xerces.*",
		"org.w3c.dom.*" })
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spring beans
public class FetchProcessorTest
{
	private static final WildBlueHeader WB_HDR;
	private static final String CUSTOMER_CONTACT_ROLE_TYPE = "CUSTOMER_CONTACT";
	private static final String ACCOUNT_CONTACT_ROLE_TYPE = "ACCOUNT_CONTACT";

	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("UnitTest");
		WB_HDR.getInvokedBy().setUsername(CreationProcessorTest.class.getSimpleName());
	}

	// spring beans
	@Resource(name = "sdpProvisioningService")
	private ProvisioningService sdpProvisioningService;

	@Resource(name = "btsClient")
	private BusinessTransactionClient btsClient;

	@Resource(name = "sdpClient")
	private SDPClient sdpClient;

	@Resource(name = "serviceLocationServiceClient")
	private ServiceLocationServiceClient svcLocClient;

	@Resource(name = "contactClient")
	private ContactServiceClient contactClient;

	@Resource(name = "catalogClient")
	private CatalogServiceClient catalogClient;

	@Resource(name = "ispServiceClient")
	private IspServiceClient ispServiceClient;

	// endpoint mocks
	private BusinessTransaction bts = mock(BusinessTransaction.class);
	private CatalogService catalog = mock(CatalogService.class);
	private FetchProcessor fetchProcessor = mock(FetchProcessor.class);

	@Before
	public void prepMocks() throws Exception
	{
		reset(btsClient);
		reset(contactClient);
		reset(sdpClient);
		reset(svcLocClient);
		reset(catalog);
		reset(ispServiceClient);

		// workaround for client wrapper
		when(btsClient.getEndpoint()).thenReturn(bts);
		when(catalogClient.getEndpoint()).thenReturn(catalog);

	}

	@Test
	public void getCustomer()
			throws WebServiceException, InternalServiceFault, JAXBException, XMLStreamException
	{
		String customerRef = "203357138";
		String accountRef = "303264845";
		String serviceAgreementRef = "403584678";
		String serviceProviderName = "WildBlue";

		PowerMockito.mockStatic(ServiceProviderFinder.class);

		when(bts.getCustomerHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getCustomerHierarchyByInternalReference(customerRef));

		when(ServiceProviderFinder
				.getServiceProviderNameFromBusinessTransactionCustomerHierarchy(any()))
						.thenReturn(serviceProviderName);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));

		GetCustomer getCustomer = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getClassLoader().getResourceAsStream("requests/GetCustomer.xml"),
				GetCustomer.class);

		GetCustomerResponse resp = sdpProvisioningService.getCustomer(getCustomer, WB_HDR);

		assertNotNull(resp);

		Customer customer = resp.getCustomer();
		assertNotNull(customer);
		assertThat(customer.getCustomerType(), is("RESIDENTIAL"));
		assertThat(customer.getServiceProviderType(), is("WildBlue"));

		Contact contact = customer.getCustomerContact();
		assertNotNull(contact);

		Person person = contact.getPerson();
		assertNotNull(person);
		assertThat(person.getFirstName(), is("Jane"));
		assertThat(person.getLastName(), is("Buck"));

		ContactInfo contactInfo = contact.getContactInfo();
		assertNotNull(contactInfo);
		assertThat(contactInfo.getEmailAddress(), is("jane.buck@example.com"));
		assertThat(contactInfo.getPrimaryPhone(), is("7204936072"));

	}

	@Test
	public void getAccount()
			throws WebServiceException, InternalServiceFault, JAXBException, XMLStreamException

	{
		String accountRef = "303264845";
		String serviceAgreementRef = "403584678";
		String serviceProviderName = "WildBlue";

		PowerMockito.mockStatic(ServiceProviderFinder.class);

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(ServiceProviderFinder
				.getServiceProviderNameFromBusinessTransactionCustomerHierarchy(any()))
						.thenReturn(serviceProviderName);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));

		GetAccount getAccount = new GetAccount();
		getAccount.setAccountReference(accountRef);

		GetAccountResponse resp = sdpProvisioningService.getAccount(getAccount, WB_HDR);

		assertNotNull(resp);

		Account account = resp.getAccount();
		assertNotNull(account);

		Contact contact = account.getAccountContact();
		assertNotNull(contact);

		Person person = contact.getPerson();
		assertThat(person.getFirstName(), is("Jane"));
		assertThat(person.getLastName(), is("Buck"));

		ContactInfo contactInfo = contact.getContactInfo();
		assertNotNull(contactInfo);
		assertThat(contactInfo.getEmailAddress(), is("jane.buck@example.com"));
		assertThat(contactInfo.getPrimaryPhone(), is("7204936072"));
	}

	@Test
	public void getContactsForAccounts()
			throws WebServiceException, InternalServiceFault, JAXBException, XMLStreamException
	{
		String accountRef = "303264845";
		String serviceAgreementRef = "403584678";
		String serviceProviderName = "WildBlue";

		PowerMockito.mockStatic(ServiceProviderFinder.class);

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(ServiceProviderFinder
				.getServiceProviderNameFromBusinessTransactionCustomerHierarchy(any()))
						.thenReturn(serviceProviderName);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));

		GetAccount getAccount = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getClassLoader().getResourceAsStream("requests/GetAccount.xml"),
				GetAccount.class);

		GetAccountResponse resp = sdpProvisioningService.getAccount(getAccount, WB_HDR);

		GetContactsForAccounts getContactsForAccounts = JAXBUtility
				.unmarshalSoapEnvelope(
						getClass().getClassLoader()
								.getResourceAsStream("requests/GetContactsForAccounts.xml"),
						GetContactsForAccounts.class);

		GetContactsForAccountsResponse response = sdpProvisioningService
				.getContactsForAccounts(getContactsForAccounts, WB_HDR);

		assertNotNull(response);

		List<AccountContactMap> account = response.getAccountContactMaps();
		assertNotNull(account);

		Contact contact = account.get(0).getAccountContact();
		assertNotNull(contact);

		Person person = contact.getPerson();
		assertThat(person.getFirstName(), is("Jane"));
		assertThat(person.getLastName(), is("Buck"));

		ContactInfo contactInfo = contact.getContactInfo();
		assertNotNull(contactInfo);
		assertThat(contactInfo.getEmailAddress(), is("jane.buck@example.com"));
	}

	@Test
	public void testGetProvisioningDetails() throws EndpointInitException
	{
		final BusinessTransactionWrapper businessTransactionUtility = null;
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;
		String flexFieldStr2 = "flexField";
		String accountRef = "300373140";
		String serviceAgreementRef = "400366791";
		String serviceProviderName = "WildBlue";
		try
		{
			PowerMockito.mockStatic(ServiceProviderFinder.class);

			when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
					.then(IWSBusinessTransaction
							.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

			when(ServiceProviderFinder
					.getServiceProviderNameFromBusinessTransactionCustomerHierarchy(any()))
							.thenReturn(serviceProviderName);

			getServiceProvisioningStatus();

			when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

			when(sdpClient.getServiceArea(any()))
					.then(LibSDPAPI.getServiceArea(serviceAgreementRef));

			GetProvisioningDetails parameter = JAXBUtility.unmarshalSoapEnvelope(
					getClass().getResourceAsStream("/requests/GetProvisioningDetails.xml"),
					GetProvisioningDetails.class);
			GetProvisioningDetailsResponse response = sdpProvisioningService
					.getProvisioningDetails(parameter, wildBlueHeader);
			assertNotNull(response);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void getServiceProvisioningStatus() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		GetServiceProvisioningStatusResponse response = sdpProvisioningService
				.getServiceProvisioningStatus(parameter, wildBlueHeader);

		assertNotNull(response);

		assertThat(response.getServiceProvisioningStatus(), is("PENDING"));

	}

	@Test
	public void getServiceAgreement() throws WebServiceException, JAXBException, XMLStreamException,
			SDPServiceFault, InternalServiceFault, WebServiceFault
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

		when(bts.getServiceAgreementByInternalReference(any(), any())).then(
				IWSBusinessTransaction.getServiceAgreementByInternalReference(serviceAgreementRef));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);
		sdpProvisioningService.getServiceProvisioningStatus(param, wildBlueHeader);

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(null, serviceAgreementRef, true));

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));

		GetServiceAgreement parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceAgreement.xml"),
				GetServiceAgreement.class);

		GetServiceAgreementResponse response = sdpProvisioningService.getServiceAgreement(parameter,
				wildBlueHeader);
		assertNotNull(response);

	}

	@Test
	public void getServiceAgreementHierarchy() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault, InternalServiceFault
	{
		String serviceAgreementRef = "400366791";
		String salesChannelType = "Retail";
		String mcr = "210401";
		String serviceId = "802066855";

		GetSalesChannelTypeForSalesChannelNameResponse getSalesChannelTypeForSalesChannelNameResponse = new GetSalesChannelTypeForSalesChannelNameResponse();
		getSalesChannelTypeForSalesChannelNameResponse.setSalesChannelType(salesChannelType);

		FetchProcessor fetchProcessor = new FetchProcessor();

		IspAccount ispAccount = new IspAccount();
		ispAccount.setStatusCode("00");

		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementRef);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = new GetServiceProvisioningStatusResponse();
		getServiceProvisioningStatusResponse.setServiceAgreementReference(serviceAgreementRef);
		getServiceProvisioningStatusResponse.setServiceProvisioningStatus("PENDING");

		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

		when(bts.getSalesChannelTypeForSalesChannelName(any(), any()))
				.thenReturn(getSalesChannelTypeForSalesChannelNameResponse);
		getServiceProvisioningStatus();

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(ispServiceClient.getIspAccount(any())).thenReturn(ispAccount);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(null, serviceAgreementRef, true));

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));

		GetServiceAgreementHierarchy parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceAgreementHierarchy.xml"),
				GetServiceAgreementHierarchy.class);

		GetServiceAgreementHierarchyResponse response = sdpProvisioningService
				.getServiceAgreementHierarchy(parameter, wildBlueHeader);

		assertNotNull(response);

		assertThat(response.getServiceAgreementHierarchy().getServiceAgreement()
				.getServiceAgreementReference(), is("400366791"));

		assertThat(response.getServiceAgreementHierarchy().getServiceAgreement().getStatus(),
				is("PENDING"));

	}

	@Test
	public void getAccountHierarchy() throws WebServiceException, WebServiceFault, SDPServiceFault,
			InternalServiceFault, JAXBException, XMLStreamException
	{
		String accountRef = "300366283";
		String serviceAgreementRef = "400366791";
		String salesChannelType = "Retail";
		String mcr = "210401";
		String serviceId = "802066855";

		GetSalesChannelTypeForSalesChannelNameResponse getSalesChannelTypeForSalesChannelNameResponse = new GetSalesChannelTypeForSalesChannelNameResponse();
		getSalesChannelTypeForSalesChannelNameResponse.setSalesChannelType(salesChannelType);

		FetchProcessor fetchProcessor = new FetchProcessor();

		IspAccount ispAccount = new IspAccount();
		ispAccount.setStatusCode("00");

		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementRef);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = new GetServiceProvisioningStatusResponse();
		getServiceProvisioningStatusResponse.setServiceAgreementReference(serviceAgreementRef);
		getServiceProvisioningStatusResponse.setServiceProvisioningStatus("PENDING");

		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;
		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(bts.getSalesChannelTypeForSalesChannelName(any(), any()))
				.thenReturn(getSalesChannelTypeForSalesChannelNameResponse);

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse1 = sdpProvisioningService
				.getServiceProvisioningStatus(param, wildBlueHeader);

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(ispServiceClient.getIspAccount(any())).thenReturn(ispAccount);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));

		GetAccountHierarchy parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetAccountHierarchy.xml"),
				GetAccountHierarchy.class);

		GetAccountHierarchyResponse response = sdpProvisioningService.getAccountHierarchy(parameter,
				wildBlueHeader);

		assertNotNull(response);

		assertThat(response.getAccountHierarchy().getServiceAgreementHierarchy().get(0)
				.getServiceAgreement().getServiceAgreementReference(), is("400366791"));

		assertThat(response.getAccountHierarchy().getServiceAgreementHierarchy().get(0)
				.getServiceAgreement().getStatus(), is("PENDING"));

	}

	@Test
	public void getServiceItem() throws WebServiceException, JAXBException, XMLStreamException,
			WebServiceFault, SDPServiceFault, InternalServiceFault
	{
		String serviceAgreementRef = "400366791";
		String salesChannelType = "Retail";
		String mcr = "210401";
		String serviceId = "802066855";

		GetSalesChannelTypeForSalesChannelNameResponse getSalesChannelTypeForSalesChannelNameResponse = new GetSalesChannelTypeForSalesChannelNameResponse();
		getSalesChannelTypeForSalesChannelNameResponse.setSalesChannelType(salesChannelType);

		FetchProcessor fetchProcessor = new FetchProcessor();

		IspAccount ispAccount = new IspAccount();
		ispAccount.setStatusCode("00");

		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getCustomerHierarchyByInternalServiceItemReference(any(), any()))
				.then(IWSBusinessTransaction
						.getCustomerHierarchyByInternalServiceItemReference(serviceId));

		getServiceProvisioningStatus();

		when(ispServiceClient.getIspAccount(any())).thenReturn(ispAccount);

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));

		GetServiceItem parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceItem.xml"),
				GetServiceItem.class);

		GetServiceItemResponse response = sdpProvisioningService.getServiceItem(parameter,
				wildBlueHeader);

		assertNotNull(response);

	}

	@Test
	public void getCustomerHierarchy() throws WebServiceException, JAXBException,
			XMLStreamException, InternalServiceFault, WebServiceFault, SDPServiceFault
	{
		String customerRef = "200368081";
		String accountRef = "300366283";
		String serviceAgreementRef = "400366791";
		String salesChannelType = "Retail";
		String mcr = "210401";
		String serviceId = "802066855";

		GetSalesChannelTypeForSalesChannelNameResponse getSalesChannelTypeForSalesChannelNameResponse = new GetSalesChannelTypeForSalesChannelNameResponse();
		getSalesChannelTypeForSalesChannelNameResponse.setSalesChannelType(salesChannelType);

		IspAccount ispAccount = new IspAccount();
		ispAccount.setStatusCode("00");

		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementRef);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = new GetServiceProvisioningStatusResponse();
		getServiceProvisioningStatusResponse.setServiceAgreementReference(serviceAgreementRef);
		getServiceProvisioningStatusResponse.setServiceProvisioningStatus("PENDING");

		FetchProcessor fetchProcessor = new FetchProcessor();
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getSalesChannelTypeForSalesChannelName(any(), any()))
				.thenReturn(getSalesChannelTypeForSalesChannelNameResponse);

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse1 = sdpProvisioningService
				.getServiceProvisioningStatus(param, wildBlueHeader);

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(ispServiceClient.getIspAccount(any())).thenReturn(ispAccount);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));

		when(bts.getCustomerHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getCustomerHierarchyByInternalReference(customerRef));

		GetCustomerHierarchy parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetCustomerHierarchy.xml"),
				GetCustomerHierarchy.class);

		GetCustomerHierarchyResponse response = sdpProvisioningService
				.getCustomerHierarchy(parameter, wildBlueHeader);

		assertNotNull(response);

		assertThat(response.getCustomerHierarchy().getAccountHierarchy().get(0)
				.getServiceAgreementHierarchy().get(0).getServiceAgreement()
				.getServiceAgreementReference(), is("400366791"));

		assertThat(
				response.getCustomerHierarchy().getAccountHierarchy().get(0)
						.getServiceAgreementHierarchy().get(0).getServiceAgreement().getStatus(),
				is("PENDING"));
	}

	@Test
	public void getAllServiceAgreementHierarchies() throws WebServiceException, XMLStreamException,
			SDPServiceFault, WebServiceFault, JAXBException, InternalServiceFault
	{
		String serviceAgreementRef = "400366791";
		String salesChannelType = "Retail";
		String mcr = "210401";
		String serviceId = "802066855";

		GetSalesChannelTypeForSalesChannelNameResponse getSalesChannelTypeForSalesChannelNameResponse = new GetSalesChannelTypeForSalesChannelNameResponse();
		getSalesChannelTypeForSalesChannelNameResponse.setSalesChannelType(salesChannelType);

		FetchProcessor fetchProcessor = new FetchProcessor();

		IspAccount ispAccount = new IspAccount();
		ispAccount.setStatusCode("00");

		GetServiceProvisioningStatus getServiceProvisioningStatus = new GetServiceProvisioningStatus();
		getServiceProvisioningStatus.setServiceAgreementReference(serviceAgreementRef);

		GetServiceProvisioningStatusResponse getServiceProvisioningStatusResponse = new GetServiceProvisioningStatusResponse();
		getServiceProvisioningStatusResponse.setServiceAgreementReference(serviceAgreementRef);
		getServiceProvisioningStatusResponse.setServiceProvisioningStatus("PENDING");

		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

		when(bts.getSalesChannelTypeForSalesChannelName(any(), any()))
				.thenReturn(getSalesChannelTypeForSalesChannelNameResponse);

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(ispServiceClient.getIspAccount(any())).thenReturn(ispAccount);

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(null, serviceAgreementRef, true));

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));

		GetServiceProvisioningStatus request = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(request, wildBlueHeader);

		GetServiceAgreementHierarchy param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceAgreementHierarchy.xml"),
				GetServiceAgreementHierarchy.class);

		sdpProvisioningService.getServiceAgreementHierarchy(param, wildBlueHeader);

		GetAllServiceAgreementHierarchies parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetAllServiceAgreementHierarchies.xml"),
				GetAllServiceAgreementHierarchies.class);

		GetAllServiceAgreementHierarchiesResponse response = sdpProvisioningService
				.getAllServiceAgreementHierarchies(parameter, WB_HDR);

		assertNotNull(response);

		assertThat(response.getServiceAgreementHierarchy().get(0).getServiceAgreement()
				.getServiceAgreementReference(), is("400366791"));

		assertThat(response.getServiceAgreementHierarchy().get(0).getServiceAgreement().getStatus(),
				is("PENDING"));

	}

}