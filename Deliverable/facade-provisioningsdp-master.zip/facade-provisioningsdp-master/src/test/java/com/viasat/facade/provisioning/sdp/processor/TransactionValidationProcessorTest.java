package com.viasat.facade.provisioning.sdp.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.Date;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.common.fault.WebServiceFault;
import com.viasat.facade.catalog.CatalogService;
import com.viasat.facade.catalog.client.CatalogServiceClient;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.servicemocks.FCDCatalog;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISContact;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISServiceLocation;
import com.viasat.facade.provisioning.sdp.util.servicemocks.IWSBusinessTransaction;
import com.viasat.facade.provisioning.sdp.util.servicemocks.LibSDPAPI;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocations;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.sdp.api.data.FixedNTD;
import com.viasat.sdp.api.data.FixedNtdState;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.Layer3ServiceConfig;
import com.viasat.sdp.api.data.Layer3ServiceState;
import com.viasat.sdp.client.SDPClient;
import com.viasat.sdp.client.SDPServiceFault;
import com.viasat.wildblue.common.commondata.ValidationError;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.AddServiceItem;
import com.viasat.wildblue.facade.provisioning.data.CancelAddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.DisconnectAccount;
import com.viasat.wildblue.facade.provisioning.data.DisconnectServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.DisconnectServiceItem;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatus;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceAgreement;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceEquipment;
import com.viasat.wildblue.facade.provisioning.data.TransitionServiceItem;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateCancelAddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectAccountResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateDisconnectServiceItemResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateResumeAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateSuspendAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceAgreementResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceEquipmentResponse;
import com.viasat.wildblue.facade.provisioning.data.ValidateTransitionServiceItemResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;

@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ BusinessTransaction.class, CatalogService.class, SDPClient.class,
		ServiceLocationServiceClient.class, FetchProcessor.class, ContactServiceClient.class })
@PowerMockIgnore(
{ "org.xml.*", "javax.xml.*", "org.apache.log4j.*", "com.sun.org.apache.xerces.*",
		"org.w3c.dom.*" })
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spring beans
public class TransactionValidationProcessorTest
{
	private static final WildBlueHeader WB_HDR;
	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("UnitTest");
		WB_HDR.getInvokedBy().setUsername(TransactionValidationProcessorTest.class.getSimpleName());
	}

	// spring beans
	@Resource(name = "btsClient")
	private BusinessTransactionClient btsClient;

	@Resource(name = "catalogClient")
	private CatalogServiceClient catalogClient;

	@Resource(name = "sdpProvisioningService")
	private ProvisioningService sdpProvisioningService;

	@Resource(name = "sdpClient")
	private SDPClient sdpClient;

	@Resource(name = "serviceLocationServiceClient")
	private ServiceLocationServiceClient svcLocClient;

	@Resource(name = "fetchProcessor")
	private FetchProcessor fetchProcessor;

	@Resource(name = "contactClient")
	private ContactServiceClient contactClient;

	// endpoint mocks
	private BusinessTransaction bts = mock(BusinessTransaction.class);
	private CatalogService catalog = mock(CatalogService.class);

	@Before
	public void prepMocks() throws Exception
	{
		reset(bts);
		reset(catalog);
		reset(sdpClient);
		reset(svcLocClient);
		reset(contactClient);

		// workaround for client wrapper
		when(btsClient.getEndpoint()).thenReturn(bts);
		when(catalogClient.getEndpoint()).thenReturn(catalog);
	}

	@Test
	public void validateAddCustomerHierarchy() throws Exception
	{
		// called x2: for internet-access and VoIP
		when(sdpClient.getLayer3Service(any()))
				.thenThrow(new SDPServiceFault("Entity not found", "2002"));

		when(svcLocClient.getServiceLocations(any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any()))
						.thenReturn(new ServiceLocations());

		// load request from xml
		AddCustomerHierarchy addCustomerHierarchy = JAXBUtility.unmarshalXML(
				getClass().getClassLoader()
						.getResourceAsStream("requests/AddCustomerHierarchy.xml"),
				AddCustomerHierarchy.class, JAXBUtility.FACADE_PROV_SDP_JBC);

		ValidateAddCustomerHierarchyResponse resp = sdpProvisioningService
				.validateAddCustomerHierarchy(addCustomerHierarchy, WB_HDR);

		Assert.assertNotNull(resp);
		assertNull(resp.getValidationResult());
	}

	@Test
	public void validateAddCustomerHierarchyNoHeader() throws Exception
	{
		// load request from xml
		AddCustomerHierarchy addCustomerHierarchy = JAXBUtility.unmarshalXML(
				getClass().getClassLoader()
						.getResourceAsStream("requests/AddCustomerHierarchy.xml"),
				AddCustomerHierarchy.class, JAXBUtility.FACADE_PROV_SDP_JBC);

		ValidateAddCustomerHierarchyResponse resp = sdpProvisioningService
				.validateAddCustomerHierarchy(addCustomerHierarchy, null);

		assertNotNull(resp);
		assertNotNull(resp.getValidationResult());
		assertNotNull(resp.getValidationResult().getValidationError());
		ValidationError ve = resp.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("invokedBy field is required.", ve.getMessage());
	}

	@Test
	public void validateCancelAddCustomerHierarchy() throws Exception
	{
		String externalAccountRef = "21826094";
		String externalSystemName = "WB_DIRECT";
		String serviceAgreementRef = "403585616";
		String transRef = "TRANSACTION_REF";
		String targetTransRef = "14991434";
		String reason = "notGiven";
		Date startDate = new Date();

		when(bts.getSoaTransactionByInternalReference(any(), any())).then(
				IWSBusinessTransaction.getSoaTransactionByInternalReference(targetTransRef, true));

		when(bts.getAccountHierarchyByExternalReference(any(), any())).then(
				IWSBusinessTransaction.getAccountHierarchyByExternalReference(externalAccountRef,
						externalSystemName, true));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(null, true));

		Layer3Service service = new Layer3Service();
		service.setState(Layer3ServiceState.PENDING);
		when(sdpClient.getLayer3Service(any())).thenReturn(service);

		FixedNTD device = new FixedNTD();
		device.setState(FixedNtdState.PENDING);
		when(sdpClient.getFixedNTD(any())).thenReturn(device);

		when(svcLocClient.getServiceLocations(any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocations(serviceAgreementRef, null, true));

		CancelAddCustomerHierarchy request = new CancelAddCustomerHierarchy();
		request.setTransactionReference(transRef);
		request.setTargetTransactionReference(targetTransRef);
		request.setReason(reason);
		request.setStartDate(startDate);

		ValidateCancelAddCustomerHierarchyResponse response = sdpProvisioningService
				.validateCancelAddCustomerHierarchy(request, WB_HDR);

		Assert.assertNotNull(response);
		assertNull(response.getValidationResult());
	}

	@Test
	public void validateTransitionServiceItem() throws Exception
	{
		String serviceAgreementRef = "403585616";
		String sdpServiceCatalogId = "Liberty 10 - HF - WiFi";
		String sdpServiceCatalogIdSlow = "Exede Suspend";

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, true));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(null, true));

		Layer3Service service = new Layer3Service();
		Layer3ServiceConfig config = new Layer3ServiceConfig();
		service.setConfiguration(config);
		config.setServiceCatalogId(sdpServiceCatalogId);
		when(sdpClient.getLayer3Service(any())).thenReturn(service);

		// load request from xml
		TransitionServiceItem request = JAXBUtility.unmarshalXML(
				getClass().getClassLoader()
						.getResourceAsStream("requests/TransitionServiceItem.xml"),
				TransitionServiceItem.class, JAXBUtility.FACADE_PROV_SDP_JBC);

		// happy path test
		ValidateTransitionServiceItemResponse resp = sdpProvisioningService
				.validateTransitionServiceItem(request, WB_HDR);

		assertNotNull(resp);
		assertNull(resp.getValidationResult());

		// test suspended in SDP
		config.setServiceCatalogId(sdpServiceCatalogIdSlow);
		resp = sdpProvisioningService.validateTransitionServiceItem(request, WB_HDR);

		assertNotNull(resp);
		assertNotNull(resp.getValidationResult());
		assertNotNull(resp.getValidationResult().getValidationError());
		ValidationError ve = resp.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("Service is currently suspended in SDP", ve.getMessage());
	}

	@Test
	public void validateTransitionServiceEquipment() throws WebServiceException, JAXBException,
			WebServiceFault, SDPServiceFault, XMLStreamException
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(param, wildBlueHeader);

		TransitionServiceEquipment parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateTransitionServiceEquipment.xml"),
				TransitionServiceEquipment.class);

		ValidateTransitionServiceEquipmentResponse response = sdpProvisioningService
				.validateTransitionServiceEquipment(parameter, WB_HDR);

		assertNotNull(response);
		assertNotNull(response.getValidationResult());
		assertNotNull(response.getValidationResult().getValidationError());
		ValidationError ve = response.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("FixedNTD Not Found", ve.getMessage());

	}

	@Test
	public void validateAddServiceItem() throws Exception
	{
		String serviceAgreementRef = "400366791";
		String salesChannelType = "Retail";
		String mcr = "210401";
		String serviceId = "802066855";

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));
		AddServiceItem parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateAddServiceItem.xml"),
				AddServiceItem.class);
		ValidateAddServiceItemResponse response = sdpProvisioningService
				.validateAddServiceItem(parameter, WB_HDR);

		assertNotNull(response);
	}

	@Test
	public void validateDisconnectAccount() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault
	{
		String accountRef = "300366283";
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		Layer3Service layer3Service = new Layer3Service();
		layer3Service.setState(Layer3ServiceState.PENDING);

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		// when(fetchProcessor.getLayer3ServiceForInternet(any())).thenReturn(layer3Service);

		DisconnectAccount parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateDisconnectAccount.xml"),
				DisconnectAccount.class);
		ValidateDisconnectAccountResponse response = sdpProvisioningService
				.validateDisconnectAccount(parameter, WB_HDR);
		assertNotNull(response);

	}

	@Test
	public void validateDisconnectServiceAgreement() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		DisconnectServiceAgreement parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateDisconnectServiceAgreement.xml"),
				DisconnectServiceAgreement.class);

		ValidateDisconnectServiceAgreementResponse response = sdpProvisioningService
				.validateDisconnectServiceAgreement(parameter, WB_HDR);

		assertNotNull(response);
		assertNotNull(response.getValidationResult());
		assertNotNull(response.getValidationResult().getValidationError());
		ValidationError ve = response.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("Internet Access Layer3Service Not Active", ve.getMessage());
	}

	@Test
	public void validateSuspendAllServiceAgreements() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault
	{

		String accountRef = "300366283";
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		FetchProcessorTest fetchProcessorTest = new FetchProcessorTest();

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(param, WB_HDR);

		SuspendAllServiceAgreements parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateSuspendAllServiceAgreements.xml"),
				SuspendAllServiceAgreements.class);

		ValidateSuspendAllServiceAgreementsResponse response = sdpProvisioningService
				.validateSuspendAllServiceAgreements(parameter, WB_HDR);

		assertNotNull(response);

		assertNotNull(response.getValidationResult());
		assertNotNull(response.getValidationResult().getValidationError());
		ValidationError ve = response.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("Internet Access Layer3Service Not Active", ve.getMessage());

	}

	@Test
	public void validateDisconnectServiceItem() throws JAXBException, XMLStreamException,
			WebServiceException, WebServiceFault, SDPServiceFault
	{
		String serviceItemRef = "818298264";
		String mcr = "270608";
		String serviceId = "818298264";

		when(bts.getCustomerHierarchyByInternalServiceItemReference(any(), any()))
				.then(IWSBusinessTransaction
						.getCustomerHierarchyByInternalServiceItemReference(serviceItemRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		DisconnectServiceItem parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateDisconnectServiceItem.xml"),
				DisconnectServiceItem.class);

		ValidateDisconnectServiceItemResponse response = sdpProvisioningService
				.validateDisconnectServiceItem(parameter, WB_HDR);

		assertNotNull(response);

		assertNotNull(response.getValidationResult());
		assertNotNull(response.getValidationResult().getValidationError());
		ValidationError ve = response.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("Active Voip Layer3Service Not Found", ve.getMessage());

	}

	@Test
	public void validateTransitionServiceAgreement()
			throws WebServiceException, WebServiceFault, JAXBException, XMLStreamException,
			SDPServiceFault, InternalServiceFault, InternalServiceFault
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String accountRef = "300366283";
		String serviceId = "802066855";

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, false));

		TransitionServiceAgreement parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateTransitionServiceAgreement.xml"),
				TransitionServiceAgreement.class);

		ValidateTransitionServiceAgreementResponse validateTransitionServiceAgreementResponse = sdpProvisioningService
				.validateTransitionServiceAgreement(parameter, WB_HDR);

		assertNotNull(validateTransitionServiceAgreementResponse);

		assertNotNull(validateTransitionServiceAgreementResponse.getValidationResult());
		assertNotNull(validateTransitionServiceAgreementResponse.getValidationResult()
				.getValidationError());
		ValidationError ve = validateTransitionServiceAgreementResponse.getValidationResult()
				.getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("ServiceAgreement Contact Already Exists", ve.getMessage());
	}

	@Test
	public void validateResumeAllServiceAgreements() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault
	{

		String accountRef = "300366283";
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		FetchProcessorTest fetchProcessorTest = new FetchProcessorTest();

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(param, WB_HDR);

		ResumeAllServiceAgreements parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateResumeAllServiceAgreements.xml"),
				ResumeAllServiceAgreements.class);

		ValidateResumeAllServiceAgreementsResponse response = sdpProvisioningService
				.validateResumeAllServiceAgreements(parameter, WB_HDR);

		assertNotNull(response);

		assertNotNull(response.getValidationResult());
		assertNotNull(response.getValidationResult().getValidationError());
		ValidationError ve = response.getValidationResult().getValidationError().get(0);
		assertNotNull(ve);
		assertEquals("VALIDATION_ERROR", ve.getErrorCode());
		assertEquals("Suspended Internet Access Layer3Service Not Found", ve.getMessage());

	}

}