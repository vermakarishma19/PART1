package com.viasat.facade.provisioning.sdp.util.servicemocks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.math.BigDecimal;

import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.internalservice.servicelocation.api.model.InstallationAttribute;
import com.viasat.internalservice.servicelocation.api.model.LegacyAttribute;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocationAggregate;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocationAggregates;
import com.viasat.internalservice.servicelocation.api.model.ServiceLocations;

public class ISServiceLocation
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ISServiceLocation.class);

	private static final String JSON_ROOT_DIR = "src/test/resources/responses/location/";

	public static Answer<ServiceLocationAggregate> createServiceLocationAggregate()
	{
		return invocation -> {
			ServiceLocationAggregate sla = invocation.getArgumentAt(0,
					ServiceLocationAggregate.class);
			String user = invocation.getArgumentAt(1, String.class);
			String application = invocation.getArgumentAt(2, String.class);

			LOGGER.debug("createServiceLocationAggregate:\n" + JAXBUtility.marshalJSON(sla, false));

			assertNotNull(sla.getServiceAgreementId());
			assertNotNull(sla.getAddressLine1());
			assertNotNull(sla.getMunicipality());
			assertNotNull(sla.getRegion());
			assertNotNull(sla.getPostalCode());
			assertNotNull(sla.getCountryCode());
			assertNotNull(sla.getRequestedLatitude());
			assertNotNull(sla.getRequestedLongitude());
			assertNotNull(sla.getActualLatitude());
			assertNotNull(sla.getActualLongitude());

			assertNotNull(sla.getInstallationAttributes());
			InstallationAttribute ia = sla.getInstallationAttributes().get(0);
			assertNotNull(ia);
			assertNotNull(ia.getAntennaPointingAid());
			assertNotNull(ia.getAzimuth());
			assertNotNull(ia.getBeamNumber());
			assertNotNull(ia.getBoomArmAngle());
			assertNotNull(ia.getElevation());
			assertNotNull(ia.getSatelliteName());
			assertNotNull(ia.getSkew());
			assertNotNull(ia.getPolarization());
			assertNotNull(ia.getCustomerCode());

			assertNotNull(sla.getLegacyAttributes());
			LegacyAttribute la = sla.getLegacyAttributes().get(0);
			assertNotNull(la);
			assertNotNull(la.getGatewayNumber());
			assertNotNull(la.getGatewayName());
			assertNotNull(la.getIspUsername());
			assertNotNull(la.getIspPassword());

			assertNotNull(user);
			assertNotNull(application);

			// echo request
			return sla;
		};
	}

	public static Answer<ServiceLocations> getServiceLocations(String serviceAgreementRef,
			String customerCode, boolean defaultResponse)
	{
		return invocation -> {
			// value could be "null"
			String serviceAgreementId = String
					.valueOf(invocation.getArgumentAt(0, BigDecimal.class));
			String custCode = invocation.getArgumentAt(9, String.class);
			String user = invocation.getArgumentAt(14, String.class);
			String application = invocation.getArgumentAt(15, String.class);

			LOGGER.debug("getServiceLocations:\nserviceAgreementRef: " + serviceAgreementId
					+ "\ncustomerCode: " + custCode);

			assertTrue(serviceAgreementId != null || custCode != null);
			assertNotNull(user);
			assertNotNull(application);

			String file = null;
			if (serviceAgreementRef != null)
			{
				assertEquals(serviceAgreementRef, serviceAgreementId);
				file = JSON_ROOT_DIR + "ServiceLocations-" + serviceAgreementRef + ".json";
			}
			else if (customerCode != null)
			{
				assertEquals(customerCode, custCode);
				file = JSON_ROOT_DIR + "ServiceLocations-" + customerCode + ".json";
			}

			if (defaultResponse)
				file = JSON_ROOT_DIR + "ServiceLocations-DEFAULT.json";

			return JAXBUtility.unmarshalJSON(new FileInputStream(file), ServiceLocations.class);
		};
	}

	public static Answer<ServiceLocationAggregates> getServiceLocationAggregates(
			String serviceAgreementRef, boolean defaultResponse)
	{
		return invocation -> {
			String serviceAgreementId = String
					.valueOf(invocation.getArgumentAt(0, BigDecimal.class));
			String user = invocation.getArgumentAt(15, String.class);
			String application = invocation.getArgumentAt(16, String.class);

			LOGGER.debug(
					"getServiceLocationAggregates:\nserviceAgreementRef: " + serviceAgreementRef);

			assertEquals(serviceAgreementRef, serviceAgreementId);
			assertNotNull(user);
			assertNotNull(application);

			String file;
			if (!defaultResponse)
				file = JSON_ROOT_DIR + "ServiceLocationAggregates-" + serviceAgreementRef + ".json";
			else
				file = JSON_ROOT_DIR + "ServiceLocationAggregates-DEFAULT.json";

			return JAXBUtility.unmarshalJSON(new FileInputStream(file),
					ServiceLocationAggregates.class);
		};
	}

	public static Answer<Void> deleteServiceLocationAggregate()
	{
		return invocation -> {
			String serviceLocationId = String
					.valueOf(invocation.getArgumentAt(0, BigDecimal.class));
			String user = invocation.getArgumentAt(1, String.class);
			String application = invocation.getArgumentAt(2, String.class);

			LOGGER.debug(
					"deleteServiceLocationAggregate:\nserviceLocationId: " + serviceLocationId);

			assertNotNull(serviceLocationId);
			assertNotNull(user);
			assertNotNull(application);

			return null;
		};
	}
}
