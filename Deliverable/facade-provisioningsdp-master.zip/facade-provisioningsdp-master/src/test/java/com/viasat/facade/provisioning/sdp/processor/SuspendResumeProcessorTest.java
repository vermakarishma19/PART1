package com.viasat.facade.provisioning.sdp.processor;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.common.fault.WebServiceFault;
import com.viasat.facade.catalog.CatalogService;
import com.viasat.facade.catalog.client.CatalogServiceClient;
import com.viasat.facade.isp.client.IspServiceClient;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.ServiceProviderFinder;
import com.viasat.facade.provisioning.sdp.util.servicemocks.FCDCatalog;
import com.viasat.facade.provisioning.sdp.util.servicemocks.IWSBusinessTransaction;
import com.viasat.facade.provisioning.sdp.util.servicemocks.LibSDPAPI;
import com.viasat.sdp.client.SDPClient;
import com.viasat.sdp.client.SDPServiceFault;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.GetServiceProvisioningStatus;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.ResumeAllServiceAgreementsResponse;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreements;
import com.viasat.wildblue.facade.provisioning.data.SuspendAllServiceAgreementsResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;
import com.viasat.wildblue.internalwebservice.referencedata.ReferenceDataServiceInterface;

// PowerMock for Mockito
@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ BusinessTransaction.class, ReferenceDataServiceInterface.class, SDPClient.class,
		CatalogService.class, ServiceProviderFinder.class, IspServiceClient.class,
		FetchProcessor.class })
// spring context
@PowerMockIgnore(
{ "org.xml.*", "javax.xml.*", "org.apache.log4j.*", "com.sun.org.apache.xerces.*",
		"org.w3c.dom.*" })
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spring beans
public class SuspendResumeProcessorTest
{
	private static final WildBlueHeader WB_HDR;

	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("UnitTest");
		WB_HDR.getInvokedBy().setUsername(CreationProcessorTest.class.getSimpleName());
	}

	// spring beans
	@Resource(name = "sdpProvisioningService")
	private ProvisioningService sdpProvisioningService;

	@Resource(name = "btsClient")
	private BusinessTransactionClient btsClient;

	@Resource(name = "sdpClient")
	private SDPClient sdpClient;

	@Resource(name = "catalogClient")
	private CatalogServiceClient catalogClient;

	@Resource(name = "ispServiceClient")
	private IspServiceClient ispServiceClient;

	@Resource(name = "fetchProcessor")
	private FetchProcessor fetchProcessor;

	@Resource(name = "validationProcessor")
	private ValidationProcessor validationProcessor;

	// endpoint mocks
	private BusinessTransaction bts = mock(BusinessTransaction.class);
	private CatalogService catalog = mock(CatalogService.class);

	@Before
	public void prepMocks() throws Exception
	{
		reset(btsClient);
		reset(sdpClient);
		reset(catalog);
		reset(ispServiceClient);

		// workaround for client wrapper
		when(btsClient.getEndpoint()).thenReturn(bts);
		when(catalogClient.getEndpoint()).thenReturn(catalog);

	}

	@Test
	public void resumeAllServiceAgreements() throws WebServiceException, WebServiceFault,
			JAXBException, XMLStreamException, SDPServiceFault
	{
		String accountRef = "303267703";
		String transactionType = "resumeAllServiceAgreements";
		String businessTransactionReference = "31105943";
		String Mcr = "701453";
		String serviceId = "818297941";
		String serviceAgreementRef = "403587936";

		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(Mcr, false));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass()
						.getResourceAsStream("/requests/GetServiceProvisioningStatusForResume.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(parameter, wildBlueHeader);

		ResumeAllServiceAgreements resumeAllServiceAgreements = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getClassLoader()
						.getResourceAsStream("requests/ResumeAllServiceAgreements.xml"),
				ResumeAllServiceAgreements.class);

		ResumeAllServiceAgreementsResponse response = sdpProvisioningService
				.resumeAllServiceAgreements(resumeAllServiceAgreements, wildBlueHeader);

		Assert.assertNotNull(response);

	}

	@Test
	public void suspendAllServiceAgreements() throws WebServiceException, WebServiceFault,
			SDPServiceFault, JAXBException, XMLStreamException
	{
		String accountRef = "300366283";
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		String transactionType = "suspendAllServiceAgreements";
		String businessTransactionReference = "31105950";
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(parameter, wildBlueHeader);

		SuspendAllServiceAgreements suspendAllServiceAgreements = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getClassLoader()
						.getResourceAsStream("requests/SuspendAllServiceAgreements.xml"),
				SuspendAllServiceAgreements.class);

		SuspendAllServiceAgreementsResponse response = sdpProvisioningService
				.suspendAllServiceAgreements(suspendAllServiceAgreements, wildBlueHeader);

		Assert.assertNotNull(response);

	}
}