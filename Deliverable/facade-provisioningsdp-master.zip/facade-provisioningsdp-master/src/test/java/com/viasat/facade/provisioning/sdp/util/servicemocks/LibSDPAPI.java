package com.viasat.facade.provisioning.sdp.util.servicemocks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.FileInputStream;

import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.sdp.api.data.CommandState;
import com.viasat.sdp.api.data.FixedNTD;
import com.viasat.sdp.api.data.Layer3Service;
import com.viasat.sdp.api.data.NewConfigureFixedNTDInput;
import com.viasat.sdp.api.data.NewConfigureLayer3ServiceInput;
import com.viasat.sdp.api.data.ServiceArea;
import com.viasat.sdp.client.util.SDPXMLHelper;

public class LibSDPAPI
{
	private static final Logger LOGGER = LoggerFactory.getLogger(LibSDPAPI.class);

	private static final String XML_ROOT_DIR = "src/test/resources/responses/sdp/";

	public static Answer<FixedNTD> configureFixedNTD(String serviceAgreementRef,
			boolean defaultResponse)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);
			String mac = invocation.getArgumentAt(1, String.class);
			NewConfigureFixedNTDInput input = invocation.getArgumentAt(2,
					NewConfigureFixedNTDInput.class);

			LOGGER.debug("configureFixedNTD:\nid: " + id + "\nmac: " + mac + "\n"
					+ SDPXMLHelper.objectToString(input));

			assertEquals(serviceAgreementRef, id);
			assertNull(mac);
			assertNotNull(input);
			assertNotNull(input.getCsaId());
			assertNotNull(input.getLatitude());
			assertNotNull(input.getLongitude());
			assertNotNull(input.getSatelliteId());

			String file;
			if (!defaultResponse)
				file = XML_ROOT_DIR + "ConfigureFixedNTD-" + serviceAgreementRef + ".xml";
			else
				file = XML_ROOT_DIR + "ConfigureFixedNTD-DEFAULT.xml";

			if (file != null)
				return JAXBUtility.unmarshalSDPMessageEnvelope(new FileInputStream(file),
						FixedNTD.class);

			return null;
		};
	}

	public static Answer<Layer3Service> configureLayer3Service(String serviceAgreementRef,
			String serviceItemRef, boolean defaultResponse)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);
			NewConfigureLayer3ServiceInput input = invocation.getArgumentAt(1,
					NewConfigureLayer3ServiceInput.class);

			LOGGER.debug("configureLayer3Service:\nid: " + id + "\n"
					+ SDPXMLHelper.objectToString(input));

			assertEquals(serviceItemRef, id);
			assertNotNull(input);
			assertEquals(serviceAgreementRef, input.getNtdId());
			assertNotNull(input.getServiceCatalogId());

			String file;
			if (!defaultResponse)
				file = XML_ROOT_DIR + "ConfigureLayer3Service-" + serviceItemRef + ".xml";
			else
				file = XML_ROOT_DIR + "ConfigureLayer3Service-DEFAULT.xml";

			if (file != null)
				return JAXBUtility.unmarshalSDPMessageEnvelope(new FileInputStream(file),
						Layer3Service.class);

			return null;
		};
	}

	public static Answer<CommandState> deactivateLayer3Service(String serviceItemRef)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);

			LOGGER.debug("deactivateLayer3Service:\nid: " + id);

			assertEquals(serviceItemRef, id);

			return CommandState.SUCCEEDED;
		};
	}

	public static Answer<CommandState> deleteLayer3Service(String serviceItemRef)
	{
		return invocation -> {
			String serviceId = invocation.getArgumentAt(0, String.class);

			LOGGER.debug("deleteLayer3Service:\nserviceId: " + serviceId);

			assertEquals(serviceItemRef, serviceId);

			return CommandState.SUCCEEDED;
		};
	}

	public static Answer<CommandState> deleteFixedNTD(String serviceAgreementRef)
	{
		return invocation -> {
			String deviceId = invocation.getArgumentAt(0, String.class);

			LOGGER.debug("deleteFixedNTD:\ndeviceId: " + deviceId);

			assertEquals(serviceAgreementRef, deviceId);

			return CommandState.SUCCEEDED;
		};
	}

	public static Answer<FixedNTD> getFixedNTD(String serviceAgreementRef)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);

			assertEquals(serviceAgreementRef, id);

			String file;
			file = XML_ROOT_DIR + "GetFixedNTD-" + serviceAgreementRef + ".xml";

			if (file != null)
				return JAXBUtility.unmarshalSDPMessageEnvelope(new FileInputStream(file),
						FixedNTD.class);

			return null;
		};
	}

	public static Answer<ServiceArea> getServiceArea(String serviceAreaId)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);

			assertEquals(serviceAreaId, id);

			String file;
			file = XML_ROOT_DIR + "GetServiceArea-" + serviceAreaId + ".xml";

			if (file != null)
				return JAXBUtility.unmarshalSDPMessageEnvelope(new FileInputStream(file),
						ServiceArea.class);

			return null;
		};
	}

	public static Answer<Layer3Service> getLayer3Service(String serviceId)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);

			assertEquals(serviceId, id);

			String file;
			file = XML_ROOT_DIR + "GetLayer3Service-" + serviceId + ".xml";

			if (file != null)
				return JAXBUtility.unmarshalSDPMessageEnvelope(new FileInputStream(file),
						Layer3Service.class);

			return null;
		};
	}

	public static Answer<CommandState> activateLayer3Service(String serviceItemRef)
	{
		return invocation -> {
			String id = invocation.getArgumentAt(0, String.class);

			LOGGER.debug("activateLayer3Service:\nid: " + id);

			assertEquals(serviceItemRef, id);

			return CommandState.SUCCEEDED;
		};
	}
}
