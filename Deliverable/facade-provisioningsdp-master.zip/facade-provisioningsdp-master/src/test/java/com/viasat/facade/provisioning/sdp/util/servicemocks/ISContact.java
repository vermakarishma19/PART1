package com.viasat.facade.provisioning.sdp.util.servicemocks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.FileInputStream;
import java.math.BigDecimal;

import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.internalservice.contact.api.model.ContactAggregate;
import com.viasat.internalservice.contact.api.model.ContactAggregates;
import com.viasat.internalservice.contact.api.model.ContactRole;
import com.viasat.internalservice.contact.api.model.Contacts;
import com.viasat.internalservice.contact.api.model.PostalAddressAggregate;

public class ISContact
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ISContact.class);

	private static final String JSON_ROOT_DIR = "src/test/resources/responses/contact/";

	public static Answer<ContactAggregate> createContactAggregate(String accountRef,
			String serviceAgreementRef, boolean defaultResponse)
	{
		return invocation -> {
			ContactAggregate ca = invocation.getArgumentAt(0, ContactAggregate.class);
			String user = invocation.getArgumentAt(1, String.class);
			String application = invocation.getArgumentAt(2, String.class);

			LOGGER.debug("createContactAggregate:\n" + JAXBUtility.marshalJSON(ca, false));

			assertNotNull(ca.getFirstName());
			assertNotNull(ca.getLastName());

			assertNotNull(ca.getContactRoles());
			ContactRole cr = ca.getContactRoles().get(0);
			assertNotNull(cr);
			assertNotNull(cr.getContactRoleType());
			assertNotNull(cr.getContactRoleType().get(0));
			assertNotNull(cr.getContactRoleType().get(0).getContactRoleType());

			assertNotNull(ca.getEmailAddresses().get(0));
			assertNotNull(ca.getEmailAddresses().get(0).getEmailAddress());

			assertNotNull(ca.getPhoneNumbers().get(0));
			assertNotNull(ca.getPhoneNumbers().get(0).getPrimaryPhoneNumber());

			assertNotNull(ca.getPostalAddresses());
			PostalAddressAggregate paa = ca.getPostalAddresses().get(0);
			assertNotNull(paa);
			assertNotNull(paa.getAddressLine1());
			assertNotNull(paa.getMunicipality());
			assertNotNull(paa.getRegion());
			assertNotNull(paa.getCountryCode());

			assertNotNull(user);
			assertNotNull(application);

			String contactRole = cr.getContactRoleType().get(0).getContactRoleType();

			String file = null;
			if ("SERVICE_AGREEMENT_CONTACT".equals(contactRole))
			{
				assertNull(cr.getAccountId());
				assertNotNull(cr.getServiceAgreementId());
				assertEquals(new BigDecimal(serviceAgreementRef), cr.getServiceAgreementId());

				file = JSON_ROOT_DIR + "ContactAggregates-SvcAgrmt-" + serviceAgreementRef
						+ ".json";
			}

			if ("ACCOUNT_CONTACT".equals(contactRole))
			{
				assertNull(cr.getServiceAgreementId());
				assertNotNull(cr.getAccountId());
				assertEquals(new BigDecimal(accountRef), cr.getAccountId());

				file = JSON_ROOT_DIR + "ContactAggregates-Acct-" + accountRef + ".json";
			}

			if ("CUSTOMER_CONTACT".equals(contactRole))
			{
				assertNull(cr.getServiceAgreementId());
				assertNotNull(cr.getAccountId());
				assertEquals(new BigDecimal(accountRef), cr.getAccountId());

				file = JSON_ROOT_DIR + "ContactAggregates-Cust-" + accountRef + ".json";
			}

			if (defaultResponse)
				file = JSON_ROOT_DIR + "ContactAggregates-SvcAgrmt-DEFAULT.json";

			return JAXBUtility.unmarshalJSON(new FileInputStream(file), ContactAggregates.class)
					.get(0);
		};
	}

	public static Answer<Void> deleteContactAggregate()
	{
		return invocation -> {
			String contactId = String.valueOf(invocation.getArgumentAt(0, BigDecimal.class));
			String user = invocation.getArgumentAt(1, String.class);
			String application = invocation.getArgumentAt(2, String.class);

			LOGGER.debug("deleteContactAggregate:\ncontactId: " + contactId);

			assertNotNull(contactId);

			assertNotNull(user);
			assertNotNull(application);

			return null;
		};
	}

	public static Answer<ContactAggregates> getContactAggregates(String accountRef,
			String serviceAgreementRef, boolean defaultResponse)
	{
		return invocation -> {
			// value could be "null"
			String accountId = String.valueOf(invocation.getArgumentAt(0, BigDecimal.class));
			String svcAgreementId = String.valueOf(invocation.getArgumentAt(1, BigDecimal.class));
			String contactRoleType = invocation.getArgumentAt(7, String.class);
			String user = invocation.getArgumentAt(12, String.class);
			String application = invocation.getArgumentAt(13, String.class);

			LOGGER.debug("getContactAggregate:\naccountId: " + accountId + "\nserviceAgreementId: "
					+ svcAgreementId + "\ncontactRoleType: " + contactRoleType);

			assertNotNull(contactRoleType);

			assertNotNull(user);
			assertNotNull(application);

			String file = null;

			if ("SERVICE_AGREEMENT_CONTACT".equals(contactRoleType))
			{
				assertEquals(serviceAgreementRef, svcAgreementId);

				file = JSON_ROOT_DIR + "ContactAggregates-SvcAgrmt-" + svcAgreementId + ".json";
			}
			else if ("ACCOUNT_CONTACT".equals(contactRoleType))
			{
				assertEquals(accountRef, accountId);

				file = JSON_ROOT_DIR + "ContactAggregates-Acct-" + accountId + ".json";
			}
			else if ("CUSTOMER_CONTACT".equals(contactRoleType))
			{
				assertEquals(accountRef, accountId);

				file = JSON_ROOT_DIR + "ContactAggregates-Cust-" + accountId + ".json";
			}

			// default override
			if (defaultResponse)
				file = JSON_ROOT_DIR + "ContactAggregates-Cust-DEFAULT.json";

			return JAXBUtility.unmarshalJSON(new FileInputStream(file), ContactAggregates.class);
		};
	}

	public static Answer<Contacts> getContacts(String accountRef, String serviceAgreementRef,
			boolean defaultResponse)
	{
		return invocation -> {
			// value could be "null"
			String accountId = String.valueOf(invocation.getArgumentAt(0, BigDecimal.class));
			String svcAgreementId = String.valueOf(invocation.getArgumentAt(1, BigDecimal.class));
			String contactRoleType = invocation.getArgumentAt(7, String.class);
			String user = invocation.getArgumentAt(12, String.class);
			String application = invocation.getArgumentAt(13, String.class);

			LOGGER.debug("getContacts:\naccountId: " + accountId + "\nserviceAgreementId:"
					+ svcAgreementId + "\ncontactRoleType: " + contactRoleType);

			assertNotNull(contactRoleType);

			assertNotNull(user);
			assertNotNull(application);

			// use default file if one is not provided
			String file = null;

			if ("SERVICE_AGREEMENT_CONTACT".equals(contactRoleType))
			{
				assertEquals(serviceAgreementRef, svcAgreementId);

				file = JSON_ROOT_DIR + "Contacts-SvcAgrmt-" + svcAgreementId + ".json";
			}
			else if ("ACCOUNT_CONTACT".equals(contactRoleType))
			{
				assertEquals(accountRef, accountId);

				file = JSON_ROOT_DIR + "Contacts-Acct-" + accountId + ".json";
			}
			else if ("CUSTOMER_CONTACT".equals(contactRoleType))
			{
				assertEquals(accountRef, accountId);

				file = JSON_ROOT_DIR + "Contacts-Cust-" + accountId + ".json";
			}

			// default override
			if (defaultResponse)
				file = JSON_ROOT_DIR + "Contacts-SvcAgrmt-DEFAULT.json";

			Contacts resp = JAXBUtility.unmarshalJSON(new FileInputStream(file), Contacts.class);
			// LOGGER.debug(JAXBUtility.marshalJSON(resp, false));
			return resp;
		};
	}
}
