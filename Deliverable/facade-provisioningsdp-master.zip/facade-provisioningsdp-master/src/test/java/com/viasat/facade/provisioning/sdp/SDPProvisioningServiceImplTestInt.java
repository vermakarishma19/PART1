package com.viasat.facade.provisioning.sdp;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.ValidateAddCustomerHierarchyResponse;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
public class SDPProvisioningServiceImplTestInt
{
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SDPProvisioningServiceImplTestInt.class);

	private static final String CONFIG_SVC_ENDPOINT = "configurationServiceEndpoint";
	private static final String CONFIG_SVC_URL = "http://iws-configuration.sandbox.dev.wdc1.wildblue.net/ConfigurationService/services/ConfigurationService";
	private static final WildBlueHeader WB_HDR;
	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("IntegrationTest");
		WB_HDR.getInvokedBy().setUsername(SDPProvisioningServiceImplTestInt.class.getSimpleName());
	}

	@Resource // from spring
	private SDPProvisioningServiceImpl sdpService;

	@BeforeClass
	public static void setUpConfig() throws Exception
	{
		LOGGER.info("setUpConfig()");

		if (System.getenv(CONFIG_SVC_ENDPOINT) == null)
			System.setProperty(CONFIG_SVC_ENDPOINT, CONFIG_SVC_URL);
		else
			System.setProperty(CONFIG_SVC_ENDPOINT, System.getenv(CONFIG_SVC_ENDPOINT));
	}
@Ignore
	@Test
	public void testValidateAddCustomerHierarchy()
	{
		AddCustomerHierarchy req = new AddCustomerHierarchy();
		// TODO populate test data

		try
		{
			ValidateAddCustomerHierarchyResponse resp = sdpService.validateAddCustomerHierarchy(req,
					WB_HDR);

			// TODO evaluate response
		}
		catch (WebServiceException e)
		{
			LOGGER.error(null, e);
			Assert.fail();
		}
	}
}