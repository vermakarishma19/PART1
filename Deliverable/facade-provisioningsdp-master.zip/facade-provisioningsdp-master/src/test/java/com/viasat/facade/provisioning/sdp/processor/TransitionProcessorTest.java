package com.viasat.facade.provisioning.sdp.processor;

import com.viasat.common.fault.WebServiceFault;
import com.viasat.facade.catalog.CatalogService;
import com.viasat.facade.catalog.client.CatalogServiceClient;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.servicemocks.*;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.sdp.client.SDPClient;
import com.viasat.sdp.client.SDPServiceFault;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.*;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ BusinessTransaction.class, CatalogService.class, SDPClient.class,
		ServiceLocationServiceClient.class })
@PowerMockIgnore(
{ "org.xml.*", "javax.xml.*", "org.apache.log4j.*", "com.sun.org.apache.xerces.*",
		"org.w3c.dom.*" })
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spr/**/ing beans
public class TransitionProcessorTest
{
	private static final WildBlueHeader WB_HDR;

	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("UnitTest");
		WB_HDR.getInvokedBy().setUsername(TransactionValidationProcessorTest.class.getSimpleName());
	}

	// spring beans
	@Resource(name = "btsClient")
	private BusinessTransactionClient btsClient;

	@Resource(name = "catalogClient")
	private CatalogServiceClient catalogClient;

	@Resource(name = "sdpProvisioningService")
	private ProvisioningService sdpProvisioningService;

	@Resource(name = "sdpClient")
	private SDPClient sdpClient;

	@Resource(name = "contactClient")
	private ContactServiceClient contactClient;

	@Resource(name = "serviceLocationServiceClient")
	private ServiceLocationServiceClient svcLocClient;

	@Resource(name = "transactionValidationProcessor")
	private TransactionValidationProcessor transactionValidationProcessor;

	// endpoint mocks
	private BusinessTransaction bts = mock(BusinessTransaction.class);
	private CatalogService catalog = mock(CatalogService.class);

	@Before
	public void prepMocks() throws Exception
	{
		reset(bts);
		reset(catalog);
		reset(sdpClient);
		reset(svcLocClient);
		reset(contactClient);

		// workaround for client wrapper
		when(btsClient.getEndpoint()).thenReturn(bts);
		when(catalogClient.getEndpoint()).thenReturn(catalog);
	}

	@Test
	public void testTransitionServiceItem() throws Exception
	{
		String serviceAgreementRef = "403585616";
		String oldServiceItem = "818290527";
		String newServiceItem = "818292488";

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		// called x2: once for WORKING, and once for COMPLETE
		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(sdpClient.deactivateLayer3Service(any()))
				.then(LibSDPAPI.deactivateLayer3Service(oldServiceItem));

		when(sdpClient.deleteLayer3Service(any()))
				.then(LibSDPAPI.deleteLayer3Service(oldServiceItem));

		when(sdpClient.configureLayer3Service(any(), any()))
				.then(LibSDPAPI.configureLayer3Service(serviceAgreementRef, newServiceItem, true));

		// load request from xml
		TransitionServiceItem request = JAXBUtility.unmarshalXML(
				getClass().getClassLoader()
						.getResourceAsStream("requests/TransitionServiceItem.xml"),
				TransitionServiceItem.class, JAXBUtility.FACADE_PROV_SDP_JBC);

		// happy path test
		TransitionServiceItemResponse resp = sdpProvisioningService.transitionServiceItem(request,
				WB_HDR);

		assertNotNull(resp);
	}

	@Test
	public void testTransitionServiceEqiupment() throws WebServiceException, WebServiceFault,
			SDPServiceFault, JAXBException, XMLStreamException
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		String accountRef = "300366283";
		String businessTransactionReference = "31105140";
		String transactionType = "transitionServiceEquipment";
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.getServiceAgreementByInternalReference(any(), any())).then(
				IWSBusinessTransaction.getServiceAgreementByInternalReference(serviceAgreementRef));

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		GetServiceProvisioningStatus param = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/GetServiceProvisioningStatus.xml"),
				GetServiceProvisioningStatus.class);

		sdpProvisioningService.getServiceProvisioningStatus(param, wildBlueHeader);

		TransitionServiceEquipment parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/ValidateTransitionServiceEquipment.xml"),
				TransitionServiceEquipment.class);
		transactionValidationProcessor.validateTransitionServiceEquipment(parameter, WB_HDR);

		TransitionServiceEquipment request = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/TransitionServiceEquipment.xml"),
				TransitionServiceEquipment.class);

		TransitionServiceEquipmentResponse response = sdpProvisioningService
				.transitionServiceEquipment(request, WB_HDR);

	}

	@Test
	public void transitionServiceAgreement()
			throws WebServiceException, JAXBException, XMLStreamException, WebServiceFault,
			SDPServiceFault, InternalServiceFault, InternalServiceFault
	{
		String transactionType = "transitionServiceAgreement";
		String serviceAgreementRef = "403588416";
		String mcr = "701453";
		String accountRef = "303268123";
		String serviceId = "818298801";

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		// called x2: once for WORKING, and once for COMPLETE
		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, false));

		when(contactClient.createContactAggregate(any(), any(), any()))
				.then(ISContact.createContactAggregate(accountRef, serviceAgreementRef, true));

		when(svcLocClient.createServiceLocationAggregate(any(), any(), any()))
				.then(ISServiceLocation.createServiceLocationAggregate());

		TransitionServiceAgreement parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream(
						"/requests/ValidateTransitionServiceAgreementFortransition.xml"),
				TransitionServiceAgreement.class);

		sdpProvisioningService.validateTransitionServiceAgreement(parameter, WB_HDR);

		TransitionServiceAgreement request = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/TransitionServiceAgreement.xml"),
				TransitionServiceAgreement.class);

		TransitionServiceAgreementResponse response = sdpProvisioningService
				.transitionServiceAgreement(request, WB_HDR);
	}

	@Test
	public void transitionServiceEquipmentComplete() throws WebServiceException, JAXBException,
			XMLStreamException, WebServiceFault, SDPServiceFault
	{
		String serviceAgreementRef = "403588642";
		String oldServiceItemReference = "818299509";

		String transactionType = "transitionServiceEquipmentComplete";

		String mcr = "701453";

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		// called x2: once for WORKING, and once for COMPLETE
		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(bts.getServiceAgreementHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction
						.getServiceAgreementHierarchyByInternalReference(serviceAgreementRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.deactivateLayer3Service(any()))
				.then(LibSDPAPI.deactivateLayer3Service(oldServiceItemReference));

		when(sdpClient.deleteLayer3Service(any()))
				.then(LibSDPAPI.deleteLayer3Service(oldServiceItemReference));

		TransitionServiceEquipmentComplete request = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/TransitionServiceEquipmentComplete.xml"),
				TransitionServiceEquipmentComplete.class);

		TransitionServiceEquipmentCompleteResponse response = sdpProvisioningService
				.transitionServiceEquipmentComplete(request, WB_HDR);
	}

}