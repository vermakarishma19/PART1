package com.viasat.facade.provisioning.sdp.processor;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISContact;
import com.viasat.facade.provisioning.sdp.util.servicemocks.ISServiceLocation;
import com.viasat.facade.provisioning.sdp.util.servicemocks.IWSBusinessTransaction;
import com.viasat.facade.provisioning.sdp.util.servicemocks.LibSDPAPI;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.sdp.client.SDPClient;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchyResponse;
import com.viasat.wildblue.facade.provisioning.data.AddServiceItem;
import com.viasat.wildblue.facade.provisioning.data.AddServiceItemResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;
import com.viasat.wildblue.internalwebservice.referencedata.ReferenceDataServiceInterface;

// PowerMock for Mockito
@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ BusinessTransaction.class, ReferenceDataServiceInterface.class, SDPClient.class,
		ServiceLocationServiceClient.class, ContactServiceClient.class })
// spring context
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spring beans
public class CreationProcessorTest
{
	private static final WildBlueHeader WB_HDR;
	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("UnitTest");
		WB_HDR.getInvokedBy().setUsername(CreationProcessorTest.class.getSimpleName());
	}

	// spring beans
	@Resource(name = "sdpProvisioningService")
	private ProvisioningService sdpProvisioningService;

	@Resource(name = "btsClient")
	private BusinessTransactionClient btsClient;

	@Resource(name = "sdpClient")
	private SDPClient sdpClient;

	@Resource(name = "serviceLocationServiceClient")
	private ServiceLocationServiceClient svcLocClient;

	@Resource(name = "contactClient")
	private ContactServiceClient contactClient;

	// endpoint mocks
	private BusinessTransaction bts = mock(BusinessTransaction.class);

	@Before
	public void prepMocks() throws Exception
	{
		reset(bts);
		reset(contactClient);
		reset(sdpClient);
		reset(svcLocClient);

		// workaround for client wrapper
		when(btsClient.getEndpoint()).thenReturn(bts);
	}

	@Test
	public void addCustomerHierarchy() throws Exception
	{
		String accountRef = "303265783";
		String serviceAgreementRef = "403585616";
		String netServiceItemRef = "818290527";

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		// called x2: once for WORKING, and once for COMPLETE
		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(sdpClient.configureFixedNTD(any(), any(), any()))
				.then(LibSDPAPI.configureFixedNTD(serviceAgreementRef, true));

		// can be called x2: once for VoIp, once for internet-access
		when(sdpClient.configureLayer3Service(any(), any())).then(
				LibSDPAPI.configureLayer3Service(serviceAgreementRef, netServiceItemRef, true));

		// called x3: for customer, account, and service agreement contacts
		when(contactClient.createContactAggregate(any(), any(), any()))
				.then(ISContact.createContactAggregate(accountRef, serviceAgreementRef, true));

		when(svcLocClient.createServiceLocationAggregate(any(), any(), any()))
				.then(ISServiceLocation.createServiceLocationAggregate());

		// load request from xml
		AddCustomerHierarchy addCustomerHierarchy = JAXBUtility.unmarshalXML(
				getClass().getClassLoader()
						.getResourceAsStream("requests/AddCustomerHierarchy.xml"),
				AddCustomerHierarchy.class, JAXBUtility.FACADE_PROV_SDP_JBC);

		// call service
		AddCustomerHierarchyResponse resp = sdpProvisioningService
				.addCustomerHierarchy(addCustomerHierarchy, WB_HDR);

		// exception is thrown on validation or processing fault
		assertNotNull(resp);
	}

	@Test
	public void addServiceItem() throws Exception
	{
		String serviceAgreementRef = "403585616";
		String netServiceItemRef = "818290527";

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, true));

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		// called x2: once for WORKING, and once for COMPLETE
		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(sdpClient.configureLayer3Service(any(), any())).then(
				LibSDPAPI.configureLayer3Service(serviceAgreementRef, netServiceItemRef, true));

		when(sdpClient.activateLayer3Service(any()))
				.then(LibSDPAPI.activateLayer3Service(serviceAgreementRef));

		// load request from xml
		AddServiceItem addServiceItem = JAXBUtility.unmarshalXML(
				getClass().getClassLoader().getResourceAsStream("requests/AddServiceItem.xml"),
				AddServiceItem.class, JAXBUtility.FACADE_PROV_SDP_JBC);

		// call service
		AddServiceItemResponse resp = sdpProvisioningService.addServiceItem(addServiceItem, WB_HDR);

		// exception is thrown on validation or processing fault
		assertNotNull(resp);

	}

}