package com.viasat.facade.provisioning.sdp;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.common.client.ProvisioningServiceClient;
import com.viasat.wildblue.facade.provisioning.data.AddCustomerHierarchy;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-clientContext.xml" })
public class SDPProvisioningServiceClientTestInt
{
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SDPProvisioningServiceClientTestInt.class);

	private static final WildBlueHeader WB_HDR;

	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("IntegrationTest");
		WB_HDR.getInvokedBy().setUsername(SDPProvisioningServiceClientTestInt.class.getSimpleName());
	}

	@Resource(name = "facadeProvisioningServiceClient") // from spring
	private ProvisioningServiceClient sdpService;

	@Test
	public void testValidateAddCustomerHierarchy()
	{
		AddCustomerHierarchy req = new AddCustomerHierarchy();
		try
		{
			sdpService.getEndpoint("junit", SDPProvisioningServiceClientTestInt.class.getSimpleName())
					.validateAddCustomerHierarchy(req, WB_HDR);
		}
		catch (WebServiceException e)
		{
			LOGGER.error(null, e);
			Assert.fail();
		}
	}
}