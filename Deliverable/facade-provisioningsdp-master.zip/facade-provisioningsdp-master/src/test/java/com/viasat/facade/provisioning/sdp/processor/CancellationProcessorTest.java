package com.viasat.facade.provisioning.sdp.processor;

import com.viasat.common.fault.WebServiceFault;
import com.viasat.facade.catalog.CatalogService;
import com.viasat.facade.catalog.client.CatalogServiceClient;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.servicemocks.*;
import com.viasat.internalservice.contact.client.ContactServiceClient;
import com.viasat.internalservice.fault.InternalServiceFault;
import com.viasat.internalservice.servicelocation.client.ServiceLocationServiceClient;
import com.viasat.sdp.client.SDPClient;
import com.viasat.sdp.client.SDPServiceFault;
import com.viasat.wildblue.common.exception.WebServiceException;
import com.viasat.wildblue.common.header.InvokedBy;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.ProvisioningService;
import com.viasat.wildblue.facade.provisioning.data.*;
import com.viasat.wildblue.internalwebservice.businesstransaction.BusinessTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.client.BusinessTransactionClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;
import java.util.Date;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ BusinessTransaction.class, CatalogService.class, SDPClient.class,
		ServiceLocationServiceClient.class })
@PowerMockIgnore(
{ "org.xml.*", "javax.xml.*", "org.apache.log4j.*", "com.sun.org.apache.xerces.*",
		"org.w3c.dom.*" })
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@SuppressWarnings("unused") // spring beans
public class CancellationProcessorTest
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CancellationProcessorTest.class);

	private static final WildBlueHeader WB_HDR;
	static
	{
		WB_HDR = new WildBlueHeader();
		WB_HDR.setInvokedBy(new InvokedBy());
		WB_HDR.getInvokedBy().setApplication("UnitTest");
		WB_HDR.getInvokedBy().setUsername(CancellationProcessorTest.class.getSimpleName());
	}

	// spring beans
	@Resource(name = "btsClient")
	private BusinessTransactionClient btsClient;

	@Resource(name = "catalogClient")
	private CatalogServiceClient catalogClient;

	@Resource(name = "contactClient")
	private ContactServiceClient contactClient;

	@Resource(name = "sdpProvisioningService")
	private ProvisioningService sdpProvisioningService;

	@Resource(name = "sdpClient")
	private SDPClient sdpClient;

	@Resource(name = "serviceLocationServiceClient")
	private ServiceLocationServiceClient svcLocClient;

	// endpoint mocks
	private BusinessTransaction bts = mock(BusinessTransaction.class);
	private CatalogService catalog = mock(CatalogService.class);

	@Before
	public void prepMocks() throws Exception
	{
		reset(bts);
		reset(catalog);
		reset(sdpClient);
		reset(svcLocClient);
		reset(contactClient);

		// workaround for client wrapper
		when(btsClient.getEndpoint()).thenReturn(bts);
		when(catalogClient.getEndpoint()).thenReturn(catalog);
	}

	@Test
	public void cancelAddCustomerHierarchy() throws Exception
	{
		String externalRef = "21826094";
		String externalSystemName = "WB_DIRECT";
		String accountRef = "303265783";
		String serviceAgreementRef = "403585616";
		String customerRef = "203358076";
		String internetSvcItemRef = "818290527";
		String voipSvcItemRef = "818290528";

		String transRef = "TRANSACTION_REF";
		String targetTransRef = "14991434";
		String reason = "notGiven";
		Date startDate = new Date();

		// bts mocks
		when(bts.getSoaTransactionByInternalReference(any(), any())).then(
				IWSBusinessTransaction.getSoaTransactionByInternalReference(targetTransRef, true));
		when(bts.getServiceAgreementByExternalReference(any(), any())).then(IWSBusinessTransaction
				.getServiceAgreementByExternalReference(externalRef, externalSystemName, true));
		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));
		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, true));
		when(bts.getAccountHierarchyByExternalReference(any(), any())).then(IWSBusinessTransaction
				.getAccountHierarchyByExternalReference(externalRef, externalSystemName, true));

		// catalog mock
		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(null, true));

		// sdp mocks
		when(sdpClient.deleteLayer3Service(eq(internetSvcItemRef)))
				.then(LibSDPAPI.deleteLayer3Service(internetSvcItemRef));
		when(sdpClient.deleteLayer3Service(eq(voipSvcItemRef)))
				.then(LibSDPAPI.deleteLayer3Service(voipSvcItemRef));
		when(sdpClient.deleteFixedNTD(any())).then(LibSDPAPI.deleteFixedNTD(serviceAgreementRef));

		// contact mock
		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));
		doAnswer(ISContact.deleteContactAggregate()).when(contactClient)
				.deleteContactAggregate(any(), any(), any());

		// service location mock
		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));
		doAnswer(ISServiceLocation.deleteServiceLocationAggregate()).when(svcLocClient)
				.deleteServiceLocationAggregate(any(), any(), any());

		CancelAddCustomerHierarchy request = new CancelAddCustomerHierarchy();
		request.setTransactionReference(transRef);
		request.setTargetTransactionReference(targetTransRef);
		request.setReason(reason);
		request.setStartDate(startDate);

		try
		{
			CancelAddCustomerHierarchyResponse response = sdpProvisioningService
					.cancelAddCustomerHierarchy(request, WB_HDR);
		}
		catch (WebServiceException e)
		{
			LOGGER.error("Unexpected exception:", e);
			fail();
		}
	}

	@Test
	public void disconnectAccount() throws WebServiceException, WebServiceFault, SDPServiceFault,
			InternalServiceFault, JAXBException, XMLStreamException
	{
		String serviceAgreementRef = "400366791";
		String mcr = "210401";
		String serviceId = "802066855";
		String transactionType = "disconnectAccount";
		String accountRef = "300366283";
		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(bts.getAccountHierarchyByInternalReference(any(), any()))
				.then(IWSBusinessTransaction.getAccountHierarchyByInternalReference(accountRef));

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.getLayer3Service(any())).then(LibSDPAPI.getLayer3Service(serviceId));

		when(sdpClient.getFixedNTD(any())).then(LibSDPAPI.getFixedNTD(serviceAgreementRef));

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
						.then(ISContact.getContacts(accountRef, serviceAgreementRef, true));
		doAnswer(ISContact.deleteContactAggregate()).when(contactClient)
				.deleteContactAggregate(any(), any(), any());

		when(svcLocClient.getServiceLocationAggregates(any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
						ISServiceLocation.getServiceLocationAggregates(serviceAgreementRef, true));
		doAnswer(ISServiceLocation.deleteServiceLocationAggregate()).when(svcLocClient)
				.deleteServiceLocationAggregate(any(), any(), any());

		DisconnectAccount parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/DisconnectAccount.xml"),
				DisconnectAccount.class);

		DisconnectAccountResponse response = sdpProvisioningService.disconnectAccount(parameter,
				wildBlueHeader);

	}

	@Test
	public void disconnectServiceItem() throws WebServiceException, WebServiceFault,
			SDPServiceFault, JAXBException, XMLStreamException
	{
		String serviceItemRef = "818298264";
		String mcr = "270608";
		String serviceId = "818298264";

		when(bts.getCustomerHierarchyByInternalServiceItemReference(any(), any()))
				.then(IWSBusinessTransaction
						.getCustomerHierarchyByInternalServiceItemReference(serviceItemRef));

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(sdpClient.deactivateLayer3Service(any()))
				.then(LibSDPAPI.deactivateLayer3Service(serviceId));

		when(sdpClient.deleteLayer3Service(any())).then(LibSDPAPI.deleteLayer3Service(serviceId));

		DisconnectServiceItem parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/DisconnectServiceItem.xml"),
				DisconnectServiceItem.class);

		DisconnectServiceItemResponse response = sdpProvisioningService
				.disconnectServiceItem(parameter, WB_HDR);
	}

	@Test
	public void cancelTransitionServiceAgreement() throws JAXBException, XMLStreamException, WebServiceException, WebServiceFault, InternalServiceFault {
		String targetTransactionReference="14997255";
		String transactionReference="14997255";
		String extSystemName="SFPORTAL";
		String extSvcAgreementRef="NAD-19-03-20-02";
		String extAccountRef="NAD-19-03-20-02";
		String serviceAgreementRef="403588802";
		String mcr="701453";

		when(bts.addFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.addFacadeTransaction("TRANSACTION_REF"));

		when(bts.getSoaTransactionByInternalReference(any(), any())).then(
				IWSBusinessTransaction.getSoaTransactionByInternalReference(transactionReference, false));

		when(bts.getServiceAgreementByExternalReference(any(), any())).then(IWSBusinessTransaction
				.getServiceAgreementByExternalReference(extSvcAgreementRef, extSystemName, false));

		when(bts.getCustomerHierarchyByInternalServiceAgreementReference(any(), any())).then(
				IWSBusinessTransaction.getCustomerHierarchyByInternalServiceAgreementReference(
						serviceAgreementRef, false));

		when(bts.updateFacadeTransaction(any(), any()))
				.then(IWSBusinessTransaction.updateFacadeTransaction());

		when(catalog.getComponents(any(), any())).then(FCDCatalog.getComponents(mcr, false));

		when(contactClient.getContacts(any(), any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any()))
				.then(ISContact.getContacts(null, serviceAgreementRef, true));

		when(svcLocClient.getServiceLocations(any(), any(), any(), any(), any(), any(), any(),
				any(), any(), any(), any(), any(), any(), any(), any(), any())).then(
				ISServiceLocation.getServiceLocations(serviceAgreementRef, null, true));


		CancelTransitionServiceAgreement parameter = JAXBUtility.unmarshalSoapEnvelope(
				getClass().getResourceAsStream("/requests/CancelTransitionServiceAgreement.xml"),
				CancelTransitionServiceAgreement.class);
		CancelTransitionServiceAgreementResponse cancelTransitionServiceAgreementResponse=sdpProvisioningService.cancelTransitionServiceAgreement(parameter,WB_HDR);

	}

}