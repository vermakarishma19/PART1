package com.viasat.facade.provisioning.sdp.util.servicemocks;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.catalog.data.GetComponents;
import com.viasat.facade.catalog.data.GetComponentsResponse;
import com.viasat.facade.catalog.data.ObjectFactory;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;

public class FCDCatalog
{
	private static final Logger LOGGER = LoggerFactory.getLogger(FCDCatalog.class);

	private static final String XML_ROOT_DIR = "src/test/resources/responses/catalog/";
	private static final ObjectFactory OF = new ObjectFactory();
	private static final JAXBContext JBC;
	static
	{
		try
		{
			JBC = JAXBContext.newInstance(OF.getClass().getPackage().getName());
		}
		catch (JAXBException e)
		{
			throw new RuntimeException("Failed to create JAXBContext!", e);
		}
	}

	public static Answer<GetComponentsResponse> getComponents(String reference, boolean useDefault)
	{
		return invocation -> {
			GetComponents req = invocation.getArgumentAt(0, GetComponents.class);

			LOGGER.debug("getComponents:\n"
					+ JAXBUtility.marshalXML(OF.createGetComponents(req), JBC, false));

			assertNotNull(req);
			assertFalse(req.getMasterCatalogReferences().isEmpty());

			String file;
			if (!useDefault)
				file = XML_ROOT_DIR + "GetComponents-" + reference + ".xml";
			else
				file = XML_ROOT_DIR + "GetComponents-DEFAULT.xml";

			GetComponentsResponse resp = JAXBUtility.unmarshalSoapEnvelope(
					new FileInputStream(file), GetComponentsResponse.class, JBC);

			// LOGGER.debug("getComponentsResponse: " +
			// JAXBUtility.marshalXML(resp, GetComponentsResponse.class, true));

			return resp;
		};
	}

}
