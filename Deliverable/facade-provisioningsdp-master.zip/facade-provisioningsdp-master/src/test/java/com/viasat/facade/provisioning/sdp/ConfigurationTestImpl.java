package com.viasat.facade.provisioning.sdp;

import com.viasat.common.ws.client.Configuration;

public class ConfigurationTestImpl implements Configuration
{
	@Override
	public String getURL()
	{
		return "http://fcd-provisioningsdp.sandbox.dev.wdc1.wildblue.net/Facade-Provisioning-SDP/v1/services/ProvisioningFacadeSDP";
	}

}
