package com.viasat.facade.provisioning.sdp.util.servicemocks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AddFacadeTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.AddFacadeTransactionResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetAccountHierarchyByExternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetAccountHierarchyByExternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetAccountHierarchyByInternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetAccountHierarchyByInternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetCustomerHierarchyByInternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetCustomerHierarchyByInternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetCustomerHierarchyByInternalServiceAgreementReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetCustomerHierarchyByInternalServiceAgreementReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetCustomerHierarchyByInternalServiceItemReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetCustomerHierarchyByInternalServiceItemReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetServiceAgreementByExternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetServiceAgreementByExternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetServiceAgreementByInternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetServiceAgreementByInternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetServiceAgreementHierarchyByInternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetServiceAgreementHierarchyByInternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetSoaTransactionByInternalReference;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.GetSoaTransactionByInternalReferenceResponse;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.ObjectFactory;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.UpdateFacadeTransaction;
import com.viasat.wildblue.internalwebservice.businesstransaction.data.UpdateFacadeTransactionResponse;

public class IWSBusinessTransaction
{
	private static final Logger LOGGER = LoggerFactory.getLogger(IWSBusinessTransaction.class);

	private static final String XML_ROOT_DIR = "src/test/resources/responses/bts/";
	private static final ObjectFactory OF = new ObjectFactory();
	private static final JAXBContext JBC;
	static
	{
		try
		{
			JBC = JAXBContext.newInstance(OF.getClass().getPackage().getName());
		}
		catch (JAXBException e)
		{
			throw new RuntimeException("Failed to create JAXBContext!", e);
		}
	}

	public static Answer<AddFacadeTransactionResponse> addFacadeTransaction(String transactionRef)
	{
		return invocation -> {
			AddFacadeTransaction req = invocation.getArgumentAt(0, AddFacadeTransaction.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("addFacadeTransaction:\n"
					+ JAXBUtility.marshalXML(OF.createAddFacadeTransaction(req), JBC, false));

			validateHeader(hdr);
			assertNotNull(req.getFacadeOwnerName());
			assertNotNull(req.getFacadeTransactionTypeName());
			assertNotNull(req.getFacadeXmlLogItem()); // ?
			assertNotNull(req.getSoaTransactionReference());

			// ensure at least one reference value is present
			assertTrue(req.getCustomerReference() != null || req.getAccountReference() != null
					|| req.getServiceAgreementReference() != null);

			AddFacadeTransactionResponse resp = new AddFacadeTransactionResponse();
			resp.setFacadeTransactionReference(transactionRef);
			return resp;
		};
	}

	public static Answer<UpdateFacadeTransactionResponse> updateFacadeTransaction()
	{
		return invocation -> {
			UpdateFacadeTransaction req = invocation.getArgumentAt(0,
					UpdateFacadeTransaction.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("updateFacadeTransaction:\n"
					+ JAXBUtility.marshalXML(OF.createUpdateFacadeTransaction(req), JBC, false));

			validateHeader(hdr);
			assertNotNull(req.getFacadeTransactionReference());
			assertNotNull(req.getFacadeTransactionStatusName());

			UpdateFacadeTransactionResponse resp = new UpdateFacadeTransactionResponse();
			return resp;
		};
	}

	public static Answer<GetSoaTransactionByInternalReferenceResponse> getSoaTransactionByInternalReference(
			String soaTransRef, boolean useDefault)
	{
		return invocation -> {
			GetSoaTransactionByInternalReference req = invocation.getArgumentAt(0,
					GetSoaTransactionByInternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getSoaTransactionByInternalReference:\n" + JAXBUtility
					.marshalXML(OF.createGetSoaTransactionByInternalReference(req), JBC, false));

			validateHeader(hdr);
			assertEquals(soaTransRef, req.getSoaTransactionReference());

			String file;
			if (!useDefault)
				file = XML_ROOT_DIR + "GetSoaTransByIntRef-" + req.getSoaTransactionReference()
						+ ".xml";
			else
				file = XML_ROOT_DIR + "GetSoaTransByIntRef-DEFAULT.xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetSoaTransactionByInternalReferenceResponse.class, JBC);
		};
	}

	public static Answer<GetAccountHierarchyByExternalReferenceResponse> getAccountHierarchyByExternalReference(
			String externalAccountRef, String externalSystemName, boolean useDefault)
	{
		return invocation -> {
			GetAccountHierarchyByExternalReference req = invocation.getArgumentAt(0,
					GetAccountHierarchyByExternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getAccountHierarchyByExternalReference:\n" + JAXBUtility
					.marshalXML(OF.createGetAccountHierarchyByExternalReference(req), JBC, false));

			validateHeader(hdr);
			assertEquals(externalAccountRef, req.getExternalAccountReference());
			assertEquals(externalSystemName, req.getExternalSystemName());
			assertNotNull(req.getExternalSystemName());

			String file;
			if (!useDefault)
				file = XML_ROOT_DIR + "GetAcctHrchyByExtRef-" + req.getExternalAccountReference()
						+ ".xml";
			else
				file = XML_ROOT_DIR + "GetAcctHrchyByExtRef-DEFAULT.xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetAccountHierarchyByExternalReferenceResponse.class, JBC);
		};
	}

	public static Answer<GetServiceAgreementByExternalReferenceResponse> getServiceAgreementByExternalReference(
			String externalServiceAgreementRef, String externalSystemName, boolean useDefault)
	{
		return invocation -> {
			GetServiceAgreementByExternalReference req = invocation.getArgumentAt(0,
					GetServiceAgreementByExternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getServiceAgreementByExternalReference:\n" + JAXBUtility
					.marshalXML(OF.createGetServiceAgreementByExternalReference(req), JBC, false));

			validateHeader(hdr);
			assertEquals(externalServiceAgreementRef, req.getExternalServiceAgreementReference());
			assertEquals(externalSystemName, req.getExternalSystemName());

			String file;
			if (!useDefault)
				file = XML_ROOT_DIR + "GetSvcAgrmtByExtRef-"
						+ req.getExternalServiceAgreementReference() + ".xml";
			else
				file = XML_ROOT_DIR + "GetSvcAgrmtByExtRef-DEFAULT.xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetServiceAgreementByExternalReferenceResponse.class, JBC);
		};
	}

	public static Answer<GetCustomerHierarchyByInternalServiceAgreementReferenceResponse> getCustomerHierarchyByInternalServiceAgreementReference(
			String serviceAgreementRef, boolean useDefault)
	{
		return invocation -> {
			GetCustomerHierarchyByInternalServiceAgreementReference req = invocation.getArgumentAt(
					0, GetCustomerHierarchyByInternalServiceAgreementReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getCustomerHierarchyByInternalServiceAgreementReference:\n"
					+ JAXBUtility.marshalXML(
							OF.createGetCustomerHierarchyByInternalServiceAgreementReference(req),
							JBC, false));

			validateHeader(hdr);
			assertEquals(serviceAgreementRef, req.getServiceAgreementReference());

			String file;
			if (!useDefault)
				file = XML_ROOT_DIR + "GetCustHrchyByIntSvcAgrmtRef-"
						+ req.getServiceAgreementReference() + ".xml";
			else
				file = XML_ROOT_DIR + "GetCustHrchyByIntSvcAgrmtRef-DEFAULT.xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetCustomerHierarchyByInternalServiceAgreementReferenceResponse.class, JBC);
		};
	}

	public static Answer<GetCustomerHierarchyByInternalReferenceResponse> getCustomerHierarchyByInternalReference(
			String customerRef)
	{
		return invocation -> {
			GetCustomerHierarchyByInternalReference req = invocation.getArgumentAt(0,
					GetCustomerHierarchyByInternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getCustomerHierarchyByInternalReference:\n" + JAXBUtility
					.marshalXML(OF.createGetCustomerHierarchyByInternalReference(req), JBC, false));

			validateHeader(hdr);
			assertNotNull(req.getCustomerReference());

			String file = XML_ROOT_DIR + "GetCustHierarchyByIntResp-" + customerRef + ".xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetCustomerHierarchyByInternalReferenceResponse.class, JBC);

		};
	}

	public static Answer<GetAccountHierarchyByInternalReferenceResponse> getAccountHierarchyByInternalReference(
			String accountRef)
	{
		return invocation -> {
			GetAccountHierarchyByInternalReference req = invocation.getArgumentAt(0,
					GetAccountHierarchyByInternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getAccountHierarchyByInternalReference:\n" + JAXBUtility
					.marshalXML(OF.createGetAccountHierarchyByInternalReference(req), JBC, false));

			validateHeader(hdr);
			assertNotNull(req.getAccountReference());

			String file = XML_ROOT_DIR + "GetAcctHierarchyByIntResp-" + accountRef + ".xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetAccountHierarchyByInternalReferenceResponse.class, JBC);
		};
	}

	public static Answer<GetServiceAgreementByInternalReferenceResponse> getServiceAgreementByInternalReference(
			String serviceAgreementRef)
	{
		return invocation -> {
			GetServiceAgreementByInternalReference req = invocation.getArgumentAt(0,
					GetServiceAgreementByInternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getServiceAgreementByInternalReference:\n" + JAXBUtility
					.marshalXML(OF.createGetServiceAgreementByInternalReference(req), false));

			validateHeader(hdr);
			assertNotNull(req.getServiceAgreementReference());
			String file = XML_ROOT_DIR + "getServiceAgByIntRef-" + serviceAgreementRef + ".xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetServiceAgreementByInternalReferenceResponse.class);
		};
	}

	public static Answer<GetServiceAgreementHierarchyByInternalReferenceResponse> getServiceAgreementHierarchyByInternalReference(
			String serviceAgreementRef)
	{
		return invocation -> {
			GetServiceAgreementHierarchyByInternalReference req = invocation.getArgumentAt(0,
					GetServiceAgreementHierarchyByInternalReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug(
					"getServiceAgreementHierarchyByInternalReference:\n" + JAXBUtility.marshalXML(
							OF.createGetServiceAgreementHierarchyByInternalReference(req), false));

			validateHeader(hdr);
			assertNotNull(req.getServiceAgreementReference());
			String file = XML_ROOT_DIR + "getServiceAgHieraByIntRef-" + serviceAgreementRef
					+ ".xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetServiceAgreementHierarchyByInternalReferenceResponse.class);
		};
	}

	public static Answer<GetCustomerHierarchyByInternalServiceItemReferenceResponse> getCustomerHierarchyByInternalServiceItemReference(
			String serviceItemRef)
	{
		return invocation -> {
			GetCustomerHierarchyByInternalServiceItemReference req = invocation.getArgumentAt(0,
					GetCustomerHierarchyByInternalServiceItemReference.class);
			WildBlueHeader hdr = invocation.getArgumentAt(1, WildBlueHeader.class);

			LOGGER.debug("getCustomerHierarchyByInternalServiceItemReference:\n" + JAXBUtility
					.marshalXML(OF.createGetCustomerHierarchyByInternalServiceItemReference(req),
							false));

			validateHeader(hdr);
			assertNotNull(req.getServiceItemReference());
			String file = XML_ROOT_DIR + "getCustomerHierByIntSrvcItemRef-" + serviceItemRef
					+ ".xml";

			return JAXBUtility.unmarshalSoapEnvelope(new FileInputStream(file),
					GetCustomerHierarchyByInternalServiceItemReferenceResponse.class);
		};
	}

	private static void validateHeader(WildBlueHeader wbHeader)
	{
		assertNotNull(wbHeader);
		assertNotNull(wbHeader.getInvokedBy());
		assertNotNull(wbHeader.getInvokedBy().getApplication());
		assertNotNull(wbHeader.getInvokedBy().getUsername());
	}
}
