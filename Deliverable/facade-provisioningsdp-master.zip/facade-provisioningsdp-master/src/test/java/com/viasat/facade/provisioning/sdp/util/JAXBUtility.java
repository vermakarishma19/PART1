package com.viasat.facade.provisioning.sdp.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.viasat.wildblue.facade.provisioning.data.ObjectFactory;

public class JAXBUtility
{
	public static final JAXBContext FACADE_PROV_SDP_JBC;
	static
	{
		try
		{
			FACADE_PROV_SDP_JBC = JAXBContext
					.newInstance(ObjectFactory.class.getPackage().getName());
		}
		catch (JAXBException e)
		{
			throw new RuntimeException("Failed to create JAXBContext!", e);
		}
	}

	public static <T> T unmarshalXML(InputStream reader, Class<T> cls)
			throws XMLStreamException, JAXBException
	{
		JAXBContext jaxbContext = JAXBContext.newInstance(cls.getPackage().getName());
		return unmarshalXML(reader, cls, jaxbContext);
	}

	public static <T> T unmarshalXML(InputStream reader, Class<T> cls, JAXBContext jaxbContext)
			throws XMLStreamException, JAXBException
	{
		XMLStreamReader xsr = XMLInputFactory.newFactory().createXMLStreamReader(reader);
		Unmarshaller um = jaxbContext.createUnmarshaller();
		return um.unmarshal(xsr, cls).getValue();
	}

	public static <T> T unmarshalSoapEnvelope(InputStream reader, Class<T> cls)
			throws XMLStreamException, JAXBException
	{
		JAXBContext jaxbContext = JAXBContext.newInstance(cls.getPackage().getName());
		return unmarshalSoapEnvelope(reader, cls, jaxbContext);
	}

	public static <T> T unmarshalSoapEnvelope(InputStream reader, Class<T> cls,
			JAXBContext jaxbContext) throws XMLStreamException, JAXBException
	{
		XMLStreamReader xsr = XMLInputFactory.newFactory().createXMLStreamReader(reader);

		while (xsr.next() != XMLStreamReader.START_ELEMENT
				|| !"Body".equalsIgnoreCase(xsr.getLocalName()))
		{
			// Skip everything before the body tag
		}
		xsr.nextTag(); // Advance to the first tag within "Body"

		Unmarshaller um = jaxbContext.createUnmarshaller();
		return um.unmarshal(xsr, cls).getValue();
	}

	public static <T> T unmarshalSDPMessageEnvelope(InputStream reader, Class<T> cls)
			throws XMLStreamException, JAXBException
	{
		XMLStreamReader xsr = XMLInputFactory.newFactory().createXMLStreamReader(reader);

		while (xsr.next() != XMLStreamReader.START_ELEMENT
				|| !"output".equalsIgnoreCase(xsr.getLocalName()))
		{
			// Skip everything before the output tag
		}
		xsr.nextTag(); // Advance to the first tag within "output"

		Unmarshaller um = JAXBContext.newInstance(cls.getPackage().getName()).createUnmarshaller();
		return um.unmarshal(xsr, cls).getValue();
	}

	public static <T> T unmarshalJSON(InputStream reader, Class<T> cls) throws IOException
	{
		ObjectMapper m = new ObjectMapper();
		// OffsetDateTime support
		m.registerModule(new JavaTimeModule());
		m.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

		return m.readValue(reader, cls);
	}

	public static String marshalXML(Object object, Class cls, boolean formatted)
			throws JAXBException
	{
		JAXBContext jaxbContext = JAXBContext.newInstance(cls.getPackage().getName());
		return marshalXML(object, cls, jaxbContext, formatted);
	}

	public static String marshalXML(Object object, Class cls, JAXBContext jaxbContext,
			boolean formatted) throws JAXBException
	{
		StringWriter sw = new StringWriter();
		Marshaller m = jaxbContext.createMarshaller();
		m.setProperty(Marshaller.JAXB_FRAGMENT, true);
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formatted);
		m.marshal(object, sw);

		return sw.toString();
	}

	public static String marshalXML(JAXBElement jaxbElement, boolean formatted) throws JAXBException
	{
		JAXBContext jaxbContext = JAXBContext
				.newInstance(jaxbElement.getDeclaredType().getPackage().getName());
		return marshalXML(jaxbElement, jaxbContext, formatted);
	}

	public static String marshalXML(JAXBElement jaxbElement, JAXBContext jaxbContext,
			boolean formatted) throws JAXBException
	{
		// JAXBElement marshaller for no @XmlRootElement
		StringWriter sw = new StringWriter();
		Marshaller m = jaxbContext.createMarshaller();
		m.setProperty(Marshaller.JAXB_FRAGMENT, true);
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formatted);
		m.marshal(jaxbElement, sw);

		return sw.toString();
	}

	public static String marshalJSON(Object object, boolean formatted)
			throws JsonProcessingException
	{
		ObjectMapper m = new ObjectMapper();
		// OffsetDateTime support
		m.registerModule(new JavaTimeModule());
		m.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

		if (formatted)
			return m.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		else
			return m.writeValueAsString(object);
	}
}