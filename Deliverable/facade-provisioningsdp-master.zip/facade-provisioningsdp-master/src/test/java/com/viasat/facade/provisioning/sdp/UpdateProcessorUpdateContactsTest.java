package com.viasat.facade.provisioning.sdp;

import static org.junit.Assert.assertNotNull;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;

import com.viasat.common.client.EndpointInitException;
import com.viasat.facade.provisioning.sdp.processor.UpdateProcessor;
import com.viasat.facade.provisioning.sdp.processor.ValidationProcessor;
import com.viasat.facade.provisioning.sdp.util.ConfigurationConstants;
import com.viasat.facade.provisioning.sdp.util.JAXBUtility;
import com.viasat.facade.provisioning.sdp.util.ServiceProviderFinder;
import com.viasat.facade.provisioning.sdp.wrapper.BusinessTransactionWrapper;
import com.viasat.facade.provisioning.sdp.wrapper.ContactsWrapper;
import com.viasat.wildblue.common.header.WildBlueHeader;
import com.viasat.wildblue.facade.provisioning.data.CorrectedContact;
import com.viasat.wildblue.facade.provisioning.data.UpdateContacts;
import com.viasat.wildblue.facade.provisioning.data.UpdateContactsResponse;

/**
 * Created by kverma on 1/9/2017.
 */

@ContextConfiguration(locations =
{ "classpath:/spring/test-applicationContext.xml" })
@RunWith(PowerMockRunner.class)
@PrepareForTest(
{ ValidationProcessor.class, BusinessTransactionWrapper.class, UpdateProcessor.class,
		UpdateProcessor.class, ServiceProviderFinder.class })
public class UpdateProcessorUpdateContactsTest
{
	private static final String CONFIGURATION_SERVICE_ENDPOINT = "configurationServiceEndpoint";
	private static final Logger LOGGER = LoggerFactory
			.getLogger(UpdateProcessorUpdateContactsTest.class);
	private UpdateProcessor processor = new UpdateProcessor();
	private EntityManager volubillAccessEm;

	@BeforeClass
	public static void setUpClass() throws ClassNotFoundException, NamingException, SQLException
	{
		String configEndpoint = System.getenv(CONFIGURATION_SERVICE_ENDPOINT);
		if (configEndpoint != null)
		{
			System.setProperty(CONFIGURATION_SERVICE_ENDPOINT, configEndpoint);
		}
		else
		{
			// default
			System.setProperty(CONFIGURATION_SERVICE_ENDPOINT,
					"http://iws-configuration.sandbox.dev.wdc1.wildblue.net/ConfigurationService/services/ConfigurationService");
		}
		LOGGER.debug("Using " + System.getProperty("configurationServiceEndpoint")
				+ " for configuration.");

	}

	@Before
	public void setUp() throws Exception
	{
		;
	}

	@Test
	public void testUpdateContacts() throws EndpointInitException
	{

		final WildBlueHeader wildBlueHeader = ConfigurationConstants.COMMON_WILDBLUE_HEADER;
		volubillAccessEm = mock(EntityManager.class);

		try
		{
			UpdateContacts parameter = JAXBUtility.unmarshalSoapEnvelope(
					getClass().getResourceAsStream("/requests/UpdateContacts.xml"),
					UpdateContacts.class);

			PowerMockito.mockStatic(BusinessTransactionWrapper.class);
			PowerMockito.mockStatic(ServiceProviderFinder.class);
			ContactsWrapper contactsWrapper = mock(ContactsWrapper.class);
			BusinessTransactionWrapper btsWrapper = mock(BusinessTransactionWrapper.class);

			processor.setBusinessTransactionWrapper(btsWrapper);
			processor.setContactsWrapper(contactsWrapper);

			String serviceAgreementReference = parameter.getServiceAgreementReference();
			String accountReference = "106288167";
			String customerReference = "106288166";

			when(btsWrapper.getAccountReferenceFromInternalServiceAgreementReference(
					serviceAgreementReference, wildBlueHeader)).thenReturn(accountReference);

			when(btsWrapper.getCustomerReferenceFromInternalAccountReference(accountReference,
					wildBlueHeader)).thenReturn(customerReference);

			CorrectedContact cc = parameter.getCorrectedContact();

			contactsWrapper.updateAllContactAggregates(serviceAgreementReference, accountReference,
					cc, wildBlueHeader.getInvokedBy().getUsername(),
					wildBlueHeader.getInvokedBy().getApplication());

			UpdateContactsResponse response = processor.updateContacts(parameter, wildBlueHeader);
			assertNotNull(response);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

}
